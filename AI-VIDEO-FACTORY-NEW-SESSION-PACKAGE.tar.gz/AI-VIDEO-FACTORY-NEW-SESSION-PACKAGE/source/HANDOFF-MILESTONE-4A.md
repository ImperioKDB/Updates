# Milestone 4A — Reliability handoff

**Status:** Final corrective implementation complete locally on `milestone-4a-reliability`; not merged.
**Repository:** `ImperioKDB/ai-video-factory`
**Starting point:** `milestone-3-continuation` at `fbad579515cd7712363296414385c69fc5f2332c`
**Target branch:** `milestone-4a-reliability`
**Implementation commit:** `9be8eede9639b473056cf5d802a40d9b1c771c8d` (`Improve render reliability and auditability`)
**Final corrective commit:** `079d8819a6a2cd9886d3a6a6d5855e6a8dc8402e` (`Complete Milestone 4A corrective safeguards`)
**Corrective scope:** Manifest-integrity and transactional-publication remediation requested by the independent audit.
**Handoff metadata commit:** immediately follows the corrective implementation commit; the repository’s final branch SHA is reported with the completion summary.

## Original problems discovered

- The npm-bundled ARM64 ffprobe executable could lose its POSIX executable bit after `npm ci`, producing `EACCES` without a useful portability diagnosis.
- Renderer font loading and optional media inputs depended on the process working directory.
- Successful renders had no machine-readable audit record connecting the brief, source revision, output hash, media metadata, and verification state.
- MP4 verification did not check output size, 9:16 aspect ratio, plausible frame count, silent/audio consistency, or full manifest state.
- User-supplied WAV handling in `scripts/narrate.py` did not follow the brief-relative media path contract.
- Automatic push and pull-request rendering could spend compute on stale duplicate runs or documentation-only changes.

## Technical changes

- Added `src/render-support.ts` for bundled FFmpeg/ffprobe executable repair and architecture-aware preflight, explicit media-path resolution, missing-file diagnostics, probing, SHA-256 hashing, and manifest paths. No unrelated system binary fallback is used.
- Updated `scripts/render.ts` to load fonts from the repository location rather than the caller’s working directory, resolve brief-declared assets relative to the brief, validate assets before frame generation, and write a manifest only after successful encoding and probing.
- Added `src/render-manifest.ts` and `schema/render-manifest.schema.json`. Manifests record input/output hashes, renderer version and available commit, timestamp, media metadata, segment count, settings, warnings, and separate rendered/verified states.
- Strengthened `scripts/test-render.ts` with actionable checks for non-empty output, MP4, H.264, 1080×1920, 9:16, 30 FPS, duration, frame count, expected audio state, AAC alignment, and full FFmpeg decode. Successful verification marks an existing manifest as `verified`.
- Added `scripts/test-reliability.ts` and `npm run test:reliability`. It uses generated sine-wave fixtures and tests executable repair, relative/absolute paths, spaces, nested directories, missing media, user WAV handling, mixed audio, manifest creation/verification, and rendering from another working directory.
- Updated `scripts/narrate.py` so `narration.wavPath` is resolved relative to the brief directory unless absolute.
- Added `docs/adr-002-reliability-and-render-audit.md` and updated `README.md` with the path contract, manifest usage, QA behavior, and zero-cost limitations.
- Updated `.github/workflows/render-video.yml` with relevant-path filters, concurrency cancellation, and executable/architecture-aware bundled-tool preflight. Piper remains opt-in. No workflow was dispatched.

## Corrective implementation

- Upgraded the render manifest contract to version 2 with a run ID, measured-versus-expected fields, average frame rate, audio duration, and explicit schema validation.
- Made manifest creation and verification writes atomic, flushed, round-trip parsed, and schema-validated before publication.
- Bound verification to the current brief path/hash, output path/hash, manifest `rendered` state, and the actual file under test. Missing manifests fail by default; legacy compatibility requires `--allow-missing-manifest`.
- Made render publication transactional: stale final MP4s and manifests are moved to run-scoped rollback names, the new MP4 is encoded/probed in a temporary directory, and final files are published only after success.
- Strengthened frame-rate checks using both nominal and average rates and rejected malformed frame-count metadata.
- Added deterministic audio assertions for fade-in/out, gain, narration placement, and ducking using isolated generated-tone bands. Corrected the renderer’s sidechain configuration so automatic makeup gain cannot defeat ducking.
- Added negative tests for mismatched brief/output/hash/status, malformed/schema-invalid manifests, missing manifests, manifest access errors, failed-render cleanup, and directory inputs. The suite cleans its temporary root in `finally`.
- Added the manifest to the successful GitHub Actions artifact beside the MP4. No workflow was dispatched.

## Files modified or added

- `.github/workflows/render-video.yml`
- `README.md`
- `HANDOFF-MILESTONE-4A.md`
- `package.json`
- `scripts/narrate.py`
- `scripts/render.ts`
- `scripts/test-render.ts`
- `scripts/test-reliability.ts`
- `src/render-support.ts`
- `src/render-manifest.ts`
- `schema/render-manifest.schema.json`
- `docs/adr-002-reliability-and-render-audit.md`

Generated MP4s, manifests, temporary WAVs, Piper models, Python environments, and build output remain ignored and were not committed.

## Verification performed

The following commands completed successfully locally:

- `npm run typecheck`
- `npm run test:brief`
- `npm run test:reliability`
- `npm run build` (existing Vite CJS API deprecation warning remains)
- `python3 -m py_compile scripts/narrate.py`
- `npm run brief:validate -- examples/first-brief.json`
- `npm run brief:validate -- examples/eight-segment.json`
- `git diff --check`

Corrective verification also completed successfully:

- `npm run typecheck`
- `npm run test:brief`
- `python3 -m py_compile scripts/narrate.py`
- `npm run build` (the existing Vite CJS API deprecation warning remains)
- `npm run test:reliability`
- `git diff --check`

The new reliability suite passed with generated audio and no Piper model download. A local eight-segment render also passed the strengthened verifier:

- Output: 22.000 seconds, 660 frames
- Video: H.264, 1080×1920, 30 FPS, 9:16
- Audio: absent as requested
- Full FFmpeg decode: passed
- Manifest: `rendered` then `verified`
- Manifest version: `2`; render ID recorded; brief/output path and hash identity checks passed
- Brief SHA-256: `733d4bd8ee8110c6b22170b0a39b3aade1e430b24d776d16454cda4b00a52db2`
- Output SHA-256: recorded in the generated manifest and verified before status transition

## Not executed

- No GitHub Actions workflow was dispatched. The private-repository allowance was not assumed to be unlimited, and this milestone was required to remain locally executable.
- ARM64 hardware execution was not available in this environment. The permission repair and architecture error paths were tested with local fixtures and the installed bundled tools, but this is not a claim of end-to-end ARM64 verification.
- Piper synthesis/model download was not repeated. Existing Milestone 3 Piper and narrated CI evidence remains historical and is not evidence for new Milestone 4A code.

## Remaining limitations

- The Motion Canvas preview and SVG renderer still have separate drawing implementations; visual consistency remains a later milestone.
- Manifest timestamps are intentionally time-dependent. Other metadata is deterministic where the encoder and environment permit.
- Existing dependency audit findings remain in the Motion Canvas/Vite dependency line; no broad upgrade was attempted.
- The workflow YAML was inspected and changed but not executed.

## Safety and branch guarantees

- No paid service, billing activation, payment method, paid API, or paid infrastructure was used.
- No GitHub Actions workflow was dispatched during Milestone 4A.
- `main` was not modified.
- `milestone-3-continuation` was not modified.
- No force-push, history rewrite, merge, or pull request was performed.
- Work is committed and pushed only to `milestone-4a-reliability`.

## Final corrective implementation

The independent post-correction audit blockers were addressed without changing the Motion Canvas/SVG architecture:

- `scripts/render.ts` creates one UUID per invocation, acquires a per-output atomic lock, reads and hashes one brief byte snapshot, renders to a temporary output, probes before publication, publishes the MP4 and manifest under the lock, validates the published identity, and deletes rollback copies only after the pair is complete.
- Failed setup, encode, probe, or manifest stages restore the prior MP4/manifest pair before releasing the lock. Lock records contain a random ownership token, PID, host, and timestamp; an old lock is recovered only when same-host ownership cannot be established and the lock is older than the recovery threshold. Different output paths use different lock files.
- `scripts/test-render.ts` requires `RENDER_ID`, parses and hashes one brief byte snapshot, checks output device/inode/size/mtime after probe/decode/hash, and validates every video frame timestamp interval against 30 FPS with a 2 ms tolerance. Missing or malformed timestamps fail.
- `.github/workflows/render-video.yml` rejects control characters, canonicalizes and confines manually supplied brief paths to the repository, uses fixed-format `printf` output, and passes the render ID emitted by the render step into verification.
- `scripts/test-reliability.ts` covers wrong render IDs, lock contention/release, independent destinations, safe stale-lock recovery, restoration of a prior successful pair after failure, progressive generated-tone fades, calibrated normalized-mix gain, narration start/end boundaries, clipping, output identity, schema/status/hash failures, and cleanup.
- `scripts/test-workflow-safety.ts` statically checks the workflow’s control-character, repository-containment, and output-protocol safeguards.

Manifest version 1 is intentionally unsupported. Existing v1 manifests must be regenerated by rerunning the render and verifier to produce a v2 manifest; normal verification does not silently accept v1 records.

## Final local verification

The following final gates passed:

- `npm run typecheck`
- `npm run test:brief`
- `python3 -m py_compile scripts/narrate.py`
- `npm run build` (existing Vite CJS API deprecation warning only)
- `npm run test:workflow-safety`
- `npm run test:reliability`
- `git diff --check`

The final isolated eight-segment render passed strict verification: 22.000 seconds, 660 frames, H.264 1080×1920, 30 FPS, no audio as requested, full FFmpeg decode, manifest status `verified`, and `decodeVerified: true`. The render ID was passed explicitly from the render invocation to the verifier. No workflow was dispatched, no Piper model was downloaded, and no paid resource was used.

## Final limitations

- Output identity checks detect ordinary replacement or mutation but are not a kernel-level immutable read lock against every adversarial filesystem race.
- Lock recovery is conservative and cannot make power-loss durability equivalent to a journaled filesystem; directory fsync is not claimed.
- Audio gain is calibrated for the normalized two-input mix (net 0 dB target with a ±4 dB tolerance), with clipping and boundary checks; exact sample-level synchronization is not claimed.
- ARM64 end-to-end execution, Piper synthesis, and GitHub Actions remain unexecuted by design.
