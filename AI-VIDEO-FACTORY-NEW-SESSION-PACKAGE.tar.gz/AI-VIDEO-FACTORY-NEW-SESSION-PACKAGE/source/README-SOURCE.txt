Repository: https://github.com/ImperioKDB/ai-video-factory
Current branch: milestone-4a-reliability
Current HEAD: cc9ca628b09cec36b4e82e6f9d35e69fb1e8d3ad
The GitHub repository is authoritative; the bundle is an offline history backup.
