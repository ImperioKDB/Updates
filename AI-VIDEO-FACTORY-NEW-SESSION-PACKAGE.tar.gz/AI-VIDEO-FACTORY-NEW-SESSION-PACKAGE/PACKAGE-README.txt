AI VIDEO FACTORY — PORTABLE NEW SESSION PACKAGE

Start with AI-VIDEO-FACTORY-NEW-SESSION-HANDOFF.md.

The source repository and public report repository are linked there. The source/ai-video-factory-all-history.bundle file is an offline Git history backup; the public GitHub repository remains authoritative.

This package intentionally excludes credentials, API keys, node_modules, generated MP4/WAV files, Piper weights, Python environments, and build output.
