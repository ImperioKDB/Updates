# AI Video Factory — Repository Forensic Audit

**Audit date:** 2026-11-02  
**Repository:** `ImperioKDB/ai-video-factory`  
**Scope:** Read-only repository audit plus local verification. No tracked files were changed, no branch was merged, no pull request was opened, and no GitHub Actions workflow was dispatched.

## 1. Repository access and branch state

Repository access is confirmed through the authenticated GitHub CLI.

- **Repository visibility:** Private.
- **Default branch:** `main`.
- **`main` HEAD:** `a3a1d827e8ec8168550be608bb89ccb959154c4f` (`a3a1d82`) — `Document milestone-three audit and handoff checkpoint`.
- **Development branch HEAD:** `origin/milestone-3-continuation` at `a23305060b5c4c40503f7d4f367dd1faecda4ad2` (`a233050`) — `Update milestone 3 handoff after review push`.
- **Working tree:** Clean on the checked-out audit copies. Local dependency installation and generated output are ignored by Git.

The development branch is six commits ahead of the current `main` checkpoint in the visible history, with the implementation commit at `13bb627` and the branch tip at `a233050`.

Recent history, oldest to newest, is:

1. `eeda018` — Initial commit.
2. `8eba9e1` — Build first Motion Canvas video milestone.
3. `a40edd4` — Use runner-provided FFmpeg in CI.
4. `f4b3829` — Bundle FFmpeg tools for reproducible CI renders.
5. `eeb3d06` — Add structured video briefs and local Piper narration.
6. `270e66d` — Document completed video factory milestones.
7. `a3a1d82` — Document milestone-three audit and handoff checkpoint on `main`.
8. `13bb627` — Implement milestone-three shared brief rendering on the development line.
9. `a233050` — Update the milestone-three handoff after review push.

The repository’s existing GitHub Actions history contains successful `main` runs through `a3a1d82`, but no run for `milestone-3-continuation`. The workflow only auto-runs on pushes to `main` or pull requests targeting `main`; the development branch push did not trigger it.

## 2. Repository architecture

The project is a small TypeScript/Vite Motion Canvas application with a separate deterministic headless renderer:

- `schema/video-brief.schema.json` defines versioned v1/v2 brief contracts using JSON Schema 2020-12.
- `src/brief.ts` validates with Ajv and normalizes v1/v2 input into a shared timeline model.
- `src/design/` contains design tokens, text-fit checks, layout preparation, transition helpers, and a preview model.
- `src/scenes/factory-intro.tsx` is the editable Motion Canvas preview. It currently imports the committed `examples/multi-segment.json` example at module load time.
- `scripts/render.ts` is the CI/export path. It generates SVG frames, rasterizes them with Sharp, and encodes H.264 MP4 through an npm-bundled FFmpeg binary.
- `scripts/narrate.py` synthesizes or validates narration WAV files using locally installed Piper, placing one clip per segment on the full timeline.
- `scripts/test-brief.ts` tests the normalized brief model and layout rules.
- `scripts/test-render.ts` probes and decodes the generated MP4 and checks dimensions, codec, frame rate, duration, and optionally AAC audio.
- `.github/workflows/render-video.yml` installs dependencies, validates a selected brief, type-checks/builds, optionally installs Piper, renders, verifies, and uploads one MP4 artifact.

The architecture deliberately does **not** claim that Motion Canvas itself renders the CI artifact. Preview and export share brief/timing/layout data, tokens, text-fit logic, and transition helpers, but they still have separate drawing implementations. That is an acceptable documented compromise for a reliable headless export path, but it is not pixel-perfect single-source rendering.

## 3. Milestone 3 verification

### Verified by this audit

On a separate worktree at `a233050`, after a clean `npm ci --ignore-scripts`:

- `npm run typecheck` — **PASS**.
- `npm run test:brief` — **PASS** for v1 compatibility, v2 validation, six layouts, timeline boundaries, eight scenes, preview/export model equality, and text overflow rejection.
- `npm run build` — **PASS**. Vite emits its existing CJS API deprecation warning.
- `python3 -m py_compile scripts/narrate.py` — **PASS**.
- v1 and eight-segment brief validation — **PASS**.
- Eight-segment headless render — **PASS**. It produced a 22.00-second MP4 with 660 frames.
- The project’s own `test:render` verifier — **PASS** after correcting a local executable-permission issue in the ignored installed ffprobe file.
- Independent system ffprobe inspection — **PASS**: MP4 container, H.264 video, 1080×1920, 30/1 FPS, 22.000000 seconds, 660 frames, progressive yuv420p, 9:16 display aspect ratio, and full decode by system FFmpeg.

The verified local artifact is available at [the eight-segment MP4](/home/ubuntu/ai-video-factory-dev-check/output/ai-video-factory.mp4).

### Implemented but not fully verified here

- Piper installation and voice-model download were not repeated in this audit because the development branch handoff reports them as locally completed, but the environment did not already contain the ignored `.venv/piper` and model files.
- Per-segment Piper synthesis, user-supplied WAV synchronization, narration-only audio, music-only audio, and mixed music/narration ducking remain supported by code and are described in the handoff, but they were not independently rerun in this audit.
- Motion Canvas browser preview behavior was not rerun here. The handoff reports a prior Playwright check, but that remains historical evidence rather than a fresh result from this audit.
- GitHub Actions narrated rendering remains unverified. The successful Actions history belongs to earlier `main` commits and does not prove the new development branch’s narrated workflow.

### Partially implemented or architecturally limited

- Preview and headless export share normalized data and layout preparation, but the actual visual drawing remains duplicated between TSX and SVG. Changes to visual composition must still be reviewed in both paths.
- `factory-intro.tsx` uses a committed example brief rather than a runtime-selected brief. The headless renderer is brief-driven; the interactive preview is not yet a general brief editor/input surface.
- The schema supports optional captions, metadata, music, transitions, six layouts, and up to eight scenes, but there is no broad visual regression suite or automated comparison between preview frames and exported frames.
- The renderer resolves asset paths from the current working directory. A brief’s relative `wavPath` or music path may be surprising when the CLI is launched from another directory rather than the repository root.

### Broken or inconsistent findings

- The first audit attempt exposed a local command-wrapper mistake, not a repository defect. The corrected command passed.
- On this ARM64 sandbox, `npm ci` installed the bundled ffprobe binary with mode `0644`, causing `test:render` to fail with `EACCES`; adding the executable bit to the ignored local file made the exact verifier pass. GitHub’s `ubuntu-latest` workflow currently uses x64, so this does not prove an Actions failure, but it is a reproducibility weakness across architectures. The project should either normalize executable permissions during installation/verification or use a robust fallback/error message.
- `npm ci` reports four known advisories in the Motion Canvas/Vite dependency chain: three moderate and one high according to the repository’s current audit output. `npm audit` reported no non-breaking fix. A broad upgrade could break the Motion Canvas/Vite compatibility and should be treated as a separate compatibility project.
- There is no automated test covering the optional Piper Actions branch end to end.

## 4. Zero-cost infrastructure assessment

The renderer itself is cost-safe: it uses local TypeScript, Sharp, bundled FFmpeg, and optional local Piper. It does not require a paid rendering API, database, hosted service, API key, or repository secret. Google Colab is not required for the current pipeline, and the Android-only development workflow can remain GitHub-plus-Manus based.

The main financial risk is the **private GitHub repository’s Actions usage**. Current GitHub documentation says standard hosted runners are independently free for public repositories, but standard hosted runners for private repositories draw from the account’s included compute allowance. GitHub Free currently lists 500 MB of artifact storage, $12 USD of included monthly compute usage, and 10 GB of cache storage per repository. If included compute is exhausted and no valid payment method exists, GitHub blocks further usage rather than silently charging; with a payment method, additional usage can be billed. [1] [2]

The current workflow is reasonably conservative but not risk-free:

- It runs automatically on every push to `main` and every pull request to `main`.
- It uses `ubuntu-latest`, which is the least expensive standard hosted family, but private-repository usage still consumes included compute.
- It has a 20-minute job timeout, which bounds runaway cost.
- Piper is manual-dispatch-only and opt-in, avoiding voice-model setup on ordinary pushes.
- The Piper cache is useful but may be large; GitHub’s default Actions cache limit is 10 GB per repository, with entries unused for over seven days subject to eviction. Exceeding included storage can create charges if billing is enabled. [3]
- The MP4 artifact is retained for 14 days, which is below the documented maximum retention and is appropriate for a temporary render. GitHub Free’s artifact allowance is only 500 MB shared with GitHub Packages, so retention and cleanup should remain deliberate. [1] [4]
- The current workflow does not use concurrency cancellation, so multiple pushes can consume multiple private-run allocations unnecessarily.

The repository is currently private, and the billing endpoint returned HTTP 403 `Resource not accessible by integration`. Therefore the actual remaining allowance cannot be verified from this session. **Do not dispatch the narrated workflow until the owner confirms that the run is within the included/free allowance.** This is a genuine verification blocker, not evidence that the workflow is broken.

Important license/cost observations:

- Motion Canvas packages are MIT.
- Sharp is Apache-2.0.
- Ajv and Vite are MIT.
- The bundled FFmpeg/ffprobe installer packages declare LGPL-2.1; the FFmpeg binary and redistribution obligations should remain documented.
- Inter and Playfair Display font packages declare OFL-1.1.
- Piper is GPL-3.0 according to the current Piper project. The selected `en_US-lessac-medium` voice repository/model card declares MIT for the model package but separately points to the Lessac Blizzard dataset license. Engine, model, and dataset terms must be reviewed before redistributing generated assets or claiming unrestricted commercial rights. [5] [6]
- Music and user-supplied audio remain the owner’s licensing responsibility; the repository currently commits no music asset.

## 5. Recommended architecture

Keep the current architecture rather than rewriting it:

1. Treat the validated normalized brief/timeline as the content contract.
2. Keep `src/design/` as the shared source for tokens, timing, text-fit checks, and prepared layout data.
3. Keep the SVG/Sharp/FFmpeg path as the deterministic CI export route. It is cheaper and more reproducible than browser-driving Motion Canvas in Actions.
4. Keep Motion Canvas as the editable visual preview, but gradually make its scene components consume the same prepared layout model rather than duplicating layout decisions.
5. Keep Piper local and optional. Narration should be generated only when explicitly requested, with user-supplied WAV remaining a first-class route.
6. Add a media manifest and path resolution rule anchored to the brief/repository root so renders are reproducible regardless of the caller’s current directory.
7. Add a final QA manifest containing the brief hash, renderer commit, duration, dimensions, frame rate, codecs, stream presence, and decode result.
8. Add workflow concurrency cancellation and keep automatic CI silent by default. Reserve narrated Piper runs for manual dispatch after allowance confirmation.
9. Do not add a database, MCP server, paid renderer, dashboard, or hosted API at this stage.

## 6. Prioritized continuation roadmap

### Milestone 4A — Cost-safe reproducibility and QA

- Fix or explicitly normalize bundled ffprobe/FFmpeg executable permissions across x64 and ARM64.
- Resolve media paths relative to a defined project/brief root.
- Add a machine-readable render manifest and stronger audio/video synchronization checks.
- Add workflow concurrency cancellation and document the private-repository allowance gate.
- Keep all changes on a new development branch; do not touch `main`.

### Milestone 4B — CI narration proof

Only after the owner confirms the private Actions run is within the included/free allowance:

- Manually dispatch `render-video.yml` for `examples/multi-segment-narrated.json` with `install_piper=true`.
- Verify the run logs, generated AAC stream, duration, full decode, and downloaded artifact.
- Record the run ID and artifact result in the handoff.
- If the allowance is unavailable, stop and retain local Piper as the supported route; do not enable billing or add a payment method.

### Milestone 4C — Visual-system consolidation

- Refactor the Motion Canvas scene to use the same prepared per-layout data used by the renderer.
- Replace the current generic preview card behavior with the six layout-specific preview components.
- Add a small set of deterministic visual snapshot checks or rendered reference frames.

### Milestone 4D — Production usability

- Add brief examples and validation for user WAV, music, captions, and mixed audio.
- Add explicit safe-area and text-fit diagnostics to the CLI.
- Add controlled asset licensing documentation.
- Only after the end-to-end narrated artifact is proven should an MCP/API layer be considered.

## Conclusion

Milestone 3 is substantially implemented and locally verified for the core brief, eight-segment rendering, build, and silent MP4 QA path. It is **not yet fully verified** because the new development branch has no successful GitHub Actions run, and the private repository’s remaining included allowance is inaccessible to this session. The correct next step is not implementation or a workflow dispatch; it is owner confirmation of the free allowance, followed by one manually approved narrated CI run. 

## References

[1]: https://docs.github.com/billing/managing-billing-for-github-actions/about-billing-for-github-actions "GitHub Actions billing"
[2]: https://docs.github.com/en/actions/reference/runners/github-hosted-runners "GitHub-hosted runners reference"
[3]: https://docs.github.com/en/actions/reference/workflows-and-actions/dependency-caching "GitHub Actions dependency caching"
[4]: https://docs.github.com/en/actions/tutorials/store-and-share-data "Store and share data with workflow artifacts"
[5]: https://github.com/OHF-Voice/piper1-gpl "Piper GPL project"
[6]: https://huggingface.co/rhasspy/piper-voices/blob/main/en/en_US/lessac/medium/MODEL_CARD "Piper Lessac medium model card"
