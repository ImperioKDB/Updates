import type {
  CompetitivenessTier,
  EvaluatedRequirement,
  MatchTier,
  MatchableProfile,
  RuleOperator,
  ScholarshipMatch,
  ScholarshipRow,
  ScholarshipRule,
} from "./types";
import { disciplineRequirementMatches } from "./discipline";

// Fields the engine can actually check against the profiles schema (plus
// the derived `age` field, computed from date_of_birth at evaluation time
// so it's never stale). A rule targeting anything else can't be verified
// and is surfaced as such rather than silently ignored or guessed.
const SUPPORTED_FIELDS = new Set([
  "discipline",
  "gpa",
  "nationality",
  "gender",
  "financial_need",
  "age",
  "state_of_origin",
  "lga_of_origin",
  "year_of_study",
  "institution_type",
  "jamb_score",
  "waec_credit_count",
  "has_english_maths_credit",
  "disability_status",
]);

// Fields where NOT meeting the requirement means the student is
// categorically ineligible (not just "less competitive"): citizenship,
// state/LGA-of-origin restrictions, age brackets, gender-restricted awards,
// discipline restrictions, and public-institution-only awards all behave
// this way. Numeric thresholds (GPA, JAMB, WAEC credits, year of study) stay
// non-gating so a near-miss still scores proportionally instead of being
// zeroed out.
const GATING_FIELDS = new Set([
  "discipline",
  "nationality",
  "gender",
  "state_of_origin",
  "lga_of_origin",
  "age",
  "institution_type",
]);

// Boolean fields with a real default (false) rather than "unset" -- missing
// data doesn't apply to these the way it does to nullable text/numeric
// fields.
const BOOLEAN_DEFAULT_FIELDS = new Set([
  "financial_need",
  "disability_status",
  "has_english_maths_credit",
]);

const FIELD_LABELS: Record<string, string> = {
  discipline: "Field of study",
  academic_level: "Study level",
  gpa: "GPA / CGPA",
  nationality: "Nationality",
  gender: "Gender",
  financial_need: "Financial need",
  age: "Age",
  state_of_origin: "State of origin",
  lga_of_origin: "LGA of origin",
  year_of_study: "Year of study",
  institution_type: "Institution type",
  jamb_score: "JAMB / UTME score",
  waec_credit_count: "WAEC/NECO credits",
  has_english_maths_credit: "English & Maths credit",
  disability_status: "Disability status",
};

const INSTITUTION_TYPE_LABELS: Record<string, string> = {
  federal_uni: "Federal University",
  state_uni: "State University",
  private_uni: "Private University",
  polytechnic: "Polytechnic / Monotechnic",
  college_of_education: "College of Education",
};

const ACADEMIC_LEVEL_LABELS: Record<string, string> = {
  undergrad: "undergraduate",
  postgrad: "postgraduate",
  both: "undergraduate or postgraduate",
};

function label(field: string): string {
  return FIELD_LABELS[field] ?? field;
}

// Computes age in whole years as of today from an ISO date string.
function computeAge(dateOfBirth: string): number {
  const dob = new Date(dateOfBirth);
  const now = new Date();
  let age = now.getFullYear() - dob.getFullYear();
  const monthDiff = now.getMonth() - dob.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < dob.getDate())) {
    age -= 1;
  }
  return age;
}

function displayValue(field: string, value: unknown): unknown {
  if (field === "institution_type" && typeof value === "string") {
    return INSTITUTION_TYPE_LABELS[value] ?? value;
  }
  if (field === "academic_level" && typeof value === "string") {
    return ACADEMIC_LEVEL_LABELS[value] ?? value;
  }
  return value;
}

function describeRequirement(field: string, operator: RuleOperator, value: unknown): string {
  const l = label(field);
  const displayed = displayValue(field, value);
  switch (operator) {
    case "eq":
      return `${l} must be ${displayed}`;
    case "gte":
      return `${l} of at least ${displayed}`;
    case "lte":
      return `${l} of at most ${displayed}`;
    case "in": {
      const arr = Array.isArray(value) ? value : [value];
      return `${l} must be one of: ${arr.map((v) => displayValue(field, v)).join(", ")}`;
    }
    case "exists":
      return `${l} must be provided`;
  }
}

function normalizeNationality(value: unknown): string {
  const normalized = String(value).trim().toLowerCase().replace(/\s+/g, " ");
  if (normalized === "nigeria" || normalized === "nigerian" || normalized.includes("nigerian")) {
    return "nigerian";
  }
  return normalized;
}

function valuesMatch(a: unknown, b: unknown, field?: string): boolean {
  if (field === "nationality") {
    return normalizeNationality(a) === normalizeNationality(b);
  }
  return String(a).trim().toLowerCase() === String(b).trim().toLowerCase();
}

const OPEN_DISCIPLINE_VALUES = new Set([
  "all disciplines",
  "any discipline",
  "all fields",
  "any field",
  "open to all disciplines",
  "open to any discipline",
]);

function isOpenDiscipline(value: unknown): boolean {
  return typeof value === "string" && OPEN_DISCIPLINE_VALUES.has(value.trim().toLowerCase());
}

function evaluateOperator(
  operator: RuleOperator,
  profileValue: string | number | boolean,
  ruleValue: unknown,
  field?: string
): boolean {
  switch (operator) {
    case "eq":
      if (typeof profileValue === "boolean") return profileValue === Boolean(ruleValue);
      return valuesMatch(profileValue, ruleValue, field);
    case "gte":
      return Number(profileValue) >= Number(ruleValue);
    case "lte":
      return Number(profileValue) <= Number(ruleValue);
    case "in": {
      const arr = Array.isArray(ruleValue) ? ruleValue : [ruleValue];
      return arr.some((v) => valuesMatch(profileValue, v, field));
    }
    case "exists":
      return profileValue !== null && profileValue !== undefined && profileValue !== "";
  }
}

function evaluateDisciplineOperator(
  operator: RuleOperator,
  profileValue: string,
  ruleValue: unknown
): boolean {
  if (operator === "eq") return disciplineRequirementMatches(profileValue, ruleValue);
  if (operator === "in") {
    const values = Array.isArray(ruleValue) ? ruleValue : [ruleValue];
    return values.some((value) => disciplineRequirementMatches(profileValue, value));
  }
  return evaluateOperator(operator, profileValue, ruleValue);
}

function evaluateRule(
  field: string,
  operator: RuleOperator,
  value: unknown,
  profile: MatchableProfile
): EvaluatedRequirement {
  const requirement = describeRequirement(field, operator, value);
  const gating = GATING_FIELDS.has(field);

  if (!SUPPORTED_FIELDS.has(field)) {
    return {
      field,
      label: label(field),
      operator,
      status: "unverifiable",
      requirement,
      detail:
        field === "academic_level"
          ? "Study level is not tracked in your profile yet -- confirm it on the provider's page."
          : "This detail is not tracked in your profile yet -- verify on the provider's page.",
      gating: false,
    };
  }

  // `age` isn't a stored column -- derive it from date_of_birth so it's
  // never stale, and treat a missing DOB the same as any other missing
  // required field.
  let profileValue: string | number | boolean | null;
  if (field === "age") {
    profileValue = profile.date_of_birth ? computeAge(profile.date_of_birth) : null;
  } else {
    profileValue = (profile as unknown as Record<string, string | number | boolean | null>)[field];
  }

  const isMissing =
    profileValue === null ||
    profileValue === undefined ||
    (typeof profileValue === "string" && profileValue.trim() === "");

  if (isMissing && !BOOLEAN_DEFAULT_FIELDS.has(field)) {
    return {
      field,
      label: label(field),
      operator,
      status: "missing_data",
      requirement,
      detail: `Add your ${label(field).toLowerCase()} to check this.`,
      gating,
    };
  }

  // Scholarship records use “All disciplines” (and equivalent labels) as a
  // wildcard, not as a literal course name. Treat it as met for any student
  // who has supplied a discipline, while keeping normal discipline rules
  // exact and case-insensitive.
  const met =
    field === "discipline" && operator === "eq" && isOpenDiscipline(value)
      ? true
      : field === "discipline"
        ? evaluateDisciplineOperator(operator, String(profileValue), value)
        : evaluateOperator(operator, profileValue as string | number | boolean, value, field);
  const shownValue = displayValue(field, profileValue);

  return {
    field,
    label: label(field),
    operator,
    status: met ? "met" : "not_met",
    requirement,
    detail: met
      ? `Met${profileValue !== null && profileValue !== undefined ? ` (yours: ${shownValue})` : ""}`
      : `Not met${profileValue !== null && profileValue !== undefined ? ` (yours: ${shownValue})` : ""}`,
    gating,
  };
}

// scholarships.discipline is a first-class column (coarse filter), separate
// from the finer-grained scholarship_rules table. Fold it into the same
// evaluation so the UI shows one consistent list. `level` is no longer
// folded in here -- the platform is undergrad-only now, so postgrad-only
// scholarships are filtered out entirely before they reach the engine (see
// lib/matching/getMatches.ts), rather than being scored and gated.
function implicitRules(scholarship: ScholarshipRow): ScholarshipRule[] {
  const rules: ScholarshipRule[] = [];

  if (scholarship.discipline) {
    rules.push({
      id: `implicit-discipline-${scholarship.id}`,
      scholarship_id: scholarship.id,
      field: "discipline",
      operator: "eq",
      value: scholarship.discipline,
    });
  }

  return rules;
}

// Exported so lib/matching/gaps.ts can re-derive a hypothetical tier when
// simulating "what if this missing field were filled in" -- keeps the tier
// thresholds defined in exactly one place instead of being duplicated.
export function tierFor(score: number, gatingFailed: boolean): MatchTier {
  if (gatingFailed) return "unlikely";
  if (score >= 85) return "excellent";
  if (score >= 65) return "good";
  if (score >= 40) return "possible";
  return "unlikely";
}

// --- Competitiveness ---------------------------------------------------
//
// Layered on top of the pure eligibility score below, never folded into
// it. Eligibility answers "can you apply"; competitiveness answers "how
// likely are you to actually win" -- an eligible student for a 5-spot,
// 20,000-applicant award shouldn't see the same confidence signal as one
// for a 200-spot award with light competition. See
// migration: add_competitiveness_fields.
//
// Deliberately floored at 0.5, never lower: competitiveness makes an
// eligible student's realistic chances lower, it never makes them
// ineligible -- that's what gating fields (see GATING_FIELDS above) are
// for. Missing/unresearched competitiveness data is never penalized --
// factor defaults to 1.0 (no discount), same "unknown isn't guessed at"
// principle SUPPORTED_FIELDS already applies to eligibility rules.
const COMPETITIVENESS_FACTOR_FLOOR = 0.5;

const TIER_FACTORS: Record<CompetitivenessTier, number> = {
  low: 1.0,
  medium: 0.85,
  high: 0.7,
  very_high: 0.55,
};

function computeCompetitivenessFactor(scholarship: ScholarshipRow): number {
  let factor = 1.0;
  const headroom = 1 - COMPETITIVENESS_FACTOR_FLOOR; // 0.5

  if (
    scholarship.awards_available !== null &&
    scholarship.estimated_applicant_pool !== null &&
    scholarship.estimated_applicant_pool > 0
  ) {
    // A wide-open award (roughly 1-in-2 odds or better) gets no discount
    // at all. As the ratio shrinks toward zero the factor eases down
    // toward the floor instead of collapsing linearly past it, so a
    // merely-competitive award (say 1-in-10) isn't treated the same as a
    // 1-in-10,000 long shot.
    const ratio = scholarship.awards_available / scholarship.estimated_applicant_pool;
    factor = COMPETITIVENESS_FACTOR_FLOOR + Math.min(ratio, headroom);
  } else if (scholarship.competitiveness_tier) {
    factor = TIER_FACTORS[scholarship.competitiveness_tier];
  }

  // Historical acceptance rate is the most concrete signal available when
  // known -- if it implies a harsher discount than the ratio/tier estimate
  // above, defer to it (take the more conservative of the two rather than
  // averaging them away).
  if (scholarship.historical_acceptance_rate !== null) {
    const historicalFactor = COMPETITIVENESS_FACTOR_FLOOR + scholarship.historical_acceptance_rate * headroom;
    factor = Math.min(factor, historicalFactor);
  }

  return Math.max(COMPETITIVENESS_FACTOR_FLOOR, Math.min(1.0, factor));
}

export function evaluateScholarship(
  profile: MatchableProfile,
  scholarship: ScholarshipRow,
  explicitRules: ScholarshipRule[]
): ScholarshipMatch {
  const allRules = [...implicitRules(scholarship), ...explicitRules];

  const requirements = allRules.map((r) => evaluateRule(r.field, r.operator, r.value, profile));

  const evaluable = requirements.filter((r) => r.status !== "unverifiable");
  const gatingFailed = requirements.some((r) => r.gating && r.status === "not_met");

  let eligibilityScore: number;
  if (evaluable.length === 0) {
    eligibilityScore = 50; // no rules defined yet to check against -- neutral, not zero
  } else {
    const metCount = evaluable.filter((r) => r.status === "met").length;
    eligibilityScore = Math.round((metCount / evaluable.length) * 100);
  }
  if (gatingFailed) eligibilityScore = Math.min(eligibilityScore, 15);

  const competitivenessFactor = computeCompetitivenessFactor(scholarship);

  // A gating failure has already collapsed eligibilityScore down near
  // zero -- there's nothing meaningful left to discount, and multiplying
  // a competitiveness factor through it would just produce a confusing
  // fractional single-digit number. Competitiveness only discounts a
  // score that's actually reflecting real eligibility.
  const score = gatingFailed ? eligibilityScore : Math.round(eligibilityScore * competitivenessFactor);

  const rankScore = Math.round(score * 0.85 + profile.profile_completeness * 0.15);

  return {
    ...scholarship,
    score,
    eligibilityScore,
    competitivenessFactor,
    rankScore,
    tier: tierFor(score, gatingFailed),
    requirements,
    missingProfileFields: requirements.filter((r) => r.status === "missing_data"),
    unverifiable: requirements.filter((r) => r.status === "unverifiable"),
  };
}

export function rankScholarships(
  profile: MatchableProfile,
  scholarships: ScholarshipRow[],
  rulesByScholarship: Map<string, ScholarshipRule[]>
): ScholarshipMatch[] {
  return scholarships
    .map((s) => evaluateScholarship(profile, s, rulesByScholarship.get(s.id) ?? []))
    .sort((a, b) => {
      if (b.rankScore !== a.rankScore) return b.rankScore - a.rankScore;
      if (!a.deadline) return 1;
      if (!b.deadline) return -1;
      return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
    });
}
