// lib/email/digest.ts
// New-listing digest, invoked only by the explicit admin action
// (app/api/admin/digest/route.ts). The shared sender rejects non-manual calls.
//
// Semantics:
//   - Collect every verified scholarship (undergrad or both) and every
//     verified opportunity created in the last DIGEST_WINDOW_DAYS days.
//   - Per student, skip listings already present in announcement_log, using
//     the full history so a previously sent listing is never re-announced.
//   - Send only the newest pending listing, rather than bundling a backlog
//     of older listings into a student email.
//   - minIntervalMs is the per-student re-blast throttle. The admin button
//     passes 0 because the admin may have just added listings. Listing-level
//     dedupe prevents previously announced listings from being resent.
//   - Record every pending listing in announcement_log after a successful
//     send (or a dry run), so stale pending listings do not return later.
import { createServiceClient } from '@/lib/supabase/service'
import { logError } from '@/lib/logging'
import { renderNewListingsDigest, type EmailListing } from '@/lib/email/template'
import { sendEmail } from '@/lib/email/send'
import { firstName, getAuthEmailsByUserId } from '@/lib/email/authRecipients'
import { claimNotificationDelivery, markNotificationAccepted, markNotificationRetryable } from '@/lib/email/outbox'
import { selectEmailBatch, type EmailBatch } from '@/lib/email/batches'

export const DIGEST_WINDOW_DAYS = 7
export const DIGEST_CAP = 1

const KIND_LABELS: Record<string, string> = {
  fellowship: 'Fellowship',
  internship: 'Internship',
  competition: 'Competition',
  mentorship: 'Mentorship',
}

export type DigestSummary = {
  students_emailed: number
  emails_sent: number
  listings_announced: number
  failed: number
  dry_run: boolean
}

export async function runNewListingDigest(opts: { minIntervalMs?: number; manual?: boolean; batch?: EmailBatch } = {}): Promise<DigestSummary> {
  const minIntervalMs = opts.minIntervalMs ?? 0
  const manual = opts.manual ?? false
  const supabase = createServiceClient()
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://www.scholars.com.ng'
  const summary: DigestSummary = {
    students_emailed: 0,
    emails_sent: 0,
    listings_announced: 0,
    failed: 0,
    dry_run: !process.env.BREVO_API_KEY || !process.env.REMINDER_FROM_EMAIL,
  }
  try {
    const since = new Date(Date.now() - DIGEST_WINDOW_DAYS * 86400000).toISOString()
    const now = Date.now()
    const [{ data: profiles }, { data: newSch }, { data: newOpp }, { data: logRows }] = await Promise.all([
      supabase.from('profiles').select('id,full_name'),
      supabase
        .from('scholarships')
        .select('id,title,provider_name,amount,deadline,created_at')
        .eq('verified', true)
        .in('level', ['undergrad', 'both'])
        .gte('created_at', since),
      supabase
        .from('opportunities')
        .select('id,type,title,provider_name,compensation,deadline,created_at')
        .eq('verified', true)
        .gte('created_at', since),
      // This is deliberately not limited to the recent window: a listing
      // sent in the past must never be included again.
      supabase
        .from('announcement_log')
        .select('profile_id,listing_kind,listing_id,created_at')
        .limit(100000),
    ])
    const announced = new Set(
      (logRows ?? []).map((r) => `${r.profile_id}:${r.listing_kind}:${r.listing_id}`)
    )
    const profileRows = selectEmailBatch(
      ([...(profiles ?? [])] as { id: string; full_name: string | null }[]).sort((a, b) => a.id.localeCompare(b.id)),
      opts.batch,
    )
    const emailById = await getAuthEmailsByUserId(supabase, profileRows.map((p) => p.id))
    const lastDigestAt = new Map<string, number>()
    for (const r of logRows ?? []) {
      const t = Date.parse(r.created_at)
      const prev = lastDigestAt.get(r.profile_id) ?? 0
      if (t > prev) lastDigestAt.set(r.profile_id, t)
    }
    const schList = (newSch ?? []) as { id: string; title: string; provider_name: string; amount: string | null; deadline: string | null; created_at: string }[]
    const oppList = (newOpp ?? []) as { id: string; type: string; title: string; provider_name: string; compensation: string | null; deadline: string | null; created_at: string }[]
    for (const p of profileRows) {
      const email = emailById.get(p.id)
      if (!email) {
        logError('email/digest', 'no_email_for_profile', { profile: p.id })
        continue
      }
      const last = lastDigestAt.get(p.id)
      if (minIntervalMs > 0 && last && now - last < minIntervalMs) continue
      const pendingSch = schList.filter((s) => !announced.has(`${p.id}:scholarship:${s.id}`))
      const pendingOpp = oppList.filter((o) => !announced.has(`${p.id}:opportunity:${o.id}`))
      const pending = [
        ...pendingSch.map((s) => ({ created_at: s.created_at, listing: {
          id: s.id,
          title: s.title,
          provider_name: s.provider_name,
          amount: s.amount,
          deadline: s.deadline,
          kind_label: 'Scholarship',
          url: `${baseUrl}/scholarships/${s.id}`,
        } })),
        ...pendingOpp.map((o) => ({ created_at: o.created_at, listing: {
          id: o.id,
          title: o.title,
          provider_name: o.provider_name,
          amount: o.compensation,
          deadline: o.deadline,
          kind_label: KIND_LABELS[o.type] ?? 'Opportunity',
          url: `${baseUrl}/opportunities/${o.id}`,
        } })),
      ]
      if (pending.length === 0) continue
      pending.sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at))
      const shown: EmailListing[] = [pending[0].listing]
      const moreCount = 0
      const { subject, html, text } = renderNewListingsDigest({
        firstName: firstName(p.full_name),
        items: shown,
        moreCount,
        baseUrl,
      })
      const logInsert = [
        ...pendingSch.map((s) => ({ profile_id: p.id, listing_kind: 'scholarship', listing_id: s.id })),
        ...pendingOpp.map((o) => ({ profile_id: p.id, listing_kind: 'opportunity', listing_id: o.id })),
      ]
      const pendingKey = logInsert.map((item) => `${item.listing_kind}:${item.listing_id}`).join('|')
      let deliveryId: string | null = null
      try {
        const delivery = await claimNotificationDelivery(supabase, {
          profileId: p.id,
          campaignKey: 'new_listing_digest',
          scheduleBucket: 'new-listings',
          dedupeKey: `new_listing_digest:${p.id}:${pendingKey}`,
          templateVersion: 'new-listing-digest-v1',
        })
        if (!delivery) continue
        deliveryId = delivery.id
        const res = await sendEmail({ to: email, subject, html, text, manual })
        summary.emails_sent += res.sent
        if (res.dry) summary.dry_run = true
        await markNotificationAccepted(supabase, delivery.id)
        const { error: announcementError } = await supabase.from('announcement_log').insert(logInsert)
        if (announcementError) {
          logError('email/digest', 'announcement_log_write_failed_after_send', { profile: p.id }, announcementError)
        }
        summary.students_emailed += 1
        summary.listings_announced += logInsert.length
      } catch (err) {
        summary.failed += 1
        if (deliveryId) {
          await markNotificationRetryable(supabase, deliveryId, err).catch(() => {})
        }
        logError('email/digest', 'digest_send_failed', { profile: p.id }, err)
      }
    }
  } catch (err) {
    summary.failed += 1
    logError('email/digest', 'digest_failed', undefined, err)
  }
  return summary
}
