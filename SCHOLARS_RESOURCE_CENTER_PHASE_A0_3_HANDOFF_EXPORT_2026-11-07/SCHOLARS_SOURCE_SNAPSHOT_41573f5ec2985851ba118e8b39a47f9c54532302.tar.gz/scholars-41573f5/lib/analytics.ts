// lib/analytics.ts
// Fire-and-forget product analytics (Phase 1). Never awaited, never
// blocks a flow, swallows every error: a failed track call must never
// surface to a student or break an action. keepalive lets the request
// survive navigation (e.g. tapping a gap nudge leaves the dashboard).
//
// Keep the EventName union in sync with the zod enum in
// app/api/events/route.ts and the latest events_event_whitelist migration.
// The DB constraint is the backstop if they drift.
export type EventName =
  | "page_viewed"
  | "web_vital"
  | "client_error"
  | "button_clicked"
  | "weekly_focus_viewed"
  | "weekly_focus_actioned"
  | "onboarding_step_completed"
  | "onboarding_abandoned"
  | "scholarship_issue_reported"
  | "outcome_recorded"
  | "onboarding_step_viewed"
  | "provisional_matches_viewed"
  | "match_viewed"
  | "scholarship_saved"
  | "application_started"
  | "provider_clicked"
  | "application_status_changed"
  | "draft_generated"
  | "draft_confirmed"
  | "gap_nudge_clicked"
  | "whatsapp_opt_in"
  | "whatsapp_opt_out"
  | "community_post_created"
  | "community_reply_created"
  | "community_helpful_reaction"
  | "community_reported";
export type EventMeta = Record<string, string | number | boolean>;
export function track(event: EventName, meta?: EventMeta): void {
  if (typeof window === "undefined") return;
  try {
    void fetch("/api/events", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ event, meta: meta ?? {} }),
      keepalive: true,
    }).catch(() => {});
  } catch {
    // analytics must never throw
  }
}
