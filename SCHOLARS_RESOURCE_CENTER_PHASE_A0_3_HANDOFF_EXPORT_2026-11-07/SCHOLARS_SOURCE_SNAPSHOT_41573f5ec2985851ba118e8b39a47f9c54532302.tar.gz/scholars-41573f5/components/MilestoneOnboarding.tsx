"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { track } from "@/lib/analytics";
import { useSpringValue } from "@/lib/motion/useSpring";

type MilestoneId = "welcome_tour" | "discover_tip" | "saved_tip" | "application_tip";
type Context = "dashboard" | "discover" | "applications";
type TargetRect = { top: number; left: number; width: number; height: number };

type TourStep = {
  id: string;
  title: string;
  body: string;
  target?: string;
  action: string;
};

const STORAGE_KEY_PREFIX = "scholars.onboarding.milestones.v1";
const MILESTONE_EVENT = "scholars:milestone";
const DASHBOARD_TOUR_READY_EVENT = "scholars:dashboard-tour-ready";

const DASHBOARD_STEPS: TourStep[] = [
  {
    id: "welcome",
    title: "Welcome to Scholars",
    body: "Find verified scholarships and opportunities that fit your background, then keep every next step in one place.",
    action: "Next",
  },
  {
    id: "profile",
    title: "Start with your profile",
    body: "A few details about your course, school, and year help Scholars surface opportunities you can realistically pursue.",
    target: "profile",
    action: "Next",
  },
  {
    id: "matches",
    title: "Read your match score",
    body: "Each score is a quick signal of how closely an opportunity fits the information in your profile. Complete more fields to make it sharper.",
    target: "matches",
    action: "Next",
  },
  {
    id: "save",
    title: "Build a shortlist",
    body: "Save anything worth a closer look. Your saved opportunities stay together while you prepare documents and compare deadlines.",
    target: "save",
    action: "Next",
  },
  {
    id: "ready",
    title: "You are ready",
    body: "Complete your profile, open a match, and save one opportunity. That is the fastest way to get value from Scholars today.",
    action: "Find my opportunities",
  },
];

const CONTEXT_STEPS: Record<Context, TourStep> = {
  discover: {
    id: "discover_tip",
    title: "Explore the full catalog",
    body: "Browse every verified listing here. Your dashboard is where personalized eligibility scores and your strongest matches live.",
    target: "scholarships-list",
    action: "Got it",
  },
  applications: {
    id: "application_tip",
    title: "Keep the next step visible",
    body: "When you track an application, you can update its status, prepare materials, and return to the provider link before the deadline.",
    target: "applications-list",
    action: "Got it",
  },
  dashboard: {
    id: "saved_tip",
    title: "Your shortlist is ready",
    body: "You can find this opportunity again in Saved. Use it as your working list while you decide what to apply for.",
    target: "saved",
    action: "Got it",
  },
};

function storageKey(userId: string) {
  return `${STORAGE_KEY_PREFIX}:${userId}`;
}

function readState(userId: string): Partial<Record<MilestoneId, boolean>> {
  if (typeof window === "undefined") return {};
  try {
    const value = JSON.parse(window.localStorage.getItem(storageKey(userId)) ?? "{}");
    return value && typeof value === "object" ? value : {};
  } catch {
    return {};
  }
}

function writeState(userId: string, state: Partial<Record<MilestoneId, boolean>>) {
  try {
    window.localStorage.setItem(storageKey(userId), JSON.stringify(state));
  } catch {
    // Onboarding remains usable when storage is blocked.
  }
}

export function announceMilestone(milestone: Exclude<MilestoneId, "welcome_tour">) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(MILESTONE_EVENT, { detail: milestone }));
}

function getTargetElement(target?: string): Element | null {
  if (!target || typeof document === "undefined") return null;
  return document.querySelector(`[data-tour="${target}"]`);
}

function getTargetRect(target?: string): TargetRect | null {
  if (!target || typeof document === "undefined") return null;
  const element = getTargetElement(target);
  if (!element || !element.isConnected) return null;
  const rect = element.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) return null;
  return { top: rect.top, left: rect.left, width: rect.width, height: rect.height };
}

export function MilestoneOnboarding({ context, userId }: { context: Context; userId: string }) {
  const router = useRouter();
  const [state, setState] = useState<Partial<Record<MilestoneId, boolean>>>({});
  const [tourIndex, setTourIndex] = useState<number | null>(null);
  const [contextStep, setContextStep] = useState<TourStep | null>(null);
  const [targetRect, setTargetRect] = useState<TargetRect | null>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const spotlightRef = useRef<HTMLDivElement>(null);
  const transitionTimerRef = useRef<number | null>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const dashboardTour = context === "dashboard" ? DASHBOARD_STEPS : [];
  const activeStep = contextStep ?? (tourIndex === null ? null : dashboardTour[tourIndex]);
  const isDashboardTour = contextStep === null && tourIndex !== null;
  const stepCount = dashboardTour.length;

  useEffect(() => {
    const initial = readState(userId);
    setState(initial);
    if (context === "dashboard" && !initial.welcome_tour) {
      setTourIndex(0);
    } else if (context === "discover" && !initial.discover_tip) {
      setContextStep(CONTEXT_STEPS.discover);
    }

    function handleMilestone(event: Event) {
      const milestone = (event as CustomEvent<Exclude<MilestoneId, "welcome_tour">>).detail;
      if (milestone !== "saved_tip" && milestone !== "application_tip") return;
      const latest = readState(userId);
      if (latest[milestone] || (context === "dashboard" && tourIndex !== null)) return;
      setContextStep(CONTEXT_STEPS[context]);
    }

    window.addEventListener(MILESTONE_EVENT, handleMilestone);
    return () => window.removeEventListener(MILESTONE_EVENT, handleMilestone);
    // The listener intentionally reads the state at event time.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [context, userId]);

  useEffect(() => {
    if (!activeStep) return;
    const target = getTargetElement(activeStep.target);
    if (!target) return;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    target.scrollIntoView({
      behavior: reduceMotion ? "auto" : "smooth",
      block: "center",
      inline: "nearest",
    });
  }, [activeStep?.id]);

  useEffect(() => {
    if (!activeStep) {
      setTargetRect(null);
      return;
    }
    let frame = 0;
    const update = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => setTargetRect(getTargetRect(activeStep.target)));
    };
    update();
    const target = getTargetElement(activeStep.target);
    const observer = typeof ResizeObserver === "undefined" || !target ? null : new ResizeObserver(update);
    if (observer && target) observer.observe(target);
    window.addEventListener("resize", update);
    window.addEventListener("scroll", update, true);
    return () => {
      cancelAnimationFrame(frame);
      observer?.disconnect();
      window.removeEventListener("resize", update);
      window.removeEventListener("scroll", update, true);
    };
  }, [activeStep]);

  const spotlightTop = targetRect ? targetRect.top - 8 : 0;
  const spotlightLeft = targetRect ? targetRect.left - 8 : 0;
  const spotlightWidth = targetRect ? targetRect.width + 16 : 0;
  const spotlightHeight = targetRect ? targetRect.height + 16 : 0;
  useSpringValue(spotlightTop, (value) => spotlightRef.current?.style.setProperty("--tour-top", `${value}px`));
  useSpringValue(spotlightLeft, (value) => spotlightRef.current?.style.setProperty("--tour-left", `${value}px`));
  useSpringValue(spotlightWidth, (value) => spotlightRef.current?.style.setProperty("--tour-width", `${value}px`));
  useSpringValue(spotlightHeight, (value) => spotlightRef.current?.style.setProperty("--tour-height", `${value}px`));
  useEffect(() => {
    if (spotlightRef.current) spotlightRef.current.style.opacity = targetRect ? "1" : "0";
  }, [targetRect]);

  useEffect(() => {
    if (!activeStep) return;
    const index = isDashboardTour ? tourIndex ?? 0 : 0;
    track("onboarding_step_viewed", { step: index, label: activeStep.id, path: "milestone" });
  }, [activeStep, isDashboardTour, tourIndex]);

  useEffect(() => {
    if (!activeStep) return;
    headingRef.current?.focus({ preventScroll: true });
  }, [activeStep?.id]);

  useEffect(() => {
    if (!activeStep) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      if (isDashboardTour) skip();
      else finishContextStep();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
    // The active step is the only value that needs to rebind the escape action.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeStep?.id, isDashboardTour]);

  useEffect(() => () => {
    if (transitionTimerRef.current !== null) window.clearTimeout(transitionTimerRef.current);
  }, []);

  const tooltipStyle = useMemo(() => {
    if (!targetRect) {
      return { top: "50%", left: "50%", transform: "translate(-50%, -50%)" } as const;
    }
    const cardHeight = 220;
    const top = targetRect.top + targetRect.height + 18 + cardHeight < window.innerHeight
      ? targetRect.top + targetRect.height + 18
      : Math.max(18, targetRect.top - cardHeight - 18);
    const left = Math.min(Math.max(16, targetRect.left), Math.max(16, window.innerWidth - 380));
    return { top, left, transform: "none" } as const;
  }, [targetRect]);

  if (!activeStep) return null;

  function finishContextStep() {
    const id = activeStep?.id;
    if (!id || id === "welcome" || id === "profile" || id === "matches" || id === "save" || id === "ready") return;
    const next = { ...state, [id]: true };
    setState(next);
    writeState(userId, next);
    setContextStep(null);
    track("onboarding_step_completed", { step: 0, label: id, path: "milestone" });
  }

  function finishDashboardTour() {
    const next = { ...state, welcome_tour: true };
    setState(next);
    writeState(userId, next);
    setTourIndex(null);
    window.dispatchEvent(new Event(DASHBOARD_TOUR_READY_EVENT));
    track("onboarding_step_completed", { step: tourIndex ?? 0, label: activeStep?.id ?? "ready", path: "milestone" });
    if (activeStep?.id === "ready") router.push("/discover");
  }

  function next() {
    if (isTransitioning) return;
    if (contextStep) {
      finishContextStep();
      return;
    }
    if (tourIndex === null) return;
    if (tourIndex >= stepCount - 1) {
      finishDashboardTour();
      return;
    }
    track("onboarding_step_completed", { step: tourIndex, label: activeStep?.id ?? "unknown", path: "milestone" });
    setIsTransitioning(true);
    setTourIndex((index) => (index === null ? null : index + 1));
    transitionTimerRef.current = window.setTimeout(() => setIsTransitioning(false), 280);
  }

  function skip() {
    const nextState = { ...state, welcome_tour: true };
    setState(nextState);
    writeState(userId, nextState);
    setTourIndex(null);
    window.dispatchEvent(new Event(DASHBOARD_TOUR_READY_EVENT));
    track("onboarding_abandoned", { step: tourIndex ?? 0, label: activeStep?.id ?? "unknown", reason: "skip_milestone_tour" });
  }

  return (
    <div className="tour-shell fixed inset-0 z-[90]" role="presentation">
      {targetRect ? (
        <div
          ref={spotlightRef}
          className="tour-spotlight absolute rounded-2xl border-2 border-white/90 shadow-[0_0_0_9999px_rgba(11,30,61,0.7)]"
          aria-hidden="true"
        />
      ) : (
        <div className="tour-backdrop absolute inset-0 bg-navy/70" aria-hidden="true" />
      )}
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="milestone-onboarding-title"
        className="tour-card absolute w-[calc(100%-2rem)] max-w-[360px] rounded-2xl border border-white/20 bg-white p-5 text-ink shadow-2xl"
        style={tooltipStyle}
      >
        <div key={activeStep.id} className="tour-card-content">
          <div className="mb-4 flex items-start justify-between gap-4">
            <div>
              {isDashboardTour && <p className="mb-1 text-xs font-semibold uppercase tracking-[0.14em] text-emerald">{(tourIndex ?? 0) + 1} of {stepCount}</p>}
              <h2 ref={headingRef} tabIndex={-1} id="milestone-onboarding-title" className="font-display text-xl font-semibold leading-tight text-navy outline-none">{activeStep.title}</h2>
            </div>
            {isDashboardTour && <button type="button" onClick={skip} className="min-h-[44px] shrink-0 px-1 text-xs font-medium text-navy-light underline underline-offset-2">Skip tour</button>}
          </div>
          <p className="text-sm leading-6 text-navy-light">{activeStep.body}</p>
          <div className="mt-5 flex items-center justify-between gap-3">
            {!isDashboardTour ? <span className="text-xs text-navy-light">You can revisit this anytime.</span> : <span />}
            <button type="button" onClick={next} disabled={isTransitioning} className="inline-flex min-h-[44px] items-center justify-center rounded-seal bg-navy px-5 py-2.5 text-sm font-medium text-white hover:bg-navy-light disabled:cursor-wait disabled:opacity-70">{activeStep.action}</button>
          </div>
        </div>
      </div>
    </div>
  );
}
