"use client";
import { useLayoutEffect, useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Logo } from "@/components/Logo";
import { safeNextPath } from "@/lib/validate";
import { getAuthCookieDomain } from "@/lib/auth/cookie-domain";

// components/AuthRescue.tsx
//
// Self-healing safety net for auth redirects. When Supabase rejects a
// redirectTo (allowlist drift, domain changes), it falls back to the Site
// URL root and strands the auth code / recovery token on the marketing
// page. That used to paint the whole landing page for a beat before
// routing on, which testers read as "it sent me to the homepage".
//
// FLASH FIX: the token check now runs in useLayoutEffect and raises a
// full-screen parchment splash BEFORE the browser paints, so the
// marketing page is never visible during a rescue. The splash stays up
// until the session event routes us, or a 4s timeout gives up and cleans
// the dead tokens out of the address bar.
//
// Mounted in the root layout, this watches the ROOT PATH ONLY.
//   PASSWORD_RECOVERY -> /reset-password/update (handoff via sessionStorage)
//   SIGNED_IN         -> /dashboard
export const RECOVERY_REDIRECT_FLAG = "scholars.recovery_redirect";
export const AUTH_NEXT_COOKIE = "scholars_auth_next";

function readAuthNext(url: URL): string {
  let cookieValue = "";
  try {
    cookieValue = document.cookie
      .split("; ")
      .find((part) => part.startsWith(`${AUTH_NEXT_COOKIE}=`))
      ?.split("=")[1] ?? "";
  } catch {
    // Ignore blocked cookie access and use the URL/default below.
  }
  let decodedCookie = "";
  try {
    decodedCookie = decodeURIComponent(cookieValue);
  } catch {
    // Ignore malformed cookie values; safeNextPath will use the default.
  }
  return safeNextPath(url.searchParams.get("next") || decodedCookie, "/dashboard");
}

function clearAuthNext() {
  try {
    const domain = getAuthCookieDomain(window.location.hostname);
    const domainAttribute = domain ? `; Domain=${domain}` : "";
    const secureAttribute = window.location.protocol === "https:" ? "; Secure" : "";
    document.cookie = `${AUTH_NEXT_COOKIE}=; Max-Age=0; Path=/; SameSite=Lax${domainAttribute}${secureAttribute}`;
  } catch {
    // Ignore blocked cookie access.
  }
}

export function AuthRescue() {
  const pathname = usePathname();
  const router = useRouter();
  const handled = useRef(false);
  const [rescuing, setRescuing] = useState(false);

  // useLayoutEffect + setState here re-renders synchronously before
  // paint, so the splash covers the landing on the very first frame.
  useLayoutEffect(() => {
    if (pathname !== "/" || handled.current) return;
    const url = new URL(window.location.href);
    const hasTokens = url.searchParams.has("code") || url.hash.includes("access_token=");
    if (!hasTokens) return;
    handled.current = true;
    setRescuing(true);
  }, [pathname]);

  useEffect(() => {
    if (!rescuing) return;
    let routed = false;
    const url = new URL(window.location.href);
    const authNext = readAuthNext(url);
    const code = url.searchParams.get("code");
    if (code) {
      // Supabase's SSR cookie bridge owns the PKCE verifier. Send rescued
      // codes through the same server callback as the normal flow so it can
      // exchange the code using the verifier cookie, including in PWAs.
      const callbackUrl = new URL("/auth/callback", url.origin);
      callbackUrl.searchParams.set("code", code);
      callbackUrl.searchParams.set("next", authNext);
      window.location.replace(callbackUrl.toString());
      return;
    }
    const supabase = createClient();
    const routeTo = (path: string) => {
      if (routed) return;
      routed = true;
      clearAuthNext();
      router.replace(path);
    };
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") {
        try {
          sessionStorage.setItem(RECOVERY_REDIRECT_FLAG, "1");
        } catch {
          // storage blocked -- the update page also listens for the event
        }
        routeTo("/reset-password/update");
      } else if (event === "SIGNED_IN") {
        routeTo(authNext);
      }
    });
    void (async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session) routeTo(authNext);
    })();
    // Exchange failed or never fired (expired code, revoked session):
    // drop the splash and strip the dead tokens so the landing renders
    // cleanly.
    const t = setTimeout(() => {
      if (!routed) {
        setRescuing(false);
        window.history.replaceState(null, "", "/");
      }
    }, 4000);
    return () => {
      sub.subscription.unsubscribe();
      clearTimeout(t);
    };
  }, [rescuing, router]);

  if (!rescuing) return null;
  return (
    <div
      className="fixed inset-0 z-[99] bg-parchment flex flex-col items-center justify-center gap-4"
      role="status"
      aria-live="polite"
    >
      <Logo className="text-navy" />
      <p className="text-sm text-navy-light">Signing you in&hellip;</p>
      <svg className="animate-spin h-5 w-5 text-navy-light" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
      </svg>
    </div>
  );
}
