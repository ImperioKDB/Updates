"use client";
import { StatusMessage } from "@/components/StatusMessage";
import { useState } from "react";
import { useAde } from "@/components/ade/AdeProvider";
import { Spinner } from "@/components/ScholarshipCard";
import { fetchWithTimeout } from "@/lib/fetch";

// components/DraftPanel.tsx
//
// Review-and-confirm UI for an auto-generated application draft. Lives
// inside a single application card in ApplicationsClient.tsx.
//
// This never submits anything anywhere -- "Confirm & use this draft" only
// timestamps that the student has reviewed it. The real next step is
// copying the statement + summary into the scholarship's own
// application_url, which is why that link sits right next to the confirm
// button rather than being buried elsewhere on the card.
//
// "Open real application" routes through useAde().confirmApply() instead of
// a bare <a href> -- this application is always already tracked, so it
// takes the alreadyTracked branch: record the /click timestamp, then open
// the tab. Without this, Ade never learns the student left for the
// provider's site and the post-deadline check-in has nothing to key off.
//
// AUDIT FIX (P5): character count below the textarea (limit 6000, matching
// patchSchema in /api/applications/[id]/draft/route.ts).
// FINAL CLEANUP: generate/save routed through fetchWithTimeout so a hung
// Gemini call or backend can't freeze the panel indefinitely.
//
// PHASE 4 OUTCOME: "Download packet (.txt)" bundles the statement + facts
// + checklist into a single plain-text file the student can keep, email
// to a recommender, or paste into any provider portal that accepts a
// text upload. No cloud dependency, no format surprises.
export type Draft = {
  draft_statement: string | null;
  draft_summary: {
    facts: { label: string; value: string }[];
    checklist: { item: string; have: boolean }[];
  } | null;
  draft_generated_at: string | null;
  draft_confirmed_at: string | null;
};

const STATEMENT_MAX_CHARS = 6000;

export function DraftPanel({
  applicationId,
  scholarshipTitle,
  draft,
  applicationUrl,
  onDraftChange,
}: {
  applicationId: string;
  scholarshipTitle: string;
  draft: Draft;
  applicationUrl: string | null;
  onDraftChange: (draft: Draft) => void;
}) {
  const { confirmApply } = useAde();
  const [open, setOpen] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [statement, setStatement] = useState(draft.draft_statement ?? "");
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const hasDraft = Boolean(draft.draft_generated_at);
  const confirmed = Boolean(draft.draft_confirmed_at);
  const dirty = statement !== (draft.draft_statement ?? "");
  const overLimit = statement.length > STATEMENT_MAX_CHARS;

  async function generate() {
    setGenerating(true);
    setError(null);
    try {
      const res = await fetchWithTimeout(`/api/applications/${applicationId}/draft`, { method: "POST", timeoutMs: 30_000 });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        setError(body.error ?? "Couldn't generate a draft. Try again.");
        return;
      }
      const { draft: updated } = await res.json();
      setStatement(updated.draft_statement ?? "");
      onDraftChange(updated);
      setOpen(true);
    } catch {
      setError("Couldn't reach the draft service. Check your connection and try again.");
    } finally {
      setGenerating(false);
    }
  }

  async function save(confirm: boolean) {
    if (overLimit) {
      setError(`Statement is ${statement.length - STATEMENT_MAX_CHARS} characters over the limit.`);
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const res = await fetchWithTimeout(`/api/applications/${applicationId}/draft`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ draft_statement: statement, confirm }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        setError(body.error ?? "Couldn't save your changes.");
        return;
      }
      const { draft: updated } = await res.json();
      onDraftChange(updated);
    } catch {
      setError("Couldn't save your changes. Check your connection and try again.");
    } finally {
      setSaving(false);
    }
  }

  async function copyAll() {
    const facts = draft.draft_summary?.facts.map((f) => `${f.label}: ${f.value}`).join("\n") ?? "";
    const text = `${statement}\n\n---\nApplication summary\n${facts}`;
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  // Phase 4 outcome: download the draft + summary + checklist as a
  // single .txt file. Filename is slugified from the scholarship title
  // so a student tracking several awards gets files that don't collide.
  function downloadPacket() {
    const facts = draft.draft_summary?.facts.map((f) => `${f.label}: ${f.value}`).join("\n") ?? "";
    const checklist = draft.draft_summary?.checklist
      .map((c) => `${c.have ? "[x]" : "[ ]"} ${c.item}`)
      .join("\n") ?? "";
    const body = [
      `Application draft: ${scholarshipTitle}`,
      `Generated: ${draft.draft_generated_at ?? "unknown"}`,
      `Status: ${confirmed ? "confirmed by student" : "needs review"}`,
      "",
      "=== PERSONAL STATEMENT ===",
      "",
      statement || "(no statement yet)",
      "",
      "=== APPLICATION SUMMARY ===",
      "",
      facts || "(no facts captured)",
      "",
      "=== DOCUMENT CHECKLIST ===",
      "",
      checklist || "(no checklist)",
      "",
      "---",
      "This draft isn't submitted anywhere. Review it, then copy it into",
      "the scholarship's own application page.",
    ].join("\n");

    const blob = new Blob([body], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const slug = scholarshipTitle
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 60);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${slug || "application-draft"}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  function openRealApplication() {
    if (!applicationUrl) return;
    confirmApply({
      listingTitle: scholarshipTitle,
      applicationUrl,
      alreadyTracked: true,
      applicationId,
      onTrack: async () => ({ id: applicationId }),
    });
  }

  if (!hasDraft) {
    return (
      <div className="mt-3 pt-3 border-t border-hairline">
        <button
          type="button"
          onClick={generate}
          disabled={generating}
          aria-busy={generating}
          className="inline-flex min-h-[44px] items-center gap-2 text-sm font-medium text-white bg-navy rounded-seal px-4 hover:bg-navy-light transition-colors disabled:opacity-60"
        >
          {generating && <Spinner className="h-4 w-4" />}
          {generating ? "Drafting\u2026" : "Generate application draft"}
        </button>
        {generating && (
          <p className="mt-2 text-xs text-navy-light" role="status" aria-live="polite">
            Ade is preparing a draft from your application details…
          </p>
        )}
        {error && (
          <StatusMessage tone="error" className="mt-2">
            {error}
          </StatusMessage>
        )}
      </div>
    );
  }

  return (
    <div className="mt-3 pt-3 border-t border-hairline">
      <div className="flex items-center justify-between gap-2 mb-2">
        <button type="button" onClick={() => setOpen((o) => !o)} className="text-xs font-medium text-navy hover:underline">
          {open ? "Hide draft" : "Review draft"}
        </button>
        <span
          className={
            "text-xs font-medium px-2 py-1 rounded-full " +
            (confirmed && !dirty ? "bg-emerald-light text-emerald" : "bg-amber-light text-amber")
          }
        >
          {confirmed && !dirty ? "Confirmed" : "Needs review"}
        </span>
      </div>
      {open && (
        <div className="space-y-3">
          <div>
            <label htmlFor={`draft-statement-${applicationId}`} className="block text-xs font-medium text-ink mb-1.5">Personal statement</label>
            <textarea
              id={`draft-statement-${applicationId}`}
              name="personal_statement"
              className="w-full rounded-lg border border-hairline bg-white px-3 py-2.5 text-sm text-ink resize-y min-h-[140px] focus:border-navy"
              value={statement}
              onChange={(e) => setStatement(e.target.value)}
              maxLength={STATEMENT_MAX_CHARS + 500}
              aria-describedby={`draft-statement-count-${applicationId}`}
              aria-invalid={overLimit || undefined}
            />
            <p
              className={`text-xs mt-1 text-right ${
                overLimit ? "text-rose font-medium" : "text-navy-light"
              }`}
              id={`draft-statement-count-${applicationId}`}
              aria-live="polite"
            >
              {statement.length}/{STATEMENT_MAX_CHARS} characters
              {overLimit && ` (${statement.length - STATEMENT_MAX_CHARS} over limit)`}
            </p>
          </div>
          {draft.draft_summary && (
            <div>
              <p className="text-xs font-medium text-ink mb-1.5">Application summary</p>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs bg-navy-50 rounded-lg p-3">
                {draft.draft_summary.facts.map((f) => (
                  <div key={f.label} className="contents">
                    <dt className="text-navy-light">{f.label}</dt>
                    <dd className="text-ink font-mono">{f.value}</dd>
                  </div>
                ))}
              </dl>
              <ul className="mt-2 space-y-1">
                {draft.draft_summary.checklist.map((c) => (
                  <li key={c.item} className="flex items-center gap-2 text-xs">
                    <span className={c.have ? "text-emerald" : "text-rose"}>{c.have ? "\u2713" : "\u2717"}</span>
                    <span className="text-navy-light">{c.item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          {error && (
            <StatusMessage tone="error">
              {error}
            </StatusMessage>
          )}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => save(true)}
              disabled={saving || overLimit}
              aria-busy={saving}
              className="inline-flex min-h-[44px] items-center gap-2 text-sm font-medium text-white bg-emerald rounded-seal px-4 hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {saving && <Spinner className="h-4 w-4" />}
              {confirmed && !dirty ? "Confirmed \u2713" : "Confirm & use this draft"}
            </button>
            {dirty && (
              <button
                type="button"
                onClick={() => save(false)}
                disabled={saving || overLimit}
                className="inline-flex min-h-[44px] items-center rounded-seal border border-hairline bg-white px-3.5 text-sm font-medium text-navy hover:border-navy/30 hover:bg-navy-50 disabled:opacity-50"
              >
                Save edits
              </button>
            )}
            <button type="button" onClick={copyAll} className="inline-flex min-h-[44px] items-center rounded-seal border border-hairline bg-white px-3.5 text-sm font-medium text-navy hover:border-navy/30 hover:bg-navy-50">
              {copied ? "Copied!" : "Copy statement + summary"}
            </button>
            <button
              type="button"
              onClick={downloadPacket}
              className="inline-flex min-h-[44px] items-center rounded-seal border border-navy/25 bg-navy-50 px-3.5 text-sm font-medium text-navy hover:border-navy/50 hover:bg-navy-50"
            >
              Download packet (.txt)
            </button>
            <button
              type="button"
              onClick={generate}
              disabled={generating}
              aria-busy={generating}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-seal border border-hairline bg-white px-3.5 text-sm font-medium text-navy hover:border-navy/30 hover:bg-navy-50 disabled:opacity-50"
            >
              {generating && <Spinner className="h-4 w-4" />}
              {generating ? "Regenerating\u2026" : "Regenerate"}
            </button>
            {applicationUrl && (
              <button
                type="button"
                onClick={openRealApplication}
                className="inline-flex min-h-[44px] items-center rounded-seal border border-navy bg-white px-3.5 text-sm font-medium text-navy hover:bg-navy-50 ml-auto"
              >
                Open real application &rarr;
              </button>
            )}
          </div>
          <p className="text-[11px] text-navy-light">
            This draft isn&apos;t submitted anywhere. Review it, then copy it into the scholarship&apos;s own application
            page.
          </p>
        </div>
      )}
    </div>
  );
}
