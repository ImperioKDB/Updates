"use client";
import { useEffect, useState } from "react";
import { enableBrowserPush } from "@/lib/push/browser";
import { getPromptState, recordPromptAction } from "@/lib/onboarding-prompt-client";
import { useOverlayAccessibility } from "@/lib/useOverlayAccessibility";
import { SpinnerIcon } from "@/components/icons";
type Props = { publicKey: string | null; isAdmin: boolean; requestId: number };
type StandaloneNavigator = Navigator & { standalone?: boolean };
export function canUsePushHere(): boolean { if (!("Notification" in window) || !("serviceWorker" in navigator) || !("PushManager" in window)) return false; const isIos = /iPhone|iPad|iPod/i.test(window.navigator.userAgent); const standalone = window.matchMedia("(display-mode: standalone)").matches || Boolean((window.navigator as StandaloneNavigator).standalone); return !isIos || standalone; }
export function PushNotificationPrompt({ publicKey, isAdmin, requestId }: Props) {
  const [open, setOpen] = useState(false); const [busy, setBusy] = useState(false); const [blocked, setBlocked] = useState(false); const [message, setMessage] = useState("");
  const close = () => { if (!busy) setOpen(false); }; const dialogRef = useOverlayAccessibility(open, close);
  useEffect(() => { if (!requestId || isAdmin || !publicKey || !canUsePushHere() || Notification.permission !== "default") return; let active = true; let timer: number | undefined; async function consider() { try { const state = await getPromptState(); if (!active || !state || state.pushEnableClickedAt || Notification.permission !== "default") return; const registration = await navigator.serviceWorker.getRegistration("/"); const existingSubscription = await registration?.pushManager.getSubscription(); if (!active || existingSubscription) return; if (document.getElementById("cookie-title")) { timer = window.setTimeout(consider, 500); return; } setOpen(true); } catch { /* optional enhancement */ } } timer = window.setTimeout(consider, 0); return () => { active = false; if (timer) window.clearTimeout(timer); }; }, [isAdmin, publicKey, requestId]);
  async function enableNotifications() { if (!publicKey || busy) return; setBusy(true); setMessage(""); setBlocked(false); void recordPromptAction("push_enable_clicked"); try { const permission = await enableBrowserPush(publicKey); if (permission === "granted") setOpen(false); else if (permission === "denied") { setBlocked(true); setMessage("Notifications are blocked in your browser. Allow them in site settings, then enable them from Profile."); } else setMessage("No permission change yet. You can try again or choose “Maybe later”."); } catch (error) { setMessage(error instanceof Error ? error.message : "Could not enable notifications. Please try again."); } finally { setBusy(false); } }
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[100] flex items-end justify-center bg-navy/55 p-0 sm:items-center sm:p-4"
      onClick={(event) => { if (!busy && event.target === event.currentTarget) close(); }}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-busy={busy}
        aria-labelledby="push-prompt-title"
        aria-describedby="push-prompt-description"
        className="w-full max-w-md rounded-t-3xl border border-hairline bg-white px-6 pb-7 pt-7 shadow-card sm:rounded-2xl sm:px-8 sm:py-8"
      >
        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-emerald">A helpful heads-up</p>
        <h2 id="push-prompt-title" className="mt-2 font-display text-2xl font-semibold leading-tight text-navy">Get scholarship alerts on your phone</h2>
        <p id="push-prompt-description" className="mt-3 text-sm leading-6 text-navy-light">Hear about new matches and saved-scholarship deadlines, even when Scholars is closed.</p>
        <ul className="mt-5 space-y-3 rounded-xl bg-parchment px-4 py-4 text-sm text-ink"><li>New scholarships that fit your profile</li><li>A reminder before a saved opportunity closes</li></ul>
        <p className="mt-4 text-xs leading-5 text-navy-light">You can turn alerts off anytime from your Profile.</p>
        {busy && (
          <div className="mt-4 flex items-start gap-3 rounded-xl border border-emerald/20 bg-emerald-light/40 px-4 py-3 text-sm text-navy" role="status" aria-live="polite">
            <SpinnerIcon className="mt-0.5 h-4 w-4 shrink-0 text-emerald" />
            <span><strong className="font-semibold">Setting up alerts…</strong><span className="mt-0.5 block text-xs leading-5 text-navy-light">Your browser may ask you to allow notifications next.</span></span>
          </div>
        )}
        {message && <p role="status" aria-live="polite" className="mt-4 rounded-xl bg-amber/10 px-3 py-2 text-sm text-navy">{message}</p>}
        <div className="mt-5 space-y-2">
          <button type="button" onClick={() => void enableNotifications()} disabled={busy || blocked} aria-busy={busy} className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-seal bg-navy px-5 text-sm font-semibold text-white hover:bg-navy-light disabled:cursor-wait disabled:opacity-70">
            {busy && <SpinnerIcon className="h-4 w-4" />}
            <span>{busy ? "Enabling alerts…" : blocked ? "Notifications blocked" : "Enable notifications"}</span>
          </button>
          <button type="button" onClick={close} disabled={busy} className="inline-flex min-h-11 w-full items-center justify-center rounded-seal px-5 text-sm font-medium text-navy-light hover:bg-parchment disabled:cursor-wait disabled:opacity-60">Maybe later</button>
        </div>
      </div>
    </div>
  );
}
