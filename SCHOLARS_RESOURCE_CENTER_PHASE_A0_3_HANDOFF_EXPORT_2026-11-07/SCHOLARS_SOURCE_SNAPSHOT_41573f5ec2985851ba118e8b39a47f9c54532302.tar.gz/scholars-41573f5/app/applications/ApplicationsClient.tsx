"use client";
import { StatusMessage } from "@/components/StatusMessage";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ProviderMonogram } from "@/components/ProviderMonogram";
import { DeadlineBadge } from "@/components/DeadlineBadge";
import type { CardScholarship } from "@/components/ScholarshipCard";
import { StatusDonut } from "@/components/StatusDonut";
import { DraftPanel, type Draft } from "@/components/DraftPanel";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { useAde } from "@/components/ade/AdeProvider";
import { fetchWithTimeout } from "@/lib/fetch";
import { track } from "@/lib/analytics";
import { MilestoneOnboarding, announceMilestone } from "@/components/MilestoneOnboarding";
import { queueApplicationStatus, queueScholarshipSavedState } from "@/lib/offline/outbox";

type ApplicationStatus = "in_progress" | "submitted" | "accepted" | "rejected" | "not_applied";

type RawApplication = Draft & {
  id: string; status: ApplicationStatus; notes: string | null; created_at: string; updated_at: string;
  link_clicked_at: string | null; checkin_prompted_at: string | null;
  scholarship: CardScholarship | null;
  opportunity?: { id: string; type: CardOpportunityType; title: string; provider_name: string; description: string | null; eligibility_notes: string | null; duration: string | null; location: string | null; compensation: string | null; discipline: string | null; deadline: string | null; application_url: string | null; how_to_apply: string | null } | null;
};
type CardOpportunityType = "fellowship" | "internship" | "competition" | "mentorship" | "training";
type ApplicationApiItem = Omit<RawApplication, "scholarship" | "opportunity"> & { scholarship: CardScholarship; listingKind: "scholarship" | "opportunity" };
function normalizeApplication(raw: RawApplication): ApplicationApiItem {
  if (raw.scholarship) return { ...raw, scholarship: raw.scholarship, listingKind: "scholarship" };
  const o = raw.opportunity;
  if (!o) throw new Error("Application has no listing");
  return { ...raw, scholarship: { id: o.id, title: o.title, provider_name: o.provider_name, amount: o.compensation, deadline: o.deadline, application_url: o.application_url, how_to_apply: o.how_to_apply, level: "both", discipline: o.discipline }, listingKind: "opportunity" };
}

type SavedApiItem = { id: string; saved_at: string; scholarship: CardScholarship };

const STATUS_LABELS: Record<ApplicationStatus, string> = {
  in_progress: "In progress", submitted: "Submitted", accepted: "Accepted", rejected: "Rejected", not_applied: "Didn't apply",
};

const STATUS_TONE: Record<ApplicationStatus, string> = {
  in_progress: "bg-amber-light text-amber", submitted: "bg-navy-50 text-navy",
  accepted: "bg-emerald-light text-emerald", rejected: "bg-rose-light text-rose", not_applied: "bg-paper text-navy-light",
};

function readinessFor(application: ApplicationApiItem) {
  const items = [
    { label: "Profile match checked", done: true },
    { label: "Personal statement ready", done: Boolean(application.draft_statement) },
    { label: "Provider application opened", done: Boolean(application.link_clicked_at) },
    { label: "Marked as submitted", done: application.status === "submitted" || application.status === "accepted" },
  ];
  const score = Math.round((items.filter((item) => item.done).length / items.length) * 100);
  return { score, items };
}

export function ApplicationsClient({ userId, initialApplications, initialSaved, initialError, initialSavedError }: {
  userId: string;
  initialApplications: ApplicationApiItem[]; initialSaved: SavedApiItem[]; initialError: string | null; initialSavedError?: string | null;
}) {
  const router = useRouter();
  const { confirmApply } = useAde();
  const [loadError, setLoadError] = useState<string | null>(initialError);
  const [savedError, setSavedError] = useState<string | null>(initialSavedError ?? null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionNotice, setActionNotice] = useState<string | null>(null);
  const [applications, setApplications] = useState<ApplicationApiItem[]>(initialApplications.map(normalizeApplication));
  const [saved, setSaved] = useState<SavedApiItem[]>(initialSaved);
  const [pendingIds, setPendingIds] = useState<Set<string>>(new Set());
  const [flashIds, setFlashIds] = useState<Set<string>>(new Set());
  const [confirmState, setConfirmState] = useState<{
    message: string;
    onConfirm: () => void;
  } | null>(null);

  async function load() {
    setLoadError(null);
    setSavedError(null);
    try {
      const [appsRes, savedRes] = await Promise.all([
        fetchWithTimeout("/api/applications", { retries: 1 }),
        fetchWithTimeout("/api/scholarships/save", { retries: 1 }),
      ]);
      if (!appsRes.ok) { setLoadError("Couldn't load your applications. Try refreshing."); return; }
      const appsData = await appsRes.json();
      setApplications((appsData.applications ?? []).map(normalizeApplication));
      if (savedRes.ok) { const savedData = await savedRes.json(); setSaved(savedData.saved ?? []); }
      else setSavedError("Saved scholarships are temporarily unavailable. Try refreshing.");
    } catch {
      setLoadError("Couldn't load your applications. Check your connection and try again.");
    }
  }

  useEffect(() => {
    const onSyncComplete = (event: Event) => {
      const detail = (event as CustomEvent<{ userId?: string }>).detail;
      if (detail?.userId === userId) void load();
    };
    window.addEventListener("scholars:offline-sync-complete", onSyncComplete);
    return () => window.removeEventListener("scholars:offline-sync-complete", onSyncComplete);
  }, [userId]);

  const trackedScholarshipIds = useMemo(() => new Set(applications.map((a) => a.scholarship.id)), [applications]);
  const untrackedSaved = useMemo(() => saved.filter((s) => !trackedScholarshipIds.has(s.scholarship.id)), [saved, trackedScholarshipIds]);

  const counts = useMemo(() => {
    const c: Record<ApplicationStatus, number> = { in_progress: 0, submitted: 0, accepted: 0, rejected: 0, not_applied: 0 };
    for (const a of applications) c[a.status] += 1;
    return c;
  }, [applications]);

  const nextAction = useMemo(() => {
    const active = applications.find((a) => a.status === "in_progress") ?? applications[0];
    if (!active) return null;
    if (active.status === "accepted") {
      return { id: active.id, title: "Review your accepted application", detail: "Keep your funding journey complete by checking the details and status below." };
    }
    if (active.status === "rejected") {
      return { id: active.id, title: "Keep your funding search moving", detail: "Review similar open awards in the same discipline after this result." };
    }
    if (!active.draft_statement) {
      return { id: active.id, title: "Prepare your application materials", detail: "Generate a reviewable draft and check the requirements before you apply." };
    }
    if (!active.link_clicked_at) {
      return { id: active.id, title: "Take the next application step", detail: "Your draft is ready. Open the provider page and complete the application there." };
    }
    return { id: active.id, title: "Update your application progress", detail: "You opened the provider page. Tell Scholars whether you started or submitted it." };
  }, [applications]);

  function focusApplication(applicationId: string) {
    document.getElementById(`application-${applicationId}`)?.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "center" });
  }

  async function startTracking(scholarshipId: string) {
    setPendingIds((p) => new Set(p).add(scholarshipId));
    setActionError(null);
    try {
      const res = await fetchWithTimeout("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scholarship_id: scholarshipId }),
      });
      if (res.ok) {
        await load();
        announceMilestone("application_tip");
      }
      else setActionError("Couldn't start tracking. Try again.");
    } catch {
      setActionError("Couldn't start tracking. Check your connection and try again.");
    }
    setPendingIds((p) => { const n = new Set(p); n.delete(scholarshipId); return n; });
  }

  async function updateStatus(applicationId: string, status: ApplicationStatus) {
    const previousStatus = applications.find((application) => application.id === applicationId)?.status;
    setPendingIds((p) => new Set(p).add(applicationId));
    setActionError(null);
    setActionNotice(null);
    setApplications((prev) => prev.map((a) => (a.id === applicationId ? { ...a, status } : a)));
    setFlashIds((prev) => new Set(prev).add(applicationId));
    setTimeout(() => setFlashIds((prev) => { const n = new Set(prev); n.delete(applicationId); return n; }), 750);
    try {
      const res = await fetchWithTimeout(`/api/applications/${applicationId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        if (status === "submitted" || status === "accepted" || status === "rejected") track("outcome_recorded", { status });
      } else {
        const queued = (res.status === 408 || res.status >= 500) && previousStatus
          ? await queueApplicationStatus(userId, applicationId, status)
          : false;
        if (queued) setActionNotice("Your status change is saved on this device and will sync when connected.");
        else {
          if (previousStatus) setApplications((prev) => prev.map((a) => a.id === applicationId ? { ...a, status: previousStatus } : a));
          setActionError(res.status === 401 ? "Your session needs to be refreshed before updating this status." : "Couldn't update status. Try again.");
        }
      }
    } catch {
      const queued = previousStatus ? await queueApplicationStatus(userId, applicationId, status) : false;
      if (queued) setActionNotice("Your status change is saved on this device and will sync when connected.");
      else {
        if (previousStatus) setApplications((prev) => prev.map((a) => a.id === applicationId ? { ...a, status: previousStatus } : a));
        setActionError("Couldn't update status. Check your connection and try again.");
      }
    } finally {
      setPendingIds((p) => { const n = new Set(p); n.delete(applicationId); return n; });
    }
  }

  async function doStopTracking(applicationId: string) {
    setPendingIds((p) => new Set(p).add(applicationId));
    setActionError(null);
    const prev = applications;
    setApplications((cur) => cur.filter((a) => a.id !== applicationId));
    try {
      const res = await fetchWithTimeout(`/api/applications/${applicationId}`, { method: "DELETE" });
      if (!res.ok) setApplications(prev);
    } catch {
      setApplications(prev);
      setActionError("Couldn't stop tracking. Check your connection and try again.");
    }
    setPendingIds((p) => { const n = new Set(p); n.delete(applicationId); return n; });
  }

  function stopTracking(applicationId: string) {
    setConfirmState({
      message: "Stop tracking this application? It leaves your Applications list; any saved scholarship stays saved.",
      onConfirm: () => doStopTracking(applicationId),
    });
  }

  function handleDraftChange(applicationId: string, updated: Draft) {
    setApplications((prev) => prev.map((a) => (a.id === applicationId ? { ...a, ...updated } : a)));
  }


  async function removeSaved(scholarshipId: string) {
    setPendingIds((p) => new Set(p).add(scholarshipId));
    setActionError(null);
    setActionNotice(null);
    try {
      const res = await fetchWithTimeout(`/api/scholarships/save?scholarship_id=${scholarshipId}`, { method: "DELETE" });
      if (res.ok) setSaved((current) => current.filter((item) => item.scholarship.id !== scholarshipId));
      else if ((res.status === 408 || res.status >= 500) && await queueScholarshipSavedState(userId, scholarshipId, false)) {
        setSaved((current) => current.filter((item) => item.scholarship.id !== scholarshipId));
        setActionNotice("This removal is saved on this device and will sync when connected.");
      } else setActionError(res.status === 401 ? "Your session needs to be refreshed before removing saved scholarships." : "Couldn't remove this saved scholarship. Try again.");
    } catch {
      const queued = await queueScholarshipSavedState(userId, scholarshipId, false);
      if (queued) {
        setSaved((current) => current.filter((item) => item.scholarship.id !== scholarshipId));
        setActionNotice("This removal is saved on this device and will sync when connected.");
      } else setActionError("Couldn't remove this saved scholarship. Check your connection and try again.");
    } finally {
      setPendingIds((p) => { const n = new Set(p); n.delete(scholarshipId); return n; });
    }
  }

  function openApplication(a: ApplicationApiItem) {
    if (!a.scholarship.application_url) return;
    confirmApply({ listingTitle: a.scholarship.title, applicationUrl: a.scholarship.application_url, alreadyTracked: true, applicationId: a.id, onTrack: async () => ({ id: a.id }) });
  }

  return (
    <div>
      {confirmState && (
        <ConfirmDialog
          message={confirmState.message}
          onConfirm={confirmState.onConfirm}
          onClose={() => setConfirmState(null)}
          confirmLabel="Stop tracking"
          tone="rose"
        />
      )}

      <div className="mb-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.16em] text-navy-light">Your funding journey</p>
            <h1 className="font-display text-3xl font-semibold text-navy mt-1">Applications</h1>
            <p className="text-sm text-navy-light mt-1">One place to prepare, submit, and follow up.</p>
          </div>
          <Link href="/discover" className="inline-flex items-center justify-center rounded-seal bg-navy text-white text-sm font-medium px-4 py-2.5 hover:bg-navy-light transition-colors">
            Find another scholarship <span aria-hidden="true" className="ml-2">&rarr;</span>
          </Link>
        </div>
        <div className="bg-white rounded-2xl border border-hairline p-4 sm:p-5 mt-6 grid gap-5 md:grid-cols-[auto_1fr] md:items-center">
          <StatusDonut counts={counts} />
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {(Object.keys(STATUS_LABELS) as ApplicationStatus[]).map((status) => (
              <div key={status} className="rounded-xl bg-paper px-3 py-3">
                <p className="text-xs text-navy-light">{STATUS_LABELS[status]}</p>
                <p className="font-mono text-xl font-semibold text-navy mt-1">{counts[status]}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {loadError && (
        <StatusMessage tone="error" className="mb-6">
          {loadError}{" "}
          <button type="button" onClick={() => { setLoadError(null); router.refresh(); }} className="font-medium underline">Try again</button>
        </StatusMessage>
      )}

      {actionError && <StatusMessage tone="error" className="mb-6">{actionError}</StatusMessage>}
      {actionNotice && <div role="status" className="mb-6 rounded-xl border border-navy/10 bg-navy-50 px-4 py-3 text-sm text-navy">{actionNotice}</div>}

      {nextAction && (
        <div className="bg-navy text-white rounded-2xl p-5 sm:p-6 mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
          <p className="text-xs font-medium uppercase tracking-wide text-white/70 mb-1">Your next best action</p>
          <h2 className="font-display text-lg font-semibold">{nextAction.title}</h2>
          <p className="text-sm text-white/80 mt-1 max-w-xl">{nextAction.detail}</p>
          </div>
          <button type="button" onClick={() => focusApplication(nextAction.id)} className="shrink-0 rounded-seal bg-white text-navy text-sm font-medium px-4 py-2.5 hover:bg-navy-50 transition-colors">
            Continue below <span aria-hidden="true" className="ml-1">&darr;</span>
          </button>
        </div>
      )}

      {untrackedSaved.length > 0 && (
        <div className="mb-10">
          <h2 className="font-display text-lg font-semibold text-navy mb-3">Start tracking</h2>
          <p className="text-sm text-navy-light mb-4">Scholarships you&apos;ve saved but aren&apos;t tracking yet.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {untrackedSaved.map((s) => (
              <div key={s.scholarship.id} className="bg-white rounded-xl border border-hairline p-4 flex items-center gap-3">
                <ProviderMonogram name={s.scholarship.provider_name} size={40} />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-ink truncate">{s.scholarship.title}</p>
                  <p className="text-xs text-navy-light">{s.scholarship.provider_name}</p>
                </div>
                <button type="button" onClick={() => startTracking(s.scholarship.id)} disabled={pendingIds.has(s.scholarship.id)}
                  className="shrink-0 inline-flex min-h-[44px] items-center text-xs font-medium text-white bg-navy rounded-full px-3 py-1.5 hover:bg-navy-light transition-colors disabled:opacity-50">
                  + Track
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div data-tour="applications-list" className="flex items-end justify-between gap-3 mb-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-navy">Tracked applications</h2>
          <p className="text-sm text-navy-light mt-1">Update each one as you move through the provider&apos;s process.</p>
        </div>
        <span className="text-xs font-medium text-navy-light whitespace-nowrap">{applications.length} total</span>
      </div>
      {applications.length === 0 ? (
        <div className="bg-white rounded-xl border border-hairline p-8 text-center">
          <p className="text-sm text-navy-light">Nothing tracked yet. Save a scholarship from your matches, then start tracking it here.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {applications.map((a) => {
            return (
              <div id={`application-${a.id}`} key={a.id} className="relative bg-white rounded-2xl border border-hairline p-4 sm:p-5 shadow-card scroll-mt-6">
                {flashIds.has(a.id) && <span className="status-flash" aria-hidden="true" />}
                <div className="flex items-start gap-3">
                  <ProviderMonogram name={a.scholarship.provider_name} size={44} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-medium text-ink leading-snug">{a.scholarship.title}</p>
                        <p className="text-xs text-navy-light mt-0.5">{a.scholarship.provider_name}</p>
                      </div>
                      <button type="button" onClick={() => stopTracking(a.id)} disabled={pendingIds.has(a.id)} className="shrink-0 inline-flex min-h-[44px] items-center px-2 text-xs text-navy-light hover:text-rose disabled:opacity-50">Remove</button>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 mt-3">
                      <DeadlineBadge deadline={a.scholarship.deadline} />
                      <span className={`text-xs font-medium px-2 py-1 rounded-full ${STATUS_TONE[a.status]}`}>{STATUS_LABELS[a.status]}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 rounded-xl border border-hairline bg-paper/50 p-3">
                  <label className="block">
                    <span className="sr-only">Status</span>
                    <span className="text-xs font-medium text-navy-light block mb-1.5">Where are you with this application?</span>
                    <select value={a.status} onChange={(e) => updateStatus(a.id, e.target.value as ApplicationStatus)} disabled={pendingIds.has(a.id)}
                      className="w-full text-sm rounded-lg border border-hairline bg-white px-3 py-2.5 disabled:opacity-50">
                      {(Object.keys(STATUS_LABELS) as ApplicationStatus[]).map((s) => (<option key={s} value={s}>{STATUS_LABELS[s]}</option>))}
                    </select>
                  </label>
                </div>
                {(() => {
                  const readiness = readinessFor(a);
                  return (
                    <div className="mt-4">
                      <div className="flex items-center justify-between gap-3 mb-1.5">
                        <span className="text-xs font-medium text-navy-light">Application readiness</span>
                        <span className="font-mono text-xs font-semibold text-navy">{readiness.score}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-hairline overflow-hidden"><div className="h-full rounded-full bg-emerald transition-all" style={{ width: `${readiness.score}%` }} /></div>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-3 gap-y-1 mt-2">
                        {readiness.items.map((item) => <li key={item.label} className={`text-xs ${item.done ? "text-emerald" : "text-navy-light"}`}>{item.done ? "✓" : "○"} {item.label}</li>)}
                      </ul>
                    </div>
                  );
                })()}
                <div className="mt-4">
                  {/* PHASE 4 OUTCOME: a rejection is a dead end today.
                      Point the student at open awards in their discipline so
                      a "no" becomes a next step instead of a stop. */}
                  {a.status === "rejected" && (
                    <Link
                      href={`/discover?discipline=${encodeURIComponent(a.scholarship.discipline ?? "")}`}
                      className="inline-flex min-h-[44px] items-center text-xs font-medium text-navy hover:underline mt-3"
                    >
                      Didn&apos;t work out? Browse similar open awards &rarr;
                    </Link>
                  )}
                  {a.scholarship.application_url ? (
                    <button type="button" onClick={() => openApplication(a)} className="inline-flex items-center justify-center rounded-seal bg-navy text-white text-sm font-medium px-4 py-2.5 hover:bg-navy-light transition-colors">Open provider application <span aria-hidden="true" className="ml-2">&rarr;</span></button>
                  ) : a.scholarship.how_to_apply ? (
                    <p className="text-sm text-navy-light leading-relaxed"><span className="font-medium text-ink">How to apply: </span>{a.scholarship.how_to_apply}</p>
                  ) : null}
                  <DraftPanel applicationId={a.id} scholarshipTitle={a.scholarship.title}
                    draft={{ draft_statement: a.draft_statement, draft_summary: a.draft_summary, draft_generated_at: a.draft_generated_at, draft_confirmed_at: a.draft_confirmed_at }}
                    applicationUrl={a.scholarship.application_url} onDraftChange={(u) => handleDraftChange(a.id, u)} />
                </div>
              </div>
            );
          })}
        </div>
      )}

      <h2 id="saved" className="font-display text-lg font-semibold text-navy mb-5 scroll-mt-20">Saved ({saved.length})</h2>
      {savedError && <StatusMessage tone="error" className="mb-5">{savedError} <button type="button" onClick={() => router.refresh()} className="font-medium underline">Try again</button></StatusMessage>}
      {saved.length === 0 ? (
        <div className="bg-white rounded-xl border border-hairline p-8 text-center">
          <p className="text-sm text-navy-light">Save scholarships from your matches above to track their deadlines here.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {saved.map((s) => (
            <div key={s.scholarship.id} className="bg-white rounded-xl border border-hairline p-5 flex gap-4 shadow-card">
              <ProviderMonogram name={s.scholarship.provider_name} size={52} />
              <div className="min-w-0 flex-1">
                <Link href={`/scholarships/${s.scholarship.id}`} className="font-medium text-ink leading-snug hover:text-navy hover:underline">{s.scholarship.title}</Link>
                <p className="text-xs text-navy-light mt-0.5">{s.scholarship.provider_name}</p>
                <div className="mt-2"><DeadlineBadge deadline={s.scholarship.deadline} /></div>
                <div className="mt-2 flex flex-wrap gap-2">
                  <button type="button" onClick={() => startTracking(s.scholarship.id)} disabled={pendingIds.has(s.scholarship.id)} className="inline-flex min-h-[44px] items-center text-xs font-medium text-white bg-navy rounded-full px-3 py-1.5 disabled:opacity-50">+ Track</button>
                  <button type="button" onClick={() => removeSaved(s.scholarship.id)} disabled={pendingIds.has(s.scholarship.id)} className="inline-flex min-h-[44px] items-center px-2 text-xs font-medium text-navy-light hover:text-rose disabled:opacity-50">Unsave</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      <MilestoneOnboarding context="applications" userId={userId} />
    </div>
  );
}
