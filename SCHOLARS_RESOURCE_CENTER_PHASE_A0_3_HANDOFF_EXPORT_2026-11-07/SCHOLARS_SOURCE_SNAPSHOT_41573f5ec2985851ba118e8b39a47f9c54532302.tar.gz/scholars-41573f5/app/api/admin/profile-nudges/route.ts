// app/api/admin/profile-nudges/route.ts
// POST /api/admin/profile-nudges -- the admin profile-reminder buttons.
//   body {}              routine pass: respects the 2-day interval and
//                        5-email cap; pressing twice in one day sends
//                        nothing new the second time.
//   body { force: true } override pass: ignores the 2-day wait AND the
//                        5-email cap, emailing every profile under 100%
//                        right now (batch-capped at
//                        PROFILE_NUDGE_FORCE_BATCH per press). For one-off
//                        campaigns; the confirm dialog in the admin UI
//                        states exactly what it overrides.
//
// Auth: the middleware /api/admin gate plus assertAdmin here, the same
// defense in depth as the other admin routes. Rate limited 5/min so a
// stuck button cannot fan out sends. maxDuration 300 so a large student
// base is not cut off mid-send.
//
// Both paths write the same ledger columns (migration 0018). This route is
// called only by an explicit admin action; no scheduled job sends these emails.
import { NextResponse } from 'next/server'
import { z } from 'zod'
import { createClient } from '@/lib/supabase/server'
import { assertAdmin } from '@/lib/admin/guard'
import { checkRateLimit } from '@/lib/ratelimit'
import { runProfileNudges, PROFILE_NUDGE_INTERVAL_MS } from '@/lib/email/profileNudges'
import { isEmailBatch, type EmailBatch } from '@/lib/email/batches'
export const maxDuration = 300
const bodySchema = z.object({ force: z.boolean().optional().default(false), batch: z.string().optional() })
export async function POST(request: Request) {
const limited = await checkRateLimit(request, { route: 'admin-profile-nudges', limit: 5 })
if (limited) return limited
const supabase = await createClient()
const guard = await assertAdmin(supabase)
if (!guard.ok) return guard.response
const raw = await request.json().catch(() => null)
const parsed = bodySchema.safeParse(raw ?? {})
if (!parsed.success) {
return NextResponse.json(
{ error: 'Invalid request body', issues: parsed.error.issues },
{ status: 400 }
)
}
const force = parsed.data.force
const batch = parsed.data.batch === undefined ? undefined : (isEmailBatch(parsed.data.batch) ? parsed.data.batch : null)
if (batch === null) return NextResponse.json({ error: 'Choose Batch A, Batch B, or Batch C.' }, { status: 400 })
const options =
force
? { minIntervalMs: 0, enforceSendWindow: false, ignoreCap: true }
: { minIntervalMs: PROFILE_NUDGE_INTERVAL_MS, enforceSendWindow: false }
// A click is the only allowed email trigger. Keep this path synchronous so
// the response reports the actual send result and the override button cannot
// silently enqueue work for a background worker.
const summary = await runProfileNudges({ ...options, manual: true, batch: batch as EmailBatch | undefined })
return NextResponse.json({ summary: { ...summary, forced: force } })
}
