// app/api/admin/digest/route.ts
// POST /api/admin/digest -- the admin "send the digest now" button.
//
// Auth: the middleware /api/admin gate plus an inline is_admin check here,
// the same defense in depth as the other admin routes. No cron secret
// involved: this rides on your logged-in admin session.
//
// Rate limited to 5 calls per minute so a stuck button cannot fan out
// sends. maxDuration 300 so a large student base is not cut off mid-send.
//
// Passes minIntervalMs: 0 on purpose. Listing-level dedupe in
// announcement_log still guarantees each student receives each listing
// exactly once, so a second press the same day only sends listings
// verified since the first press.
import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { assertAdmin } from '@/lib/admin/guard'
import { checkRateLimit } from '@/lib/ratelimit'
import { runNewListingDigest } from '@/lib/email/digest'
import { isEmailBatch, type EmailBatch } from '@/lib/email/batches'

export const maxDuration = 300

export async function POST(request: Request) {
  const limited = await checkRateLimit(request, { route: 'admin-digest', limit: 5 })
  if (limited) return limited
  const supabase = await createClient()
  const guard = await assertAdmin(supabase)
  if (!guard.ok) return guard.response
  const raw = await request.json().catch(() => ({})) as { batch?: unknown }
  const batch = raw.batch === undefined ? undefined : (isEmailBatch(raw.batch) ? raw.batch : null)
  if (batch === null) return NextResponse.json({ error: 'Choose Batch A, Batch B, or Batch C.' }, { status: 400 })
  const summary = await runNewListingDigest({ minIntervalMs: 0, manual: true, batch: batch as EmailBatch | undefined })
  return NextResponse.json({ summary })
}
