// app/auth/callback/route.ts
// GET /auth/callback?code=...&next=/dashboard
//
// Handles both the Google OAuth redirect and the email-confirmation link.
// Both flows land the browser here with a `code` query param that has to
// be exchanged for a session via the server client -- without this route,
// signInWithOAuth's redirectTo (and the confirmation email's
// emailRedirectTo) send the browser straight to a protected page with no
// session yet, and middleware.ts bounces it back to /login.
//
// INPUT HARDENING: `next` is user-controlled input that decides a
// redirect target. safeNextPath (lib/validate.ts) whitelists same-origin
// relative paths only -- blocking //evil.com, absolute URLs, backslash
// normalization tricks and control characters -- so this route can never
// be turned into an open redirect.
//
// REFERRAL ATTRIBUTION: if a ref_id cookie is present (set by
// middleware.ts the moment someone visits a /s/[id] share link before
// signing up), stamp it onto the new user's profiles.referred_by the
// first time their session is established here. This route is the one
// place every signup path -- Google OAuth AND email/password +
// confirmation -- funnels through, so it's the single correct place to
// consume the cookie rather than duplicating this in both auth pages.
// Guarded with .is('referred_by', null) so it can only ever be set once
// per profile, and the cookie is cleared right after so a returning user
// who logs out and back in on the same device doesn't get re-attributed.
// The cookie value is user-controlled input, so it is UUID-validated
// here (second gate after middleware) before it reaches the database.
// A failure here is logged but never blocks sign-in -- attribution is a
// growth metric, not something worth failing auth over.
import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { createClient } from "@/lib/supabase/server";
import { logError } from "@/lib/logging";
import { safeNextPath, isUuid } from "@/lib/validate";
import { COOKIE_NAMES } from "@/lib/config";
import { getAuthCookieDomain } from "@/lib/auth/cookie-domain";
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = safeNextPath(searchParams.get("next"), "/dashboard");
  if (code) {
    const supabase = createClient();
    const { data, error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error && data.user) {
      const cookieStore = cookies();
      const refId = cookieStore.get(COOKIE_NAMES.REF)?.value;
      const attributionCookie = cookieStore.get(COOKIE_NAMES.ATTRIBUTION)?.value;
      let attribution: Record<string, string> = {};
      try {
        const parsed = JSON.parse(decodeURIComponent(attributionCookie || "{}"));
        for (const key of ["referral_source", "campaign_id", "ambassador_code", "utm_source", "utm_medium", "utm_campaign"]) {
          if (typeof parsed?.[key] === "string" && parsed[key].trim()) attribution[key] = parsed[key].trim().slice(0, 120);
        }
      } catch {
        // Ignore malformed attribution cookies; auth must remain fail-open.
      }
      if (refId && isUuid(refId) && refId !== data.user.id) {
        const { error: attributionError } = await supabase
          .from("profiles")
          .update({ referred_by: refId })
          .eq("id", data.user.id)
          .is("referred_by", null);
        if (attributionError) {
          logError("auth/callback", "referral attribution failed", undefined, attributionError);
        }
        cookieStore.set(COOKIE_NAMES.REF, "", { maxAge: 0, path: "/" });
      }
      if (Object.keys(attribution).length > 0) {
        const { error: attributionError } = await supabase
          .from("profiles")
          .update(attribution)
          .eq("id", data.user.id)
          .is("utm_source", null)
          .is("referral_source", null);
        if (attributionError) logError("auth/callback", "campaign attribution failed", undefined, attributionError);
        cookieStore.set(COOKIE_NAMES.ATTRIBUTION, "", { maxAge: 0, path: "/" });
      }
      // The browser sets this short-lived fallback marker before OAuth or
      // signup. Remove it on the normal callback path so a later root-level
      // auth rescue cannot inherit an old onboarding destination.
      const authCookieDomain =
        process.env.VERCEL_ENV === "production"
          ? getAuthCookieDomain("www.scholars.com.ng")
          : undefined;
      cookieStore.set("scholars_auth_next", "", {
        maxAge: 0,
        path: "/",
        ...(authCookieDomain ? { domain: authCookieDomain } : {}),
      });
      return NextResponse.redirect(origin + next);
    }
  }
  return NextResponse.redirect(
    origin +
      "/login?error=" +
      encodeURIComponent("Could not sign you in. The link may have expired -- please try again.")
  );
}
