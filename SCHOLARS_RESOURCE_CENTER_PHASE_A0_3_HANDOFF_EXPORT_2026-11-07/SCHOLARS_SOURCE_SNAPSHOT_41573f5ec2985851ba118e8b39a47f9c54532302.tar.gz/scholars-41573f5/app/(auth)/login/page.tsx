"use client";
import { Suspense, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { AuthShell } from "@/components/AuthShell";
import { FormField, inputClass } from "@/components/FormField";
import { StatusMessage } from "@/components/StatusMessage";
import { PasswordField } from "@/components/PasswordField";
import { normalizeEmail } from "@/lib/auth/email";
import { LogoLoader } from "@/components/LogoLoader";
import { AuthOtp } from "@/components/AuthOtp";
import { safeNextPath } from "@/lib/validate";
import { AUTH_NEXT_COOKIE } from "@/components/AuthRescue";
import { getAuthCookieDomain } from "@/lib/auth/cookie-domain";
import { getAuthRedirectOrigin } from "@/lib/auth/redirect-origin";
import { recordConfirmationEmailEvent } from "@/lib/auth/confirmation-email-analytics";

// AUTH SECURITY AUDIT (brute-force brake, client side): progressive
// lockout stored in localStorage. UX-level only -- the real brakes are
// Supabase's own server-side auth rate limits.
const LOCK_KEY = "scholars_login_lockout";

// Keep OAuth on the host where an installed PWA was launched. Previews use
// the configured production origin so Supabase allowlist matching stays stable.
function appBase(): string {
  if (typeof window === "undefined") return process.env.NEXT_PUBLIC_APP_URL || "";
  return getAuthRedirectOrigin(window.location.origin, process.env.NEXT_PUBLIC_APP_URL);
}
function rememberAuthNext(next: string) {
  const domain = getAuthCookieDomain(window.location.hostname);
  const domainAttribute = domain ? `; Domain=${domain}` : "";
  document.cookie = `${AUTH_NEXT_COOKIE}=${encodeURIComponent(next)}; Max-Age=600; Path=/; SameSite=Lax${domainAttribute}${window.location.protocol === "https:" ? "; Secure" : ""}`;
}

type LockState = { count: number; until: number };

function readLock(): LockState {
  try {
    const raw = localStorage.getItem(LOCK_KEY);
    if (!raw) return { count: 0, until: 0 };
    const parsed = JSON.parse(raw) as Partial<LockState>;
    return { count: parsed.count ?? 0, until: parsed.until ?? 0 };
  } catch {
    return { count: 0, until: 0 };
  }
}

function writeLock(lock: LockState) {
  try {
    localStorage.setItem(LOCK_KEY, JSON.stringify(lock));
  } catch {
    // storage blocked -- lockout degrades to per-page state, fine
  }
}

function clearLock() {
  try {
    localStorage.removeItem(LOCK_KEY);
  } catch {
    // ignore
  }
}

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(searchParams.get("error"));
  const [confirmationEmail, setConfirmationEmail] = useState<string | null>(null);
  const cleanEmail = normalizeEmail(email);
  const next = safeNextPath(searchParams.get("next"), "/dashboard");

  // Middleware is the first line of defense, but an installed PWA can
  // occasionally reach this page before its browser cookie state has been
  // refreshed. Ask Supabase to validate the user rather than trusting the
  // locally cached session, so a rejected session cannot bounce back into the
  // protected route.
  const sessionRedirected = useRef(false);
  useEffect(() => {
    let active = true;
    const redirectIfSignedIn = (hasSession: boolean) => {
      if (!active || !hasSession || sessionRedirected.current) return;
      sessionRedirected.current = true;
      router.replace(next);
      router.refresh();
    };
    const { data: authListener } = supabase.auth.onAuthStateChange(
      (_event, session) => redirectIfSignedIn(Boolean(session))
    );
    void supabase.auth.getUser().then(({ data, error: userError }) => {
      if (!userError) redirectIfSignedIn(Boolean(data.user));
    }).catch(() => {
      // Keep the normal sign-in form available if browser storage is blocked.
    });
    return () => {
      active = false;
      authListener.subscription.unsubscribe();
    };
  }, [next, router, supabase]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const lock = readLock();
    if (lock.until > Date.now()) {
      const secs = Math.ceil((lock.until - Date.now()) / 1000);
      setError(`Too many failed attempts. Try again in ${secs} second${secs === 1 ? "" : "s"}.`);
      return;
    }
    setLoading(true);
    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: cleanEmail,
      password,
    });
    setLoading(false);
    if (signInError) {
      if (signInError.code === "email_not_confirmed" || signInError.message.toLowerCase().includes("email not confirmed")) {
        setConfirmationEmail(cleanEmail);
        return;
      }
      const count = lock.count + 1;
      const until = count >= 5 ? Date.now() + Math.min(30_000 * 2 ** (count - 5), 300_000) : 0;
      writeLock({ count, until });
      setError("That password didn’t work. Check it and try again, or use Forgot password.");
      return;
    }
    clearLock();
    router.push(next);
    router.refresh();
  }

  async function handleGoogle(): Promise<string | null> {
    setError(null);
    setGoogleLoading(true);
    rememberAuthNext(next);
    try {
      const { error: googleError } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: `${appBase()}/auth/callback?next=${encodeURIComponent(next)}`,
          queryParams: { prompt: "select_account" },
        },
      });
      if (googleError) {
        setGoogleLoading(false);
        const message = "We couldn't start Google sign-in. Please try again.";
        setError(message);
        return message;
      }
    } catch {
      setGoogleLoading(false);
      const message = "We couldn't start Google sign-in. Please try again.";
      setError(message);
      return message;
    }
    return null;
  }

  async function handleResendConfirmation(): Promise<string | null> {
    const { error: resendError } = await supabase.auth.resend({ type: "signup", email: confirmationEmail ?? "" });
    void recordConfirmationEmailEvent({
      email: confirmationEmail ?? "",
      kind: "resend",
      status: resendError ? "failed" : "accepted",
      errorCode: resendError?.code ?? null,
    });
    return resendError ? "We couldn't send a new code right now. Please try again shortly." : null;
  }

  async function handleVerifyConfirmation(token: string): Promise<string | null> {
    const { data, error: verifyError } = await supabase.auth.verifyOtp({
      email: confirmationEmail ?? cleanEmail,
      token,
      type: "signup",
    });
    if (verifyError) return "That code is invalid or has expired. Request a new code and try again.";
    if (!data.session) return "Your email was verified, but we couldn't start your session. Please log in.";
    router.push(next);
    router.refresh();
    return null;
  }

  if (confirmationEmail) {
    return (
      <AuthOtp
        email={confirmationEmail}
        purpose="signup"
        onVerify={handleVerifyConfirmation}
        onResend={handleResendConfirmation}
        onGoogle={handleGoogle}
        onBack={() => setConfirmationEmail(null)}
      />
    );
  }

  return (
    <AuthShell heading="Welcome back" sub="Log in to see your latest matches.">
      {error && <StatusMessage tone="error" className="mb-5">{error}</StatusMessage>}
      <form onSubmit={handleSubmit} noValidate>
        <FormField label="Email" id="login-email">
          <input
            className={inputClass}
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@university.edu.ng"
            autoComplete="email"
          />
        </FormField>
        <FormField label="Password" id="login-password">
          <PasswordField
            id="login-password"
            value={password}
            onChange={setPassword}
            placeholder="Your password"
            autoComplete="current-password"
          />
        </FormField>
        <div className="text-right mb-2">
          <Link href="/reset-password" className="text-xs text-navy-light hover:text-navy">
            Forgot password?
          </Link>
        </div>
        <button
          type="submit"
          disabled={loading}
          aria-busy={loading}
          className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-navy text-white font-medium py-3 mt-2 hover:bg-navy-light transition-colors disabled:opacity-60"
        >
          {loading && (
            <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
          )}
          {loading ? "Logging in…" : "Log in"}
        </button>
      </form>
      <div className="flex items-center gap-3 my-6">
        <div className="h-px flex-1 bg-hairline" />
        <span className="text-xs text-navy-light">or continue with</span>
        <div className="h-px flex-1 bg-hairline" />
      </div>
      <button
        onClick={handleGoogle}
        disabled={googleLoading}
        className="w-full inline-flex items-center justify-center gap-2 rounded-lg border border-hairline bg-white py-2.5 text-sm font-medium text-ink hover:bg-navy-50 transition-colors disabled:opacity-60"
      >
        {googleLoading && (
          <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
        )}
        {googleLoading ? "Redirecting…" : "Continue with Google"}
      </button>
      <p className="text-sm text-navy-light mt-8 text-center">
        Don&apos;t have an account?{" "}
        <Link href={`/signup?next=${encodeURIComponent(next)}`} className="text-navy font-medium hover:underline">
          Sign up
        </Link>
      </p>
    </AuthShell>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <AuthShell heading="Welcome back" sub="Sign in to see your scholarship matches.">
          <LogoLoader variant="section" label="Loading sign-in form…" />
        </AuthShell>
      }
    >
      <LoginForm />
    </Suspense>
  );
}
