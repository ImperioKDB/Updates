"use client";
import { StatusMessage } from "@/components/StatusMessage";
import { ScrollReveal } from "@/components/ScrollReveal";
import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { ScholarshipCard, type CardScholarship } from "@/components/ScholarshipCard";
import { LogoLoader } from "@/components/LogoLoader";
import { isCurrentlyOpen } from "@/lib/discovery";
import { fetchWithTimeout, FetchTimeoutError, FetchNetworkError } from "@/lib/fetch";
import { MilestoneOnboarding } from "@/components/MilestoneOnboarding";
import { readCachedScholarshipCatalog, writeCachedScholarshipCatalog } from "@/lib/offline/catalog-cache";
import { queueScholarshipSavedState } from "@/lib/offline/outbox";

const LEVEL_OPTIONS = [
  { value: "", label: "All levels" },
  { value: "undergrad", label: "Undergraduate only" },
  { value: "both", label: "Open to undergrad & postgrad" },
] as const;

const PAGE_SIZE = 20;
const SEARCH_DEBOUNCE_MS = 350;

export function DiscoverClient({ userId, initialSavedIds, initialSavedError }: { userId: string; initialSavedIds: string[]; initialSavedError?: string | null }) {
  const searchParams = useSearchParams();
  const [keyword, setKeyword] = useState(() => searchParams.get("q") ?? "");
  const [level, setLevel] = useState(() => searchParams.get("level") ?? "");
  const [discipline, setDiscipline] = useState(() => searchParams.get("discipline") ?? "");
  const [items, setItems] = useState<CardScholarship[]>([]);
  const [total, setTotal] = useState(0);
  const [nextOffset, setNextOffset] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [cachedAt, setCachedAt] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [savedError, setSavedError] = useState<string | null>(initialSavedError ?? null);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set(initialSavedIds));
  const [pendingIds, setPendingIds] = useState<Set<string>>(new Set());

  const requestIdRef = useRef(0);
  const abortRef = useRef<AbortController | null>(null);
  const filtersActive = keyword.trim() !== "" || level !== "" || discipline.trim() !== "";

  async function load(offset: number, replace: boolean) {
    const requestId = ++requestIdRef.current;
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    setLoading(true);
    setLoadError(null);

    const params = new URLSearchParams();
    if (keyword.trim()) params.set("q", keyword.trim());
    if (level) params.set("level", level);
    if (discipline.trim()) params.set("discipline", discipline.trim());
    params.set("limit", String(PAGE_SIZE));
    params.set("offset", String(offset));

    const canUseCache = Boolean(userId && offset === 0 && replace && !filtersActive && items.length === 0);
    try {
      const res = await fetchWithTimeout("/api/scholarships?" + params.toString(), { signal: controller.signal, retries: 1 });
      if (requestId !== requestIdRef.current) return;
      if (!res.ok) {
        if (res.status >= 500 && canUseCache) {
          const cached = readCachedScholarshipCatalog<CardScholarship>(userId);
          if (cached) {
            setItems(cached.scholarships);
            setTotal(cached.total);
            setNextOffset(cached.scholarships.length);
            setCachedAt(cached.cachedAt);
            setLoading(false);
            return;
          }
        }
        setLoadError(res.status === 401 ? "Your session needs to be refreshed before loading scholarships." : "Couldn't load scholarships. Try again.");
        setLoading(false);
        return;
      }
      const data = await res.json();
      const page = (data.scholarships ?? []) as CardScholarship[];
      setItems((prev) => (replace ? page : [...prev, ...page]));
      setTotal(data.total ?? 0);
      setNextOffset(offset + page.length);
      if (offset === 0 && replace && !filtersActive) {
        writeCachedScholarshipCatalog(userId, page, data.total ?? 0);
        setCachedAt(null);
      }
    } catch (err) {
      if (requestId !== requestIdRef.current) return;
      if (controller.signal.aborted) return;
      if (canUseCache) {
        const cached = readCachedScholarshipCatalog<CardScholarship>(userId);
        if (cached) {
          setItems(cached.scholarships);
          setTotal(cached.total);
          setNextOffset(cached.scholarships.length);
          setCachedAt(cached.cachedAt);
          setLoading(false);
          return;
        }
      }
      if (err instanceof FetchTimeoutError) {
        setLoadError("Request timed out. Check your connection and try again.");
      } else if (err instanceof FetchNetworkError) {
        setLoadError("Network issue. Check your connection and try again.");
      } else {
        setLoadError("Couldn't load scholarships. Try again.");
      }
    }
    setLoading(false);
  }

  useEffect(() => {
    const t = setTimeout(() => load(0, true), SEARCH_DEBOUNCE_MS);
    return () => {
      clearTimeout(t);
      abortRef.current?.abort();
    };
  }, [keyword, level, discipline]);

  useEffect(() => {
    const onSyncComplete = (event: Event) => {
      const detail = (event as CustomEvent<{ userId?: string }>).detail;
      if (detail?.userId !== userId) return;
      void fetchWithTimeout("/api/scholarships/save", { retries: 1 })
        .then(async (response) => {
          if (!response.ok) return;
          const data = await response.json();
          setSavedIds(new Set((data.saved ?? []).map((item: { scholarship: { id: string } }) => item.scholarship.id)));
          setSavedError(null);
        })
        .catch(() => {});
    };
    window.addEventListener("scholars:offline-sync-complete", onSyncComplete);
    return () => window.removeEventListener("scholars:offline-sync-complete", onSyncComplete);
  }, [userId]);

  const openNowItems = useMemo(
    () => items.filter((s) => isCurrentlyOpen(s)).map((s) => ({ ...s, isOpenNow: true })),
    [items]
  );

  const comingSoonItems = useMemo(
    () => items.filter((s) => !isCurrentlyOpen(s)).map((s) => ({ ...s, isOpenNow: false })),
    [items]
  );

  async function toggleSave(scholarshipId: string) {
    const wasSaved = savedIds.has(scholarshipId);
    setSavedIds((prev) => {
      const next = new Set(prev);
      if (wasSaved) next.delete(scholarshipId);
      else next.add(scholarshipId);
      return next;
    });
    setPendingIds((prev) => new Set(prev).add(scholarshipId));

    setSaveError(null);
    try {
      const res = wasSaved
        ? await fetchWithTimeout(`/api/scholarships/save?scholarship_id=${scholarshipId}`, { method: "DELETE" })
        : await fetchWithTimeout("/api/scholarships/save", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ scholarship_id: scholarshipId }),
          });
      let handled = res.ok;
      if (!handled && (res.status === 408 || res.status >= 500)) {
        handled = await queueScholarshipSavedState(userId, scholarshipId, !wasSaved);
      }
      if (!handled) {
        setSaveError(res.status === 401 ? "Your session needs to be refreshed before saving." : "Couldn't update this saved scholarship. Try again.");
        setSavedIds((prev) => {
          const next = new Set(prev);
          if (wasSaved) next.add(scholarshipId);
          else next.delete(scholarshipId);
          return next;
        });
      } else setSaveError(null);
    } catch (err) {
      const queued = await queueScholarshipSavedState(userId, scholarshipId, !wasSaved);
      if (!queued) {
        setSaveError("Couldn't save this change offline. Check your connection and try again.");
        setSavedIds((prev) => {
          const next = new Set(prev);
          if (wasSaved) next.add(scholarshipId);
          else next.delete(scholarshipId);
          return next;
        });
      }
    } finally {
      setPendingIds((prev) => {
        const next = new Set(prev);
        next.delete(scholarshipId);
        return next;
      });
    }
  }

  const hasMore = nextOffset < total;

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-display text-2xl font-semibold text-navy">Browse scholarships</h1>
        <p className="text-sm text-navy-light mt-1 mb-6">
          Every verified listing on Scholars. Your personalized matches live on the dashboard; this is the full catalog.
        </p>
        <div className="bg-white rounded-2xl border border-hairline p-4 sm:p-5 shadow-[0_1px_2px_rgba(11,30,61,0.03)]">
          <label className="block mb-3">
            <span className="sr-only">Search by scholarship name or provider</span>
            <input
              className="w-full min-h-[48px] rounded-xl border border-hairline bg-white px-3.5 text-sm text-ink placeholder:text-navy-light/50 focus:border-navy transition-colors"
              type="search"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="Search by scholarship name or provider, e.g. MTN"
            />
          </label>
          <div className="flex flex-wrap gap-2">
            <select
              className="min-h-[44px] text-sm rounded-xl border border-hairline bg-white px-3"
              value={level}
              onChange={(e) => setLevel(e.target.value)}
              aria-label="Filter by level"
            >
              {LEVEL_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
            <input
              className="min-h-[44px] text-sm rounded-xl border border-hairline bg-white px-3 w-full sm:w-72 placeholder:text-navy-light/50 focus:border-navy transition-colors"
              type="text"
              value={discipline}
              onChange={(e) => setDiscipline(e.target.value)}
              placeholder="Filter by course, e.g. Computer Science"
              aria-label="Filter by course"
            />
          </div>
        </div>
      </div>
      {cachedAt && (
        <div role="status" className="mb-6 rounded-xl border border-amber/25 bg-amber-light px-4 py-3 text-sm text-navy">
          Showing a saved catalogue from {new Date(cachedAt).toLocaleString()}. Scholarship availability and deadlines may have changed; verify them with the provider before applying.
          <button type="button" onClick={() => load(0, true)} className="ml-2 font-semibold underline">Retry</button>
        </div>
      )}
      {savedError && <StatusMessage tone="error" className="mb-6">Saved scholarship status may be out of date. {savedError}</StatusMessage>}
      {saveError && <StatusMessage tone="error" className="mb-6">{saveError}</StatusMessage>}
      {loadError && (
        <StatusMessage tone="error" className="mb-6">
          {loadError}{" "}
          <button type="button" onClick={() => load(0, true)} className="font-medium underline">Retry</button>
        </StatusMessage>
      )}
      {!loading && items.length === 0 && !loadError ? (
        <div className="bg-white rounded-2xl border border-hairline p-8 text-center shadow-[0_1px_2px_rgba(11,30,61,0.03)]">
          <p className="text-sm text-navy-light">No scholarships match that search. Try fewer filters or a different keyword.</p>
        </div>
      ) : (
        <>
          {openNowItems.length > 0 && (
            <ScrollReveal data-tour="scholarships-list" className="grid md:grid-cols-2 gap-4">
              {openNowItems.map((s) => (
                <ScholarshipCard key={s.id} scholarship={s} saved={savedIds.has(s.id)} pending={pendingIds.has(s.id)} onToggleSave={() => toggleSave(s.id)} sharerId={userId} />
              ))}
            </ScrollReveal>
          )}
          {comingSoonItems.length > 0 && (
            <div className="mt-10">
              <h2 className="font-display text-lg font-semibold text-navy mb-1">Coming soon</h2>
              <p className="text-sm text-navy-light mb-4">
                Verified scholarships that aren&apos;t accepting applications yet. Save one to keep it on your radar.
              </p>
              <ScrollReveal className="below-fold grid md:grid-cols-2 gap-4">
                {comingSoonItems.map((s) => (
                  <ScholarshipCard key={s.id} scholarship={s} saved={savedIds.has(s.id)} pending={pendingIds.has(s.id)} onToggleSave={() => toggleSave(s.id)} sharerId={userId} />
                ))}
              </ScrollReveal>
            </div>
          )}
          {loading && (
            <div
              className="mt-6 grid md:grid-cols-2 gap-4"
              role="status"
              aria-live="polite"
              aria-busy="true"
              aria-label="Loading scholarships"
            >
              <LogoLoader variant="section" label="Loading scholarships…" />
            </div>
          )}
          {!loading && hasMore && (
            <div className="mt-6 text-center">
              <button
                type="button"
                onClick={() => load(nextOffset, false)}
                className="rounded-seal border border-hairline bg-white text-navy text-sm font-medium px-6 py-2.5 hover:bg-navy-50 transition-colors"
              >
                Load more ({total - nextOffset} remaining)
              </button>
            </div>
          )}
          {!loading && !hasMore && items.length > 0 && (
            <p className="text-sm text-navy-light text-center mt-8 leading-relaxed">
              {filtersActive
                ? "That is every match for these filters. Try clearing one to see more."
                : "That is all the scholarships for now. We'll notify you once a new one is available."}
            </p>
          )}
        </>
      )}
      <MilestoneOnboarding context="discover" userId={userId} />
    </div>
  );
}
