import type { Metadata } from "next";
import localFont from "next/font/local";
import { AuthRescue } from "@/components/AuthRescue";
import { CookieConsent } from "@/components/CookieConsent";
import { InstallAppPrompt } from "@/components/InstallAppPrompt";
import { Monitoring } from "@/components/Monitoring";
import { NetworkStatus } from "@/components/NetworkStatus";
import "./globals.css";
import "./motion.css";

const fraunces = localFont({
  src: [
    { path: "./fonts/fraunces-latin.woff2", weight: "500 700", style: "normal" },
    { path: "./fonts/fraunces-italic-latin.woff2", weight: "500 700", style: "italic" },
  ],
  variable: "--font-fraunces",
  display: "swap",
});

const manrope = localFont({
  src: "./fonts/manrope-latin.woff2",
  weight: "400 700",
  variable: "--font-manrope",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || "https://www.scholars.com.ng"),
  title: {
    default: "Scholars | Find scholarships you're actually eligible for",
    template: "%s | Scholars",
  },
  description:
    "Scholars matches your academic profile with scholarships you can realistically win, and keeps every deadline in one place.",
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    siteName: "Scholars",
    title: "Find scholarships you're actually eligible for",
    description:
      "Create one profile and discover verified scholarships for students in Nigeria.",
    url: "/",
  },
  twitter: {
    card: "summary_large_image",
    title: "Find scholarships you're actually eligible for",
    description:
      "Create one profile and discover verified scholarships for students in Nigeria.",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${fraunces.variable} ${manrope.variable}`}>
      <body className="font-sans bg-parchment text-ink antialiased">
        {/* Rescues auth codes/tokens that Supabase strands on the root
            when a redirectTo is rejected (see components/AuthRescue.tsx).
            No-op everywhere else. */}
        <AuthRescue />
        {children}
        <NetworkStatus />
        <Monitoring />
        <InstallAppPrompt />
        {/* Essential-only cookie consent banner. Mounted in the root layout so
            it renders on every public route. Consent is stored
            in localStorage with a 1-year expiry. */}
        <CookieConsent />
      </body>
    </html>
  );
}
