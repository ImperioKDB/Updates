import { StatusMessage } from "@/components/StatusMessage";
import Link from "next/link";
import { requireAdmin } from "@/lib/admin/access";
import { createClient } from "@/lib/supabase/server";
import { daysUntil } from "@/lib/dates";
// app/admin/health/page.tsx
// GET /admin/health
//
// Weekly maintenance triage in one server-rendered page. Pulls the
// scholarships table once (small by design) and partitions it into the
// buckets maintenance actually acts on:
//
//   1. Verification queue (Phase 2): unverified drafts oldest-first with a
//      days-waiting SLA chip (amber past 7 days, rose past 14), plus an
//      "Oldest pending" tile so queue age is visible at a glance.
//   2. Unverified drafts waiting on review (sub-count: already past
//      deadline, i.e. likely dead listings that should be deleted, not
//      verified).
//   3. Live (verified) listings with no application path -- neither
//      application_url nor how_to_apply -- students can see these but
//      cannot apply. Same rule as the missingApplyPath warning in
//      components/admin/ScholarshipFields.tsx.
//   4. Past-deadline listings. Verified ones are called out separately
//      because they still render to students as "Closed" until someone
//      unverifies or extends them.
//
// Read-only by design: every row links straight to the edit page, so the
// fix happens where the tooling already exists. One query, one render,
// no client JS, no new API route, no migration.
//
// AUDIT FIX (batch 3): RELIABILITY CAP. The original query had no limit,
// so a 10,000-row catalog would serialize every row into one serverless
// response and risk blowing the function's memory/time budget. Health
// triage only ever acts on the soonest deadlines, so we cap at ROW_CAP
// ordered by deadline and say so loudly when the cap bites.
const ROW_CAP = 2000;
const QUEUE_LIMIT = 12;
type Row = {
  id: string;
  title: string;
  provider_name: string;
  deadline: string;
  verified: boolean;
  application_url: string | null;
  how_to_apply: string | null;
  created_at: string;
};
function isPast(deadline: string): boolean {
  const d = daysUntil(deadline);
  return d !== null && d < 0;
}
function daysWaiting(createdAt: string): number {
  const t = Date.parse(createdAt);
  if (Number.isNaN(t)) return 0;
  return Math.max(0, Math.floor((Date.now() - t) / 86400000));
}
function WaitingChip({ days }: { days: number }) {
  const tone =
    days > 14 ? "bg-rose-light text-rose" : days > 7 ? "bg-amber-light text-amber" : "bg-navy-50 text-navy-light";
  return (
    <span className={`text-xs font-mono font-medium px-2 py-1 rounded-full ${tone}`}>
      {days}d waiting
    </span>
  );
}
function DeadlineChip({ deadline }: { deadline: string }) {
  const d = daysUntil(deadline);
  if (d === null) return <span className="text-xs text-navy-light">{deadline}</span>;
  if (d < 0)
    return (
      <span className="text-xs font-mono font-medium px-2 py-1 rounded-full bg-rose-light text-rose">
        Closed {-d}d ago
      </span>
    );
  if (d <= 7)
    return (
      <span className="text-xs font-mono font-medium px-2 py-1 rounded-full bg-amber-light text-amber">
        {d}d left
      </span>
    );
  return <span className="text-xs font-mono text-navy-light">{d}d left</span>;
}
function VerifiedBadge({ verified }: { verified: boolean }) {
  return (
    <span
      className={
        "text-xs font-medium px-2 py-1 rounded-full " +
        (verified ? "bg-emerald-light text-emerald" : "bg-amber-light text-amber")
      }
    >
      {verified ? "Live" : "Pending"}
    </span>
  );
}
function Tile({
  value,
  label,
  hint,
  tone,
}: {
  value: number;
  label: string;
  hint: string;
  tone: "amber" | "rose" | "emerald";
}) {
  const toneClass = tone === "amber" ? "text-amber" : tone === "rose" ? "text-rose" : "text-emerald";
  return (
    <div className="bg-white rounded-xl border border-hairline p-5">
      <p className={`font-mono text-3xl font-semibold ${toneClass}`}>{value}</p>
      <p className="text-sm text-navy-light mt-1">{label}</p>
      <p className="text-xs text-navy-light mt-0.5">{hint}</p>
    </div>
  );
}
function Section({ title, sub, children }: { title: string; sub: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl border border-hairline p-5 mb-6">
      <h2 className="font-display text-lg font-semibold text-navy mb-1">{title}</h2>
      <p className="text-sm text-navy-light mb-3">{sub}</p>
      {children}
    </div>
  );
}
function HealthRow({ row, right }: { row: Row; right?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2.5 border-b border-hairline last:border-0">
      <div className="min-w-0">
        <Link
          href={`/admin/scholarships/${row.id}/edit`}
          className="text-sm font-medium text-ink hover:text-navy block truncate"
        >
          {row.title}
        </Link>
        <p className="text-xs text-navy-light">{row.provider_name}</p>
      </div>
      <div className="flex items-center gap-2 shrink-0">{right}</div>
    </div>
  );
}
function AllClear() {
  return <p className="text-sm text-emerald">Nothing here -- all clear.</p>;
}
export default async function AdminHealthPage() {
  await requireAdmin();
  const supabase = createClient();
  const { data, error } = await supabase
    .from("scholarships")
    .select("id, title, provider_name, deadline, verified, application_url, how_to_apply, created_at")
    .order("deadline", { ascending: true })
    .limit(ROW_CAP);
  if (error) {
    return <StatusMessage tone="error">We couldn&apos;t load the health checks right now. Please try again shortly.</StatusMessage>;
  }
  const rows = (data ?? []) as Row[];
  const capped = rows.length >= ROW_CAP;
  const unverified = rows.filter((r) => !r.verified);
  const unverifiedPast = unverified.filter((r) => isPast(r.deadline));
  const missingPath = rows.filter(
    (r) => r.verified && !r.application_url?.trim() && !r.how_to_apply?.trim()
  );
  const stale = rows.filter((r) => isPast(r.deadline));
  const staleLive = stale.filter((r) => r.verified);
  const attention = unverified.length + missingPath.length + staleLive.length;
  // Phase 2 verification queue: oldest unverified drafts first, capped so
  // the section stays scannable on a phone.
  const queue = [...unverified]
    .sort((a, b) => (a.created_at < b.created_at ? -1 : 1))
    .slice(0, QUEUE_LIMIT);
  const oldestDays = queue.length > 0 ? daysWaiting(queue[0].created_at) : 0;
  return (
    <div>
      <div className="flex items-center justify-between mb-8 flex-wrap gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold text-navy">Health check</h1>
          <p className="text-sm text-navy-light mt-1">
            {attention === 0
              ? "All clear -- nothing needs attention this week."
              : `${attention} item${attention === 1 ? "" : "s"} need attention this week.`}
          </p>
        </div>
        <Link href="/admin/scholarships" className="text-sm text-navy hover:underline">
          Open scholarships table
        </Link>
      </div>
      {capped && (
        <p className="text-xs text-amber bg-amber-light rounded-lg px-3.5 py-2.5 mb-6">
          Showing the first {ROW_CAP} scholarships by deadline. The catalog is larger than this
          page loads on purpose; use the scholarships table for anything older.
        </p>
      )}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-10">
        <Tile
          value={unverified.length}
          label="Unverified drafts"
          hint={`${unverifiedPast.length} already past deadline`}
          tone={unverified.length > 0 ? "amber" : "emerald"}
        />
        <Tile
          value={oldestDays}
          label="Oldest pending (days)"
          hint={oldestDays > 14 ? "breaches the 14-day SLA" : oldestDays > 7 ? "past the 7-day target" : "within SLA"}
          tone={oldestDays > 14 ? "rose" : oldestDays > 7 ? "amber" : "emerald"}
        />
        <Tile
          value={missingPath.length}
          label="Live with no apply path"
          hint="verified, but no URL or how-to-apply"
          tone={missingPath.length > 0 ? "rose" : "emerald"}
        />
        <Tile
          value={stale.length}
          label="Past-deadline listings"
          hint={`${staleLive.length} still live to students`}
          tone={staleLive.length > 0 ? "rose" : stale.length > 0 ? "amber" : "emerald"}
        />
      </div>
      <Section
        title="Verification queue"
        sub="Oldest unverified drafts first. Amber past 7 days waiting, rose past 14: verify, push the deadline forward, or delete the draft."
      >
        {queue.length === 0 ? (
          <AllClear />
        ) : (
          queue.map((r) => (
            <HealthRow
              key={r.id}
              row={r}
              right={
                <>
                  <WaitingChip days={daysWaiting(r.created_at)} />
                  <DeadlineChip deadline={r.deadline} />
                </>
              }
            />
          ))
        )}
      </Section>
      <Section
        title="Unverified drafts"
        sub="Waiting on review. Past-deadline ones are usually dead listings: delete rather than verify."
      >
        {unverified.length === 0 ? (
          <AllClear />
        ) : (
          unverified.map((r) => (
            <HealthRow key={r.id} row={r} right={<DeadlineChip deadline={r.deadline} />} />
          ))
        )}
      </Section>
      <Section
        title="Live with no application path"
        sub="Students can see these but cannot apply. Add an application URL or how-to-apply text, or unverify."
      >
        {missingPath.length === 0 ? (
          <AllClear />
        ) : (
          missingPath.map((r) => (
            <HealthRow
              key={r.id}
              row={r}
              right={
                <>
                  <DeadlineChip deadline={r.deadline} />
                  <VerifiedBadge verified={r.verified} />
                </>
              }
            />
          ))
        )}
      </Section>
      <Section
        title="Past deadline"
        sub="Verified rows still show to students as Closed until unverified or extended. Unverified rows should usually be deleted."
      >
        {stale.length === 0 ? (
          <AllClear />
        ) : (
          stale.map((r) => (
            <HealthRow
              key={r.id}
              row={r}
              right={
                <>
                  <DeadlineChip deadline={r.deadline} />
                  <VerifiedBadge verified={r.verified} />
                </>
              }
            />
          ))
        )}
      </Section>
    </div>
  );
}
