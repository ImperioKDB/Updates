import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { SendDigestButton } from "@/components/admin/SendDigestButton";
import { SendProfileNudgesButton } from "@/components/admin/SendProfileNudgesButton";
import { SendTestProfileNudgeButton } from "@/components/admin/SendTestProfileNudgeButton";
// Activation funnel window for the scoreboard below. 30 days matches how
// often you actually look at this page and how long a signup cohort stays
// relevant during an application cycle.
const ACTIVATION_WINDOW_DAYS = 30;
async function getStats() {
  const supabase = createClient();
  const sinceIso = new Date(Date.now() - ACTIVATION_WINDOW_DAYS * 86400000).toISOString();
  const [
    { count: totalScholarships },
    { count: verifiedScholarships },
    { count: totalProfiles },
    { count: recentProfiles },
    { count: totalSaved },
    { count: incompleteProfiles },
    lastNudge,
    { data: metricsSummary },
    { data: recentMonitoringErrors },
    { count: monitoringErrorCount },
  ] = await Promise.all([
    supabase.from("scholarships").select("*", { count: "exact", head: true }),
    supabase.from("scholarships").select("*", { count: "exact", head: true }).eq("verified", true),
    supabase.from("profiles").select("*", { count: "exact", head: true }),
    supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .gte("created_at", sinceIso),
    supabase.from("saved_scholarships").select("*", { count: "exact", head: true }),
    supabase.from("profiles").select("*", { count: "exact", head: true }).lt("profile_completeness", 100),
    supabase
      .from("profiles")
      .select("profile_reminder_last_sent_at")
      .not("profile_reminder_last_sent_at", "is", null)
      .order("profile_reminder_last_sent_at", { ascending: false })
      .limit(1),
    // Aggregate inside Postgres instead of serializing every event and
    // application row into this server component on every admin visit.
    supabase.rpc("get_admin_metrics_summary", { p_since: sinceIso }),
    supabase
      .from("monitoring_error_events")
      .select("id, kind, message, pathname, created_at")
      .order("created_at", { ascending: false })
      .limit(12),
    supabase
      .from("monitoring_error_events")
      .select("id", { count: "exact", head: true })
      .gte("created_at", sinceIso),
  ]);
  const summary = (metricsSummary ?? {}) as {
    activation?: Record<string, number>;
    community?: Record<string, number>;
    monitoring?: {
      pageViews?: number;
      clientErrors?: number;
      vitals?: Record<string, { total: number; count: number }>;
    };
    outcome?: Record<string, number>;
  };
  const activation: Record<string, number> = {
    profile_created: 0,
    provisional_matches_viewed: 0,
    gap_nudge_clicked: 0,
    profile_completed: 0,
    whatsapp_opt_in: 0,
    onboarding_step_completed: 0,
    onboarding_abandoned: 0,
    button_clicked: 0,
    scholarship_issue_reported: 0,
  };
  Object.assign(activation, summary.activation ?? {});
  const monitoring = {
    pageViews: summary.monitoring?.pageViews ?? 0,
    clientErrors: monitoringErrorCount ?? 0,
    vitals: summary.monitoring?.vitals ?? {},
  };
  const community: Record<string, number> = {
    posts: 0,
    replies: 0,
    helpful_reactions: 0,
    reports: 0,
  };
  Object.assign(community, summary.community ?? {});
  const outcome: Record<string, number> = {
    in_progress: 0,
    submitted: 0,
    accepted: 0,
    rejected: 0,
  };
  Object.assign(outcome, summary.outcome ?? {});
  // Profile creation is a durable row-level fact. Do not depend on the
  // append-only analytics event, which can be absent for profiles created
  // before activation tracking was deployed or if a fire-and-forget event
  // write was interrupted after the profile save succeeded.
  activation.profile_created = recentProfiles ?? 0;
  const { data: recent } = await supabase
    .from("scholarships")
    .select("id, title, provider_name, deadline, verified, level")
    .order("created_at", { ascending: false })
    .limit(6);
  return {
    totalScholarships: totalScholarships ?? 0,
    verifiedScholarships: verifiedScholarships ?? 0,
    totalProfiles: totalProfiles ?? 0,
    totalSaved: totalSaved ?? 0,
    incompleteProfiles: incompleteProfiles ?? 0,
    lastNudgeAt:
      (lastNudge?.data?.[0]?.profile_reminder_last_sent_at as string | undefined) ?? null,
    activation,
    monitoring,
    community,
    outcome,
    recentMonitoringErrors: recentMonitoringErrors ?? [],
    recent: recent ?? [],
  };
}
export default async function AdminOverviewPage() {
  const stats = await getStats();
  const cards = [
    { label: "Scholarships", value: stats.totalScholarships },
    { label: "Verified & live", value: stats.verifiedScholarships },
    { label: "Students", value: stats.totalProfiles },
    { label: "Incomplete profiles", value: stats.incompleteProfiles },
    { label: "Saves", value: stats.totalSaved },
  ];
  const activationCards = [
    { label: "Profiles created", value: stats.activation.profile_created },
    { label: "Saw first matches", value: stats.activation.provisional_matches_viewed },
    { label: "Nudge clicks", value: stats.activation.gap_nudge_clicked },
    { label: "Completed profile", value: stats.activation.profile_completed },
    { label: "WhatsApp opt-ins", value: stats.activation.whatsapp_opt_in },
    { label: "Onboarding steps completed", value: stats.activation.onboarding_step_completed },
    { label: "Onboarding abandons", value: stats.activation.onboarding_abandoned },
    { label: "Tracked actions", value: stats.activation.button_clicked },
    { label: "Listing reports", value: stats.activation.scholarship_issue_reported },
  ];
  const outcomeCards = [
    { label: "In progress", value: stats.outcome.in_progress },
    { label: "Submitted", value: stats.outcome.submitted },
    { label: "Accepted", value: stats.outcome.accepted },
    { label: "Rejected", value: stats.outcome.rejected },
  ];
  const communityCards = [
    { label: "New posts", value: stats.community.posts },
    { label: "Replies", value: stats.community.replies },
    { label: "Helpful reactions", value: stats.community.helpful_reactions },
    { label: "Reports", value: stats.community.reports },
  ];
  const monitoringCards = [
    { label: "Authenticated page views", value: stats.monitoring.pageViews },
    { label: "Client errors", value: stats.monitoring.clientErrors },
    ...["LCP", "INP", "CLS", "TTFB"].map((name) => ({
      label: `Avg ${name}`,
      value: stats.monitoring.vitals[name]
        ? Number((stats.monitoring.vitals[name].total / stats.monitoring.vitals[name].count).toFixed(2))
        : "—",
    })),
  ];
  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-2xl font-semibold text-navy">Admin overview</h1>
          <p className="text-sm text-navy-light mt-1">Usage at a glance, and the fastest path to add a scholarship.</p>
        </div>
        <Link
          href="/admin/scholarships/new"
          className="rounded-seal bg-navy text-white text-sm font-medium px-5 py-2.5 hover:bg-navy-light transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          + Add scholarship
        </Link>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
        {cards.map((c) => (
          <div key={c.label} className="bg-white rounded-xl border border-hairline p-5">
            <p className="font-mono text-3xl font-semibold text-navy">{c.value}</p>
            <p className="text-sm text-navy-light mt-1">{c.label}</p>
          </div>
        ))}
      </div>
      <div className="bg-white rounded-xl border border-hairline p-5 mb-10">
        <h2 className="font-display text-lg font-semibold text-navy mb-1">
          Activation, last {ACTIVATION_WINDOW_DAYS} days
        </h2>
        <p className="text-sm text-navy-light mb-4">
          The signup-to-completion funnel: first profile save, first look at real matches,
          gap-nudge clicks, profiles that reached 100%, and WhatsApp consent. Reads the
          events table, so it stays empty until students start generating events.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {activationCards.map((c) => (
            <div key={c.label} className="bg-parchment rounded-xl border border-hairline p-4">
              <p className="font-mono text-2xl font-semibold text-navy">{c.value}</p>
              <p className="text-xs text-navy-light mt-1">{c.label}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="bg-white rounded-xl border border-hairline p-5 mb-10">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="font-display text-lg font-semibold text-navy mb-1">Community activity, last {ACTIVATION_WINDOW_DAYS} days</h2>
            <p className="text-sm text-navy-light">Posts, replies, helpful reactions, and reports from verified scholarship discussions.</p>
          </div>
          <Link href="/admin/discussions" className="text-sm font-medium text-navy hover:underline">Moderate discussions →</Link>
        </div>
        <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
          {communityCards.map((c) => (
            <div key={c.label} className="bg-parchment rounded-xl border border-hairline p-4">
              <p className="font-mono text-2xl font-semibold text-navy">{c.value}</p>
              <p className="text-xs text-navy-light mt-1">{c.label}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="bg-white rounded-xl border border-hairline p-5 mb-10">
        <h2 className="font-display text-lg font-semibold text-navy mb-1">App health, last {ACTIVATION_WINDOW_DAYS} days</h2>
        <p className="text-sm text-navy-light mb-4">
          First-party monitoring from public and authenticated sessions. Web Vitals are reported in milliseconds except CLS; client errors are counted without storing full stack traces or form contents.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
          {monitoringCards.map((c) => (
            <div key={c.label} className="bg-parchment rounded-xl border border-hairline p-4">
              <p className="font-mono text-2xl font-semibold text-navy">{c.value}</p>
              <p className="text-xs text-navy-light mt-1">{c.label}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="bg-white rounded-xl border border-hairline p-5 mb-10">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="font-display text-lg font-semibold text-navy mb-1">Recent client errors</h2>
            <p className="text-sm text-navy-light">Sanitized browser and error-boundary reports. No form contents, tokens, or full stack traces are stored.</p>
          </div>
          <span className="text-xs text-navy-light">Latest 12</span>
        </div>
        {stats.recentMonitoringErrors.length === 0 ? (
          <p className="mt-4 rounded-lg bg-parchment px-4 py-3 text-sm text-navy-light">No client errors recorded.</p>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="border-b border-hairline text-left text-xs text-navy-light">
                  <th className="px-3 py-2 font-medium">When</th>
                  <th className="px-3 py-2 font-medium">Type</th>
                  <th className="px-3 py-2 font-medium">Route</th>
                  <th className="px-3 py-2 font-medium">Message</th>
                </tr>
              </thead>
              <tbody>
                {stats.recentMonitoringErrors.map((item: {
                  id: string;
                  kind: string;
                  message: string;
                  pathname: string | null;
                  created_at: string;
                }) => (
                  <tr key={item.id} className="border-b border-hairline last:border-0">
                    <td className="px-3 py-3 whitespace-nowrap text-xs text-navy-light">{new Date(item.created_at).toLocaleString()}</td>
                    <td className="px-3 py-3 whitespace-nowrap text-xs font-medium text-rose">{item.kind}</td>
                    <td className="px-3 py-3 whitespace-nowrap text-xs text-navy-light">{item.pathname || "—"}</td>
                    <td className="px-3 py-3 max-w-[360px] truncate text-ink" title={item.message}>{item.message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <div className="bg-white rounded-xl border border-hairline p-5 mb-10">
        <h2 className="font-display text-lg font-semibold text-navy mb-1">Outcome funnel (all time)</h2>
        <p className="text-sm text-navy-light mb-4">
          What tracked applications turn into. Accepted and rejected counts are the raw
          material for future &quot;students like you&quot; benchmarks, once volume clears the
          k-anonymity gate. Students never see this page.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {outcomeCards.map((c) => (
            <div key={c.label} className="bg-parchment rounded-xl border border-hairline p-4">
              <p className="font-mono text-2xl font-semibold text-navy">{c.value}</p>
              <p className="text-xs text-navy-light mt-1">{c.label}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="bg-white rounded-xl border border-hairline p-5 mb-10">
        <h2 className="font-display text-lg font-semibold text-navy mb-1">New-listing email digest</h2>
        <p className="text-sm text-navy-light mb-4">
          Bundles every verified scholarship and opportunity added in the last 7 days into one email
          per student, skipping anything they have already been told about. This is manual-only: no
          scheduled digest email is sent. Press the button to send after reviewing the listings. Each
          listing reaches each student at most once, so pressing twice the same day only sends what
          was verified since the first press.
        </p>
        <SendDigestButton />
      </div>
      <div className="bg-white rounded-xl border border-hairline p-5 mb-10">
        <h2 className="font-display text-lg font-semibold text-navy mb-1">Profile completion reminders</h2>
        <p className="text-sm text-navy-light mb-4">
          Emails students whose profile is under 100%, naming the exact fields they&apos;re missing so
          they know what to add. This is manual-only: no scheduled reminder email is sent. The navy
          button skips anyone reminded in the last 2 days and stops after 5 reminders. The outlined
          button overrides both guards and emails every incomplete profile right now, for a
          one-off campaign only.
        </p>
        <SendProfileNudgesButton lastNudgeAt={stats.lastNudgeAt} />
      </div>
      <div className="bg-white rounded-xl border border-hairline p-5 mb-10">
        <h2 className="font-display text-lg font-semibold text-navy mb-1">Inngest delivery test</h2>
        <p className="text-sm text-navy-light mb-4">
          Outbound email delivery is paused. This test endpoint currently records a test event but
          does not send an email. It is restricted to admins and cannot target another address.
        </p>
        <SendTestProfileNudgeButton />
      </div>
      <div className="bg-white rounded-xl border border-hairline overflow-hidden">
        <div className="px-5 py-4 border-b border-hairline flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-navy">Recently added</h2>
          <Link href="/admin/scholarships" className="text-sm text-navy hover:underline">
            View all
          </Link>
        </div>
        {stats.recent.length === 0 ? (
          <p className="text-sm text-navy-light p-5">No scholarships yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[560px]">
              <tbody>
                {stats.recent.map((s) => (
                  <tr key={s.id} className="border-b border-hairline last:border-0">
                    <td className="px-5 py-3">
                      <Link href={`/admin/scholarships/${s.id}/edit`} className="font-medium text-ink hover:text-navy">
                        {s.title}
                      </Link>
                      <p className="text-xs text-navy-light">{s.provider_name}</p>
                    </td>
                    <td className="px-5 py-3 text-navy-light">{s.deadline}</td>
                    <td className="px-5 py-3">
                      <span
                        className={
                          "text-xs font-medium px-2 py-1 rounded-full " +
                          (s.verified ? "bg-emerald-light text-emerald" : "bg-amber-light text-amber")
                        }
                      >
                        {s.verified ? "Verified" : "Pending review"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
