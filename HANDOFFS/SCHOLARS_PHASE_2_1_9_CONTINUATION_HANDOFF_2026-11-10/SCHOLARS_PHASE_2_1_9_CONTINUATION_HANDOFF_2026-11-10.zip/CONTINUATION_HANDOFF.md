# Scholars Phase 2.1.9 Continuation Handoff

**Prepared:** 2026-11-10 16:10 CET
**Current status:** BLOCKED — PRIVATE EXECUTION ENVIRONMENT REQUIRED
**Source repository:** `ImperioKDB/Updates`
**Source main commit at handoff:** `c4cc4782917c1c056a505bcb77d443a66ea6ff35`
**Application repository:** `ImperioKDB/Scholars` (public)
**Production Supabase project ref:** `cmdglabohpttgfofcmqc` (never accessed)
**Staging Supabase project ref:** `aqhktriwaglvvrchxmtd` (never accessed; do not use as restore target)

## Objective to continue

Enable a safely authorized, schema-only production capture path. This is not permission to connect, export, modify, restore, deploy, or access production or staging. First resolve private execution environment availability and least-privilege role feasibility. Only proceed to extraction after separate explicit approvals.

## Verified state

1. Both GitHub repositories (`ImperioKDB/Updates` and `ImperioKDB/Scholars`) are public. Do not put credentials, production schema output, artifact hashes, or sensitive extraction logs in either repository.
2. `Updates` main contains the synthetic-only workflow at `.github/workflows/scholars-runner-preflight.yml`, commit `04cb1e6d87ef5074a18a584cbb26d0a48c706b89`. The workflow is manually dispatched only, `ubuntu-24.04`, no third-party actions, no secrets, no artifact upload, and uses disposable local PostgreSQL only.
3. GitHub Actions run `42838236003` succeeded on `infra/phase-2-1-8-github-runner-preflight`, workflow SHA `04cb1e6d87ef5074a18a584cbb26d0a48c706b89`. It showed Ubuntu 24.04.5 x86_64; Docker 28.0.4; host PostgreSQL tools 16.15; Supabase CLI 2.122.1; disposable `postgres:17` container tools PostgreSQL 17.11. It created a fabricated schema, table, function, index, RLS policy and row; `pg_dump --schema-only` object assertions passed, fabricated row marker absent, local SHA-256 computed but not exposed, container and temp directory cleanup passed. The test used local container superuser, not a restricted role, and did not contact Supabase.
4. The authorized-device inventory showed only the Manus Sandbox; no already-authorized private execution environment was found. Sandbox private artifact retention suitability was not established.
5. Official PostgreSQL 17 and Supabase documents do not establish a complete least-privilege ACL matrix for native `pg_dump --schema-only`, Supabase CLI `db dump`, and pg-delta declarative generation under a non-owner login. The prior report explicitly refuses to invent a verified grant recipe. Candidate role attributes and boundaries are a proposal only.
6. No production/staging connection, SQL, credential, role/grant change, schema capture, restore, or deployment occurred.

## Current decision and next gates

**Decision:** `BLOCKED — PRIVATE EXECUTION ENVIRONMENT REQUIRED`.

The project administrator must:

1. Identify/approve an existing private, no-new-cost Linux x86_64 runner/workspace with secure credential injection, private logs and encrypted private artifact retention. Do not use either public repository for actual capture.
2. Have the database owner/security administrator test a candidate, dedicated, non-owner PostgreSQL 17 role on an isolated equivalent fixture for each selected tool. Ensure no superuser, ownership, role administration, writes, RLS bypass, broad read roles, or table SELECT unless separately justified and explicitly approved. Stop if tools require broader rights.
3. Approve the exact schema allowlist, purpose/retention, credential injection method, and separately authorize any eventual production capture. Keep staging excluded.

Do not request secrets in chat. The prior Phase 2.1.9 report contains the proposed non-executing capture procedure, design limits, references, and security controls. Start there; do not repeat prior audits.

## Included files

- `reports/SCHOLARS_PHASE_2_1_9_SECURE_SCHEMA_CAPTURE_ENABLEMENT_2026-11-10.md` — controlling current report and verdict.
- `reports/phase-2.1.8/*.md` — eligibility, run results, synthetic test, security and final decision.
- `workflow/scholars-runner-preflight.yml` — public synthetic runner workflow source (no credentials).
- `reports/phase-2.1.7/*.md` — prior administrator guide, capture preflight, access, PostgREST, environment and decision details relevant to current gates.
- `NEXT_SESSION_PROMPT.txt` — concise prompt for the next Manus session.

No raw Actions logs, database dump, credentials, tokens, private artifact hashes, or production data are included. The original Phase 2.1.9 task was enablement-only and is summarized here; consult the current report for source documentation links.

## Repository references

- Handoff source commit: https://github.com/ImperioKDB/Updates/commit/c4cc4782917c1c056a505bcb77d443a66ea6ff35
- Synthetic workflow commit: https://github.com/ImperioKDB/Updates/commit/04cb1e6d87ef5074a18a584cbb26d0a48c706b89
- Synthetic run: https://github.com/ImperioKDB/Updates/actions/runs/42838236003
