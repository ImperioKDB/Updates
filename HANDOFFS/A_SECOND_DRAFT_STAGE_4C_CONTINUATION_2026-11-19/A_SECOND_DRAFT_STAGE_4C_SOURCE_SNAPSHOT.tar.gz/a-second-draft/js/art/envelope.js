/* Scene 5 layered stationery envelope: back sheet, body, side folds,
   triangular flap, irregular wax seal. Static upgrade; opening animation
   belongs to Stage 4C. Five layers prepared for 4C. */
import { svgEl, svgRoot, artResult } from "../lib/svg.js";
import { buildSealGroup } from "./seal.js";

export function buildEnvelope() {
  const seal = buildSealGroup("translate(93.2 79.2) scale(0.7)");
  const node = svgRoot("0 0 220 150", "art art--envelope", [
    svgEl("g", { class: "art-envelope-back", "data-layer": "back" }, [
      svgEl("rect", { class: "art-fill-paper-under art-stroke-line", x: 14, y: 18, width: 192, height: 120, rx: 4, "stroke-width": 1 }),
    ]),
    svgEl("g", { class: "art-envelope-body", "data-layer": "body" }, [
      svgEl("rect", { class: "art-fill-paper art-stroke-ink", x: 22, y: 30, width: 176, height: 104, rx: 3, "stroke-width": 1.5 }),
    ]),
    svgEl("g", { class: "art-envelope-folds", "data-layer": "folds" }, [
      svgEl("path", { class: "art-fill-paper art-stroke-line", "stroke-width": 1, d: "M22 30 L96 84 L22 134 Z" }),
      svgEl("path", { class: "art-fill-paper art-stroke-line", "stroke-width": 1, d: "M198 30 L124 84 L198 134 Z" }),
      svgEl("path", { class: "art-fill-paper art-stroke-line", "stroke-width": 1, d: "M22 134 L110 84 L198 134 Z" }),
    ]),
    svgEl("g", { class: "art-envelope-flap", "data-layer": "flap" }, [
      svgEl("path", { class: "art-fill-paper art-stroke-ink", "stroke-width": 1.5, d: "M22 30 L110 96 L198 30 Z" }),
      svgEl("path", { class: "art-stroke-gold", "stroke-width": 1, d: "M32 34 L110 90 L188 34" }),
    ]),
    seal.node,
  ]);
  return artResult(node);
}
