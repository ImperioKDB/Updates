/* Scene 4 vintage candlestick telephone: handset, coiled cord, three signal
   arcs, sound dots. Ink line-art with rose/gold accents. Not a call UI. */
import { svgEl, svgRoot, artResult } from "../lib/svg.js";

export function buildPhone() {
  const node = svgRoot("0 0 200 160", "art art--phone", [
    svgEl("g", { class: "art-phone-base", "data-layer": "base" }, [
      svgEl("ellipse", { class: "art-fill-ink", cx: 100, cy: 142, rx: 30, ry: 8 }),
      svgEl("rect", { class: "art-fill-ink", x: 96, y: 80, width: 8, height: 60 }),
      svgEl("path", { class: "art-fill-ink", d: "M84 62 Q100 52 116 62 L108 80 Q100 86 92 80 Z" }),
    ]),
    svgEl("g", { class: "art-phone-handset", "data-layer": "handset" }, [
      svgEl("circle", { class: "art-fill-ink", cx: 42, cy: 66, r: 9 }),
      svgEl("path", { class: "art-stroke-ink", "stroke-width": 5, d: "M40 74 Q34 86 46 96" }),
      svgEl("path", { class: "art-stroke-ink", "stroke-width": 3, d: "M62 84 H80" }),
    ]),
    svgEl("g", { class: "art-phone-cord", "data-layer": "cord" }, [
      svgEl("path", { class: "art-stroke-rose", "stroke-width": 2, d: "M128 140 q6 -8 12 0 q6 8 12 0 q6 -8 12 0 q6 8 12 0" }),
    ]),
    svgEl("g", { class: "art-phone-arcs", "data-layer": "arcs" }, [
      svgEl("path", { class: "art-stroke-gold", "stroke-width": 2, d: "M150 42 q10 10 0 20" }),
      svgEl("path", { class: "art-stroke-gold", "stroke-width": 2, d: "M160 34 q16 16 0 36" }),
      svgEl("path", { class: "art-stroke-gold", "stroke-width": 2, d: "M170 26 q22 22 0 52" }),
    ]),
    svgEl("g", { class: "art-phone-dots", "data-layer": "dots" }, [
      svgEl("circle", { class: "art-fill-rose", cx: 146, cy: 52, r: 2.5 }),
      svgEl("circle", { class: "art-fill-gold", cx: 186, cy: 30, r: 2 }),
    ]),
  ]);
  return artResult(node);
}
