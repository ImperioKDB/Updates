/* Scene 1 cover emblem: envelope, sprig and wax seal (Stage 4B).
   Reused by the Scene 8 finale. Layered groups are prepared for Stage 4C. */
import { svgEl, svgRoot, artResult } from "../lib/svg.js";
import { buildSealGroup } from "./seal.js";

export function buildCoverEmblem() {
  const seal = buildSealGroup("translate(45.6 45.6) scale(0.6)");
  const node = svgRoot("0 0 120 96", "art art--cover-emblem", [
    svgEl("g", { class: "art-cover-sprig", "data-layer": "sprig" }, [
      svgEl("path", { class: "art-stroke-gold", "stroke-width": 1.5, d: "M60 32 C60 24 60 18 60 10" }),
      svgEl("ellipse", { class: "art-fill-gold-tint", cx: 53, cy: 18, rx: 6, ry: 2.6, transform: "rotate(-24 53 18)" }),
      svgEl("ellipse", { class: "art-fill-gold-tint", cx: 67, cy: 14, rx: 6, ry: 2.6, transform: "rotate(20 67 14)" }),
      svgEl("ellipse", { class: "art-fill-gold-tint", cx: 52, cy: 27, rx: 5, ry: 2.2, transform: "rotate(-30 52 27)" }),
      svgEl("ellipse", { class: "art-fill-gold-tint", cx: 68, cy: 24, rx: 5, ry: 2.2, transform: "rotate(26 68 24)" }),
    ]),
    svgEl("g", { class: "art-cover-envelope", "data-layer": "envelope" }, [
      svgEl("rect", { class: "art-fill-paper art-stroke-ink", x: 28, y: 34, width: 64, height: 44, rx: 3, "stroke-width": 1.5 }),
      svgEl("path", { class: "art-stroke-ink", "stroke-width": 1.5, d: "M28 36 L60 60 L92 36" }),
      svgEl("path", { class: "art-stroke-line", "stroke-width": 1, d: "M28 78 L48 60 M92 78 L72 60" }),
    ]),
    seal.node,
  ]);
  return artResult(node);
}
