/* Scene 6 fictional departmental seal and static stamp detail.
   Deliberately formal, no lettering, no cartoon elements. */
import { svgEl, svgRoot, artResult } from "../lib/svg.js";

export function buildReportSeal() {
  const node = svgRoot("0 0 72 72", "art art--report-seal", [
    svgEl("g", { class: "art-report-seal", "data-layer": "seal" }, [
      svgEl("circle", { class: "art-fill-paper art-stroke-ink", cx: 36, cy: 34, r: 28, "stroke-width": 1.5 }),
      svgEl("circle", { class: "art-stroke-gold", cx: 36, cy: 34, r: 22, "stroke-width": 1 }),
      svgEl("path", { class: "art-stroke-gold", "stroke-width": 1.5, d: "M18 44 Q14 34 20 24 M54 44 Q58 34 52 24" }),
      svgEl("path", { class: "art-fill-rose", d: "M36 24 L39 31 L46 31 L40 36 L42 43 L36 39 L30 43 L32 36 L26 31 L33 31 Z" }),
      svgEl("path", { class: "art-fill-rose-tint art-stroke-line", "stroke-width": 1, d: "M22 58 L50 58 L46 66 L26 66 Z" }),
    ]),
  ]);
  return artResult(node);
}

export function buildReportStamp() {
  const node = svgRoot("0 0 64 64", "art art--report-stamp", [
    svgEl("g", { class: "art-report-stamp", "data-layer": "stamp", opacity: 0.8 }, [
      svgEl("circle", { class: "art-stroke-rose", cx: 32, cy: 32, r: 26, "stroke-width": 2 }),
      svgEl("circle", { class: "art-stroke-rose", cx: 32, cy: 32, r: 19, "stroke-width": 1 }),
      svgEl("path", { class: "art-fill-rose", d: "M32 22 L35 29 L42 29 L36 34 L38 41 L32 37 L26 41 L28 34 L22 29 L29 29 Z" }),
    ]),
  ]);
  return artResult(node);
}
