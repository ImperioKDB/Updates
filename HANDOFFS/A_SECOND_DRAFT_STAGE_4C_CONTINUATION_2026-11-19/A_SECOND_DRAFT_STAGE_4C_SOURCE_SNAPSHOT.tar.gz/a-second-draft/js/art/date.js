/* Scene 2 calendar leaf: torn top, binder rings, minimal grid, rose day ring.
   Textless by design; the approved "03 · 03" stamp remains the textual date. */
import { svgEl, svgRoot, artResult } from "../lib/svg.js";

export function buildDateLeaf() {
  const node = svgRoot("0 0 160 120", "art art--date", [
    svgEl("g", { class: "art-date-leaf", "data-layer": "leaf" }, [
      svgEl("rect", { class: "art-fill-paper art-stroke-line", x: 20, y: 18, width: 120, height: 92, rx: 4, "stroke-width": 1.5 }),
      svgEl("path", { class: "art-stroke-line", "stroke-width": 1, d: "M20 26 L32 20 L44 26 L56 20 L68 26 L80 20 L92 26 L104 20 L116 26 L128 20 L140 26" }),
      svgEl("path", { class: "art-fill-paper-under", d: "M124 18 L140 18 L140 34 Z" }),
    ]),
    svgEl("g", { class: "art-date-rings", "data-layer": "rings" }, [
      svgEl("circle", { class: "art-stroke-ink", cx: 55, cy: 14, r: 6, "stroke-width": 2 }),
      svgEl("circle", { class: "art-stroke-ink", cx: 105, cy: 14, r: 6, "stroke-width": 2 }),
    ]),
    svgEl("g", { class: "art-date-grid", "data-layer": "grid" }, [
      svgEl("rect", { class: "art-fill-rose-tint", x: 28, y: 36, width: 104, height: 12, rx: 2 }),
      svgEl("path", { class: "art-stroke-line", "stroke-width": 1, d: "M28 60 H132 M28 78 H132 M28 96 H132 M54 54 V104 M80 54 V104 M106 54 V104" }),
    ]),
    svgEl("g", { class: "art-date-day", "data-layer": "day" }, [
      svgEl("circle", { class: "art-stroke-rose", cx: 80, cy: 78, r: 11, "stroke-width": 2.5 }),
      svgEl("circle", { class: "art-fill-rose", cx: 80, cy: 78, r: 2.5 }),
    ]),
  ]);
  return artResult(node);
}
