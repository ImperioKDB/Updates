/* Scene 3 generic university corridor: one-point perspective, lavender
   surfaces, gold doorway light, soft floor shadows. Not a real building.
   Reused as a faint watermark in Scene 7. Five layers prepared for 4C. */
import { svgEl, svgRoot, artResult } from "../lib/svg.js";

export function buildCorridor() {
  const node = svgRoot("0 0 320 180", "art art--corridor", [
    svgEl("g", { class: "art-corridor-far", "data-layer": "far" }, [
      svgEl("rect", { class: "art-fill-lavender-tint", x: 120, y: 40, width: 80, height: 100 }),
      svgEl("rect", { class: "art-fill-gold-tint", x: 146, y: 72, width: 28, height: 68 }),
      svgEl("path", { class: "art-stroke-gold", "stroke-width": 1.5, d: "M146 72 Q160 56 174 72" }),
    ]),
    svgEl("g", { class: "art-corridor-mid", "data-layer": "mid" }, [
      svgEl("path", { class: "art-fill-lavender-tint art-stroke-line", "stroke-width": 1, d: "M96 140 V78 Q112 60 128 78 V140 Z" }),
      svgEl("path", { class: "art-fill-lavender-tint art-stroke-line", "stroke-width": 1, d: "M192 140 V78 Q208 60 224 78 V140 Z" }),
    ]),
    svgEl("g", { class: "art-corridor-light", "data-layer": "light" }, [
      svgEl("polygon", { class: "art-fill-gold-tint", opacity: 0.55, points: "150,74 170,74 202,168 128,168" }),
      svgEl("polygon", { class: "art-fill-gold-tint", opacity: 0.35, points: "156,74 164,74 184,168 148,168" }),
    ]),
    svgEl("g", { class: "art-corridor-floor", "data-layer": "floor" }, [
      svgEl("polygon", { class: "art-fill-paper-under", points: "0,180 320,180 224,140 96,140" }),
      svgEl("polygon", { class: "art-fill-ink", opacity: 0.06, points: "78,150 92,150 62,180 30,180" }),
      svgEl("polygon", { class: "art-fill-ink", opacity: 0.06, points: "228,150 242,150 290,180 258,180" }),
    ]),
    svgEl("g", { class: "art-corridor-near", "data-layer": "near" }, [
      svgEl("rect", { class: "art-fill-lavender art-stroke-line", "stroke-width": 1, x: 64, y: 30, width: 14, height: 120 }),
      svgEl("rect", { class: "art-fill-lavender art-stroke-line", "stroke-width": 1, x: 242, y: 30, width: 14, height: 120 }),
    ]),
  ]);
  node.setAttribute("preserveAspectRatio", "xMidYMid slice");
  return artResult(node);
}
