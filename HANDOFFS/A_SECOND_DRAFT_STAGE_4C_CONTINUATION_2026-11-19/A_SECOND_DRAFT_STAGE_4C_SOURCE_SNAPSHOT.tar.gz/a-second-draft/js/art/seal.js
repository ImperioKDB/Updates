/* Irregular rose wax seal with an abstract pressed diamond (Stage 4B).
   Shared by the cover emblem, envelope and finale. Decorative, no text. */
import { svgEl } from "../lib/svg.js";

export function buildSealGroup(transform) {
  const attrs = { class: "art-seal", "data-layer": "seal" };
  if (transform) attrs.transform = transform;
  const node = svgEl("g", attrs, [
    svgEl("path", { class: "art-fill-rose", d: "M24 6 C31 5 38 9 40 15 C43 20 42 27 39 32 C36 38 30 42 23 42 C16 42 9 38 7 31 C5 25 6 18 10 13 C13 8 18 7 24 6 Z" }),
    svgEl("circle", { class: "art-stroke-gold", cx: 24, cy: 24, r: 10.5, "stroke-width": 1 }),
    svgEl("path", { class: "art-fill-ink", opacity: 0.18, d: "M24 17 L30 24 L24 31 L18 24 Z" }),
  ]);
  return { node, teardown: () => { node.remove(); } };
}
