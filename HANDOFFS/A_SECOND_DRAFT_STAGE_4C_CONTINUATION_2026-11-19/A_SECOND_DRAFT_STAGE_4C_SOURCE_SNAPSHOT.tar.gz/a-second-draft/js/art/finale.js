/* Scene 8 finale: signature flourish and resting wax seal.
   Bookends the Scene 1 emblem. Static; no response mechanisms. */
import { svgEl, svgRoot, artResult } from "../lib/svg.js";
import { buildSealGroup } from "./seal.js";

export function buildFinale() {
  const seal = buildSealGroup("translate(146 16) scale(0.5)");
  const node = svgRoot("0 0 180 56", "art art--finale", [
    svgEl("g", { class: "art-finale-flourish", "data-layer": "flourish" }, [
      svgEl("path", { class: "art-stroke-gold", "stroke-width": 1.5, d: "M8 28 C40 10 72 46 96 28 S140 12 138 28" }),
    ]),
    seal.node,
  ]);
  return artResult(node);
}
