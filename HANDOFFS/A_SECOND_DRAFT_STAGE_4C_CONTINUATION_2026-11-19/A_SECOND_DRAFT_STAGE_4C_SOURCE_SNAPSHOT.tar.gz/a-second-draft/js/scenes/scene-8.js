import { CLOSING } from "../data/closing.js";
import { renderClosingScene } from "../lib/closing.js";
import { buildPhotograph } from "../lib/photograph.js";
let teardown = null;
export function mount(root, context) {
  const view = renderClosingScene(root, context, CLOSING["scene-8"]);
  const photo = buildPhotograph({ src: "assets/scenes/scene-08.webp", alt: "Open cream letter, pressed flower and envelope with rose wax seal in golden-hour light." });
  view.node.prepend(photo.node);
  teardown = () => { photo.teardown(); view.teardown(); };
}
export function unmount() { if (teardown) { teardown(); teardown = null; } }
