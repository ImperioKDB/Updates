import { CLOSING } from "../data/closing.js";
import { renderClosingScene } from "../lib/closing.js";
import { buildPhotograph } from "../lib/photograph.js";
let teardown = null;
export function mount(root, context) {
  const view = renderClosingScene(root, context, CLOSING["scene-6"]);
  const photo = buildPhotograph({ src: "assets/scenes/scene-06.webp", alt: "Mock official report desk with cream papers, paper clips, fountain pen and stamp." });
  view.node.prepend(photo.node);
  teardown = () => { photo.teardown(); view.teardown(); };
}
export function unmount() { if (teardown) { teardown(); teardown = null; } }
