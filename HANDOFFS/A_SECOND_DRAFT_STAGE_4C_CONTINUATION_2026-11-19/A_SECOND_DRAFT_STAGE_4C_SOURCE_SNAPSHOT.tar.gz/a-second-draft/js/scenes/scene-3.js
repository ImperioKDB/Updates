import { STORY } from "../data/story.js";
import { renderStoryScene } from "../lib/story.js";
import { buildPhotograph } from "../lib/photograph.js";
let teardown = null;
export function mount(root, context) {
  const view = renderStoryScene(root, context, STORY["scene-3"]);
  const photo = buildPhotograph({ src: "assets/scenes/scene-03.webp", alt: "Quiet Nigerian university corridor with classroom doors in late-afternoon light." });
  view.node.prepend(photo.node);
  teardown = () => { photo.teardown(); view.teardown(); };
}
export function unmount() { if (teardown) { teardown(); teardown = null; } }
