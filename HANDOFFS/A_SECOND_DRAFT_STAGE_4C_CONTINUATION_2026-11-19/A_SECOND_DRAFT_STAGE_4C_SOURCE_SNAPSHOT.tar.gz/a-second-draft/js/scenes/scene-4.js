import { STORY } from "../data/story.js";
import { renderStoryScene } from "../lib/story.js";
import { buildPhotograph } from "../lib/photograph.js";
let teardown = null;
export function mount(root, context) {
  const view = renderStoryScene(root, context, STORY["scene-4"]);
  const photo = buildPhotograph({ src: "assets/scenes/scene-04.webp", alt: "Telephone handset beside a notebook and fountain pen on a desk in warm evening light." });
  view.node.prepend(photo.node);
  teardown = () => { photo.teardown(); view.teardown(); };
}
export function unmount() { if (teardown) { teardown(); teardown = null; } }
