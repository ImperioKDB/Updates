import { STORY } from "../data/story.js";
import { renderStoryScene } from "../lib/story.js";
import { buildPhotograph } from "../lib/photograph.js";
let teardown = null;
export function mount(root, context) {
  const view = renderStoryScene(root, context, STORY["scene-1"]);
  const photo = buildPhotograph({ src: "assets/scenes/scene-01.webp", alt: "Cream envelope, pressed flower and rose wax seal on a writing desk in warm window light.", priority: true });
  view.node.prepend(photo.node);
  teardown = () => { photo.teardown(); view.teardown(); };
}
export function unmount() { if (teardown) { teardown(); teardown = null; } }
