import { CLOSING } from "../data/closing.js";
import { renderClosingScene } from "../lib/closing.js";
import { buildPhotograph } from "../lib/photograph.js";
let teardown = null;
export function mount(root, context) {
  const view = renderClosingScene(root, context, CLOSING["scene-7"]);
  const photo = buildPhotograph({ src: "assets/scenes/scene-07.webp", alt: "Empty university corridor and bench in reflective afternoon light." });
  view.node.prepend(photo.node);
  teardown = () => { photo.teardown(); view.teardown(); };
}
export function unmount() { if (teardown) { teardown(); teardown = null; } }
