import { STORY } from "../data/story.js";
import { renderStoryScene } from "../lib/story.js";
import { buildPhotograph } from "../lib/photograph.js";
let teardown = null;
export function mount(root, context) {
  const view = renderStoryScene(root, context, STORY["scene-2"]);
  const photo = buildPhotograph({ src: "assets/scenes/scene-02.webp", alt: "Paper calendar journal with one date subtly circled in morning light." });
  view.node.prepend(photo.node);
  teardown = () => { photo.teardown(); view.teardown(); };
}
export function unmount() { if (teardown) { teardown(); teardown = null; } }
