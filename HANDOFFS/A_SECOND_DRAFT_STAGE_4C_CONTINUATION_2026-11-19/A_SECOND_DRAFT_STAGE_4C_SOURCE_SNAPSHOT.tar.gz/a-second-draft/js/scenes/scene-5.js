/* Scene 5 retains its explicit, user-initiated letter opening. */
import { el, on } from "../lib/dom.js";
import { reveal } from "../lib/motion.js";
import { renderLetterPanel } from "../lib/letter.js";
import { LETTER, verifyLetterIntegrity } from "../data/letter.js";
import { buildPhotograph } from "../lib/photograph.js";
let teardown = null;
export function mount(root, context) {
  const offs = [];
  let letterTeardown = null;
  let integrityOff = null;
  let opened = false;
  const photo = buildPhotograph({ src: "assets/scenes/scene-05.webp", alt: "Cream stationery, sealed envelope and rose wax seal beside a partially visible letter." });
  function openLetter() {
    if (opened) return;
    opened = true;
    envelope.remove();
    photo.teardown();
    cancelReveal();
    letterTeardown = renderLetterPanel(root, { heading: context.scene.title, paragraphs: [LETTER.salutation, ...LETTER.body], closing: LETTER.closing, signature: LETTER.signature, accent: true });
    const heading = root.querySelector(".scene-title");
    if (heading) heading.focus({ preventScroll: true });
    verifyLetterIntegrity().then((result) => {
      if (result.actualHash && !result.ok) {
        const notice = el("p", { class: "letter-integrity", role: "alert", text: "Letter integrity check failed. The text may have been altered." });
        root.append(notice);
        integrityOff = () => notice.remove();
      }
    }).catch(() => { /* verification unavailable; reading is unaffected */ });
  }
  const envelope = el("article", { class: "envelope", "aria-labelledby": "scene-title" }, [
    el("h1", { class: "scene-title envelope-title", id: "scene-title", tabindex: "-1", text: context.scene.title }),
    photo.node,
    el("p", { class: "envelope-tagline", text: "Some things deserve to be said properly." }),
    el("button", { class: "btn btn-primary envelope-open", type: "button", text: "Open the letter" }),
  ]);
  root.append(envelope);
  offs.push(on(envelope.querySelector(".envelope-open"), "click", openLetter));
  const cancelReveal = reveal(envelope);
  teardown = () => { photo.teardown(); cancelReveal(); offs.forEach((off) => off()); if (letterTeardown) letterTeardown(); if (integrityOff) integrityOff(); envelope.remove(); };
}
export function unmount() { if (teardown) { teardown(); teardown = null; } }
