/* Hash router with a strict scene lifecycle:
   unmount current -> clear outlet -> load next -> mount.
   A navigation token guards against stale async mounts during rapid
   back/forward sequences. A valid hash always wins (direct links).
   When no valid hash exists, the saved scene is restored via
   replaceState (no extra history entry), falling back to the first
   scene when nothing valid is stored. */
import { SCENES, FIRST_SCENE, sceneByRoute, sceneById } from "./data/manifest.js";
import * as state from "./state.js";
import { clear, el, on } from "./lib/dom.js";
import { pageLift } from "./lib/motion.js";

let outlet = null;
let notify = null;
let current = null;
let navigationToken = 0;
let activeTransition = null;

export function resolveRoute(hash) {
  return sceneByRoute(String(hash || "").trim());
}

function fallbackEntry() {
  return sceneById(state.getState().currentScene) || FIRST_SCENE;
}

export function currentScene() {
  return current ? current.entry : null;
}

export function go(route) {
  if (location.hash === route) return;
  location.hash = route;
}

function mountFailure() {
  const retry = el("button", { class: "btn btn-primary", type: "button", text: "Try again" });
  const off = on(retry, "click", () => handleRoute());
  clear(outlet);
  outlet.append(
    el("article", { class: "scene" }, [
      el("h1", { class: "scene-title", tabindex: "-1", text: "This page slipped out" }),
      el("div", { class: "scene-rule", "aria-hidden": "true" }),
      el("p", {
        class: "scene-note",
        text: "This scene could not be loaded. Check your connection and try again.",
      }),
      retry,
    ])
  );
  current = { entry: resolveRoute(location.hash) || FIRST_SCENE, module: { unmount: off }, failed: true };
  if (notify) notify(current.entry, { error: true });
}

async function handleRoute() {
  const token = ++navigationToken;
  if (activeTransition) activeTransition.cancel();
  activeTransition = pageLift(outlet);
  await activeTransition.finished;
  if (token !== navigationToken) return;
  activeTransition = null;
  let entry = resolveRoute(location.hash);
  if (!entry) {
    entry = fallbackEntry();
    history.replaceState(null, "", entry.route);
  }
  if (current && current.entry.id === entry.id && !current.failed) return;

  if (current) {
    try {
      current.module.unmount();
    } catch (error) {
      console.error("Scene unmount failed:", error);
    }
    current = null;
  }
  clear(outlet);

  let module;
  try {
    module = await entry.load();
  } catch (error) {
    if (token !== navigationToken) return;
    console.error("Scene load failed:", error);
    mountFailure();
    return;
  }
  if (token !== navigationToken) return; // a newer navigation owns the outlet now

  const context = {
    scene: entry,
    index: entry.order - 1,
    total: SCENES.length,
    state,
    navigate: go,
  };
  try {
    module.mount(outlet, context);
  } catch (error) {
    console.error("Scene mount failed:", error);
    mountFailure();
    return;
  }
  current = { entry, module, failed: false };
  state.setCurrentScene(entry.id);
  document.title = entry.title + " - A Second Draft";
  outlet.scrollTop = 0;
  if (notify) notify(entry, { error: false });
}

export function start({ root, onChange }) {
  outlet = root;
  notify = onChange || null;
  on(window, "hashchange", handleRoute);
  if (!resolveRoute(location.hash)) {
    history.replaceState(null, "", fallbackEntry().route);
  }
  return handleRoute();
}
