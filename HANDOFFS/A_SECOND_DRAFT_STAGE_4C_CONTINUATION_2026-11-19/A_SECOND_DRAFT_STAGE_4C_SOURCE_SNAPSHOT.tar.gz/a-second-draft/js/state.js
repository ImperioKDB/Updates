/* Central store. Persists ONLY scene ids and preferences under a versioned
   key, with an in-memory fallback when storage is unavailable.
   Never persist letter text, personal responses or interaction content. */
import { SCENES, FIRST_SCENE, sceneById } from "./data/manifest.js";

const STORAGE_KEY = "a-second-draft.state.v1";
const VERSION = 1;
const MOTION_VALUES = ["system", "reduced", "full"];
const AUDIO_VALUES = ["off", "on"]; // reserved for a later stage; no audio exists yet

const defaults = () => ({
  version: VERSION,
  currentScene: FIRST_SCENE.id,
  visited: [FIRST_SCENE.id],
  motion: "system",
  audio: "off",
});

function storageAvailable() {
  try {
    const probe = STORAGE_KEY + ".probe";
    localStorage.setItem(probe, "1");
    localStorage.removeItem(probe);
    return true;
  } catch {
    return false;
  }
}

const canPersist = storageAvailable();

function sanitize(raw) {
  const base = defaults();
  if (!raw || typeof raw !== "object" || raw.version !== VERSION) return base;
  const ids = new Set(SCENES.map((scene) => scene.id));
  const currentScene = ids.has(raw.currentScene) ? raw.currentScene : base.currentScene;
  const visited = Array.isArray(raw.visited)
    ? [...new Set(raw.visited.filter((id) => ids.has(id)))]
    : [];
  if (!visited.includes(currentScene)) visited.unshift(currentScene);
  return {
    version: VERSION,
    currentScene,
    visited,
    motion: MOTION_VALUES.includes(raw.motion) ? raw.motion : base.motion,
    audio: AUDIO_VALUES.includes(raw.audio) ? raw.audio : base.audio,
  };
}

function load() {
  if (!canPersist) return defaults();
  try {
    return sanitize(JSON.parse(localStorage.getItem(STORAGE_KEY)));
  } catch {
    return defaults();
  }
}

let memory = load();
const subscribers = new Set();

function persist() {
  if (!canPersist) return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(memory));
  } catch {
    /* Storage may fill or be revoked; in-memory state stays authoritative. */
  }
}

function commit() {
  persist();
  const snapshot = getState();
  for (const fn of subscribers) fn(snapshot);
}

export function getState() {
  return { ...memory, visited: [...memory.visited] };
}

export function subscribe(fn) {
  subscribers.add(fn);
  return () => subscribers.delete(fn);
}

export function setCurrentScene(id) {
  if (!sceneById(id)) return;
  memory.currentScene = id;
  if (!memory.visited.includes(id)) memory.visited.push(id);
  commit();
}

export function setMotion(preference) {
  if (!MOTION_VALUES.includes(preference)) return;
  memory.motion = preference;
  commit();
}

export function setAudio(preference) {
  if (!AUDIO_VALUES.includes(preference)) return;
  memory.audio = preference;
  commit();
}

export function reducedMotion() {
  if (memory.motion === "reduced") return true;
  if (memory.motion === "full") return false;
  return typeof matchMedia === "function"
    && matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export function storageMode() {
  return canPersist ? "local" : "memory";
}
