/* Application shell: wires navigation chrome to the router and manifest. */
import { SCENES } from "./data/manifest.js";
import * as router from "./router.js";
import { el, on, qs } from "./lib/dom.js";

function init() {
  const root = qs("#scene-root");
  const prevButton = qs("#prev-btn");
  const nextButton = qs("#next-btn");
  const indicatorCount = qs("#indicator-count");
  const indicatorTitle = qs("#indicator-title");
  const contentsButton = qs("#contents-btn");
  const contentsDialog = qs("#contents-dialog");
  const contentsClose = qs("#contents-close");
  const contentsList = qs("#contents-list");
  const progressFill = qs("#progress-fill");

  for (const scene of SCENES) {
    contentsList.append(
      el("li", {}, [
        el("a", { class: "contents-link", href: scene.route }, [
          el("span", { class: "contents-order", text: String(scene.order) }),
          el("span", { class: "contents-name", text: scene.title }),
        ]),
      ])
    );
  }
  const contentsLinks = [...contentsList.querySelectorAll("a")];

  const supportsDialog = typeof contentsDialog.showModal === "function";

  // Single writer for aria-expanded: always mirrors the dialog's real state.
  // Idempotent, so every pathway below can call it safely.
  function syncContentsState() {
    contentsButton.setAttribute("aria-expanded", String(contentsDialog.open));
  }

  function openContents() {
    if (supportsDialog) contentsDialog.showModal();
    else contentsDialog.setAttribute("open", "");
    syncContentsState();
  }

  function closeContents() {
    if (supportsDialog) contentsDialog.close();
    else contentsDialog.removeAttribute("open");
    syncContentsState();
  }

  on(contentsButton, "click", openContents);
  on(contentsClose, "click", closeContents);
  on(contentsDialog, "click", (event) => {
    if (event.target === contentsDialog) closeContents(); // backdrop click
  });
  // Idiomatic native-close coverage (Escape, Android back gesture, close()).
  on(contentsDialog, "close", syncContentsState);
  if (!supportsDialog) {
    on(contentsDialog, "keydown", (event) => {
      if (event.key === "Escape") closeContents();
    });
  }

  // Structural guarantee: mirror the dialog's open attribute itself. Whatever
  // closes the dialog (Escape, back gesture, programmatic close, or any path
  // that changes state without firing "close"), the trigger stays correct.
  // One observer for the app lifetime, no duplicate listeners; focus is never
  // touched here, so native focus restoration is preserved.
  const contentsObserver = new MutationObserver(syncContentsState);
  contentsObserver.observe(contentsDialog, { attributes: true, attributeFilter: ["open"] });

  function step(delta) {
    const current = router.currentScene();
    if (!current) return;
    const target = SCENES[current.order - 1 + delta];
    if (target) router.go(target.route);
  }
  on(prevButton, "click", () => step(-1));
  on(nextButton, "click", () => step(1));

  let firstRender = true;
  function sync(entry) {
    prevButton.disabled = entry.order === 1;
    nextButton.disabled = entry.order === SCENES.length;
    indicatorCount.textContent = `${entry.order} of ${SCENES.length}`;
    indicatorTitle.textContent = entry.title;
    if (progressFill) progressFill.style.width = `${(entry.order / SCENES.length) * 100}%`;
    for (const link of contentsLinks) {
      const active = link.getAttribute("href") === entry.route;
      link.classList.toggle("is-current", active);
      if (active) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    }
    closeContents();
    if (!firstRender) {
      const heading = root.querySelector(".scene-title");
      if (heading) heading.focus({ preventScroll: true });
    }
    firstRender = false;
  }

  router.start({ root, onChange: sync });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init, { once: true });
} else {
  init();
}
