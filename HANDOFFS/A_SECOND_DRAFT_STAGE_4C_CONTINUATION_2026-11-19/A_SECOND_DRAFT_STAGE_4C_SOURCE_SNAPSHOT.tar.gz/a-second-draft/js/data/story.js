/* A Second Draft - approved narrative for Scenes 1-4 (Stage 3, Batch A).
   Verbatim approved copy. Do not edit, paraphrase, reorder or "correct".
   Prose is kept separate from decorative metadata (STORY_DECOR).
   Integrity: STORY_SHA256 is the SHA-256 of canonicalStory() (UTF-8). */

const STORY_DATA = {
  "scene-1": {
    "kicker": "THE OPENING PAGE",
    "title": "The Invitation",
    "tagline": "Some things deserve to be said properly.",
    "motif": null,
    "paragraphs": [
      "Not every story needs a grand beginning. Sometimes, it is enough to pause, turn a page, and give a few thoughts the attention they deserve.",
      "This is one of those moments."
    ]
  },
  "scene-2": {
    "kicker": "A DATE WORTH REMEMBERING",
    "title": "March 3rd",
    "tagline": null,
    "motif": "03 · 03",
    "paragraphs": [
      "Some dates pass without asking to be remembered. Others quietly become attached to a person, a conversation, or the beginning of something unexpected.",
      "March 3rd was the day our paths crossed properly. And what began as a meeting gradually became an opportunity to discover someone I would come to appreciate."
    ]
  },
  "scene-3": {
    "kicker": "THE PLACES THAT REMEMBER",
    "title": "Familiar Places",
    "tagline": null,
    "motif": null,
    "paragraphs": [
      "There were the night classes, the conversations, and the little moments that slowly became part of the routine.",
      "Then came the change of scenery.",
      "You left UNIBEN, but the places where we used to study remained. And sometimes, passing through those familiar spaces brings back memories I wasn't necessarily looking for.",
      "Funny how an ordinary hallway can hold on to a little piece of someone's presence."
    ]
  },
  "scene-4": {
    "kicker": "A CONNECTION THAT FOUND ITS WAY",
    "title": "The Calls",
    "tagline": null,
    "motif": null,
    "paragraphs": [
      "Staying connected wasn't always straightforward. We had our little difficulties communicating online, but somehow, we eventually found our way to those phone calls.",
      "And something about them was different.",
      "Conversations became easier. The silences didn't always need filling. Even ordinary days seemed to have something worth looking forward to.",
      "Those calls became a part of my days that I genuinely looked forward to.",
      "And there is something about that which I don't want to leave unsaid."
    ]
  }
};

function deepFreeze(value) {
  if (value && typeof value === "object") {
    Object.values(value).forEach(deepFreeze);
    Object.freeze(value);
  }
  return value;
}

export const STORY = deepFreeze(STORY_DATA);

export const STORY_SCENE_IDS = Object.freeze(["scene-1", "scene-2", "scene-3", "scene-4"]);

/* Decorative metadata only; never part of the prose or its hash. */
export const STORY_DECOR = Object.freeze({
  "scene-1": "invitation",
  "scene-2": "date",
  "scene-3": "places",
  "scene-4": "calls",
});

export const STORY_PARAGRAPH_COUNTS = Object.freeze({ "scene-1": 2, "scene-2": 2, "scene-3": 4, "scene-4": 5 });
export const STORY_SHA256 = "49bb1eb0df0549b341c9bd61e610d0b277ca21e797482dc639e8cde266d5e28a";

export function canonicalScene(id) {
  const entry = STORY[id];
  const lines = [entry.kicker, entry.title];
  if (entry.tagline) lines.push(entry.tagline);
  if (entry.motif) lines.push(entry.motif);
  return lines.concat(entry.paragraphs).join("\n");
}

export function canonicalStory() {
  return STORY_SCENE_IDS.map(canonicalScene).join("\n\n");
}

export async function verifyStoryIntegrity() {
  const canonical = canonicalStory();
  let actualHash = "";
  const subtle = globalThis.crypto && globalThis.crypto.subtle;
  if (subtle) {
    const digest = await subtle.digest("SHA-256", new TextEncoder().encode(canonical));
    actualHash = Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
  }
  const counts = {};
  let countsOk = true;
  for (const id of STORY_SCENE_IDS) {
    counts[id] = STORY[id].paragraphs.length;
    if (counts[id] !== STORY_PARAGRAPH_COUNTS[id]) countsOk = false;
  }
  const ok = actualHash === STORY_SHA256 && countsOk;
  return { ok, expectedHash: STORY_SHA256, actualHash, counts, countsOk };
}
