/* Scene registry: single source of truth for identity, order and loading.
   Routing logic never hardcodes scene content. */

const define = (scene) => Object.freeze(scene);

export const SCENES = Object.freeze([
  define({ id: "scene-1", order: 1, title: "The Invitation", route: "#/scene-1", load: () => import("../scenes/scene-1.js") }),
  define({ id: "scene-2", order: 2, title: "March 3rd", route: "#/scene-2", load: () => import("../scenes/scene-2.js") }),
  define({ id: "scene-3", order: 3, title: "Familiar Places", route: "#/scene-3", load: () => import("../scenes/scene-3.js") }),
  define({ id: "scene-4", order: 4, title: "The Calls", route: "#/scene-4", load: () => import("../scenes/scene-4.js") }),
  define({ id: "scene-5", order: 5, title: "A Second Draft", route: "#/scene-5", load: () => import("../scenes/scene-5.js") }),
  define({ id: "scene-6", order: 6, title: "Department of Bright's Unnecessary Seriousness", route: "#/scene-6", load: () => import("../scenes/scene-6.js") }),
  define({ id: "scene-7", order: 7, title: "What Remains", route: "#/scene-7", load: () => import("../scenes/scene-7.js") }),
  define({ id: "scene-8", order: 8, title: "Until Whenever", route: "#/scene-8", load: () => import("../scenes/scene-8.js") }),
]);

export const FIRST_SCENE = SCENES[0];

export function sceneByRoute(route) {
  return SCENES.find((scene) => scene.route === route) || null;
}

export function sceneById(id) {
  return SCENES.find((scene) => scene.id === id) || null;
}
