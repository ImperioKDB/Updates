/* A Second Draft - approved narrative for Scenes 6-8 (Stage 3B).
   Verbatim approved copy. Do not edit, paraphrase, reorder or "correct".
   Prose is kept separate from decorative metadata (CLOSING_DECOR).
   Integrity: CLOSING_SHA256 is the SHA-256 of canonicalClosing() (UTF-8). */

const CLOSING_DATA = {
  "scene-6": {
    "kicker": "THE OFFICIAL REPORT",
    "title": "Department of Bright's Unnecessary Seriousness",
    "motif": "An entirely unofficial departmental report.",
    "paragraphs": [
      "Following a thorough internal review, the Department of Bright's Unnecessary Seriousness has identified a few areas requiring improvement.",
      "First, the department acknowledges that not every silence is a problem to solve, and not every moment of distance is a reason to panic.",
      "Second, it recognises that listening is sometimes more useful than trying to interpret everything.",
      "Third, the department has recommended the immediate retirement of unnecessary assumptions, excessive overthinking, and unsolicited investigations into perfectly innocent quiet moments.",
      "These recommendations are not merely theoretical. The department intends to take them seriously."
    ],
    "closing": null,
    "signature": null
  },
  "scene-7": {
    "kicker": "BEYOND THE APOLOGY",
    "title": "What Remains",
    "motif": null,
    "paragraphs": [
      "Beyond everything I have apologised for, I don't want the difficult moments to erase the good ones.",
      "I still appreciate the conversations, the laughter, the calls, and the simple fact that our paths crossed.",
      "I also understand that appreciating someone means respecting the space they need, even when that space looks different from what I might have expected.",
      "I cannot rewrite the moments I handled poorly. But I can learn from them, and I intend to.",
      "You deserve to be understood without having to repeatedly explain yourself. That is something I should have understood better."
    ],
    "closing": null,
    "signature": null
  },
  "scene-8": {
    "kicker": "THE LAST PAGE",
    "title": "Until Whenever",
    "motif": null,
    "paragraphs": [
      "I don't know what the future holds, and I don't think this little experience needs to answer that question.",
      "I simply wanted to say what I should have said properly, acknowledge what I could have handled better, and let you know that I genuinely appreciate you.",
      "If our paths find their way into more conversations, I'll be glad. If life takes us in different directions, I'll still be grateful for the parts of this story we shared.",
      "No expectations. No pressure to respond. Just a sincere apology, and a little appreciation from someone who wishes you well."
    ],
    "closing": "Until whenever, Doc.",
    "signature": "Bright."
  }
};

function deepFreeze(value) {
  if (value && typeof value === "object") {
    Object.values(value).forEach(deepFreeze);
    Object.freeze(value);
  }
  return value;
}

export const CLOSING = deepFreeze(CLOSING_DATA);

export const CLOSING_SCENE_IDS = Object.freeze(["scene-6", "scene-7", "scene-8"]);

/* Decorative metadata only; never part of the prose or its hash. */
export const CLOSING_DECOR = Object.freeze({
  "scene-6": "report",
  "scene-7": "remains",
  "scene-8": "last",
});

export const CLOSING_PARAGRAPH_COUNTS = Object.freeze({ "scene-6": 5, "scene-7": 5, "scene-8": 4 });
export const CLOSING_SHA256 = "928883e47a3ae40501ce6a4502e57f0854eca72f81ae4f196b9ac4ea3e07a24d";

export function canonicalScene(id) {
  const entry = CLOSING[id];
  const lines = [entry.kicker, entry.title];
  if (entry.motif) lines.push(entry.motif);
  lines.push(...entry.paragraphs);
  if (entry.closing) lines.push(entry.closing);
  if (entry.signature) lines.push(entry.signature);
  return lines.join("\n");
}

export function canonicalClosing() {
  return CLOSING_SCENE_IDS.map(canonicalScene).join("\n\n");
}

export async function verifyClosingIntegrity() {
  const canonical = canonicalClosing();
  let actualHash = "";
  const subtle = globalThis.crypto && globalThis.crypto.subtle;
  if (subtle) {
    const digest = await subtle.digest("SHA-256", new TextEncoder().encode(canonical));
    actualHash = Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
  }
  const counts = {};
  let countsOk = true;
  for (const id of CLOSING_SCENE_IDS) {
    counts[id] = CLOSING[id].paragraphs.length;
    if (counts[id] !== CLOSING_PARAGRAPH_COUNTS[id]) countsOk = false;
  }
  const ok = actualHash === CLOSING_SHA256 && countsOk;
  return { ok, expectedHash: CLOSING_SHA256, actualHash, counts, countsOk };
}
