/* A Second Draft - the approved letter, verbatim.
   Authoritative source content. Do not edit, paraphrase, reorder or "correct".
   The text is rendered as text (never HTML). Integrity is verified against
   LETTER_SHA256 (SHA-256 of the paragraphs joined by a blank line). */

export const LETTER_PARAGRAPHS = Object.freeze(
[
  "Dear Doc,",
  "Well, look who's receiving a digitally delivered apology.",
  "I suppose an ordinary text message wasn't sufficiently dramatic for someone who has apparently decided to become a software developer of unnecessary emotional complications.",
  "But I promise there's a reason for all this.",
  "I've been thinking about our last conversation, and I realised that there are things I should have said differently. Things I should have understood better. And, most importantly, things I owe you an apology for.",
  "So, let's start from the beginning.",
  "March 3rd.",
  "It's funny how two people can notice each other at different times, yet somehow end up meeting at just the right moment.",
  "March 3rd was when we actually met and spoke. I still remember getting to know you and gradually discovering just how extraordinary you were.",
  "You know, I've always thought of it like staring at a painting from afar, only to walk closer and discover that it is even more exquisite than you initially imagined.",
  "That was what getting to know you felt like.",
  "Then came the night classes, the conversations, and those little moments that gradually became familiar.",
  "And when you left UNIBEN, I remember how strange it felt seeing the places where we used to study. Sometimes, walking through those halls, I still find myself remembering you.",
  "I suppose places have a funny way of keeping memories.",
  "Then came the phone calls.",
  "Connecting online wasn't always easy. We had our little communication difficulties, but somehow, we found our way to those phone calls.",
  "And honestly, those became some of the best parts of my days.",
  "For the first time in a while, talking to someone didn't feel like an obligation or something I had to exhaust myself doing.",
  "It was simply enjoyable.",
  "I could talk to you without constantly wondering what to say next. Sometimes I didn't even want the conversations to end.",
  "Perhaps that's why your silence affects me more than I sometimes know how to explain.",
  "But here's where I need to acknowledge something.",
  "Your need for space is not something I should have turned into an accusation.",
  "You told me you needed time away from being actively online, that you wanted to reconstruct yourself and get your life together.",
  "I heard you, but I don't think I fully understood what that meant for you.",
  "Instead of communicating my feelings calmly, I allowed my frustration and disappointment to influence my words.",
  "I made assumptions about your intentions. I spoke as though your absence meant you didn't value what we had. And I made you feel that you had to defend yourself for wanting time to work on your own life.",
  "I'm sorry, Doc.",
  "You didn't deserve that.",
  "I should have been able to tell you that I missed you without making you feel guilty for being away.",
  "I should have expressed my disappointment without making conclusions about your character.",
  "And I should have remembered that someone can genuinely value a connection and still need time and space for themselves.",
  "I don't want to make excuses for how I behaved.",
  "I got some things wrong, and I own that.",
  "A small interruption from the Department of Bright's Unnecessary Seriousness.",
  "Following an extensive internal investigation, the department has established that:",
  "Being emotionally invested does not automatically make one an expert in communication.",
  "Jumping to conclusions is not an approved method of maintaining friendships.",
  "Sometimes, the correct response is to listen, understand and breathe before typing an entire emotional dissertation.",
  "The department is currently undergoing restructuring.",
  "Please bear with us.",
  "One more thing.",
  "I don't want this apology to erase the good things I remember about you.",
  "I still think you're extraordinary, Doc.",
  "I still remember March 3rd. The night classes. The phone calls. The laughter and the little things that made talking to you so effortless.",
  "I'm grateful that our paths crossed.",
  "And although I cannot pretend that your leaving UNIBEN or the periods of silence haven't affected me, I don't want those things to become the only memories that define our connection.",
  "I'd like to think there's still room for more good memories.",
  "I'd like us to find our way back to talking, laughing and being comfortable with each other again, if that's something you would also want.",
  "But I don't want you to feel obligated.",
  "You have your life to put together, your own journey to take, and I respect that.",
  "You don't owe me an immediate response, an explanation or a promise.",
  "I simply wanted you to know that I recognise where I went wrong, that I am genuinely sorry, and that I still value you.",
  "Until whenever, Doc.",
  "No dramatic soundtrack. No countdown. No compulsory forgiveness form.",
  "Just a sincere apology from someone who could have handled things better.",
  "And perhaps, if life permits, a chance to write a few better chapters.",
  "With affection,",
  "Bright."
]
);

export const LETTER_PARAGRAPH_COUNT = 59;
export const LETTER_SHA256 = "9621669d65fe51d3a062ad4540a7f08f7acbf4429fbc9f6813d07e89a0eefff6";

export const LETTER = Object.freeze({
  salutation: LETTER_PARAGRAPHS[0],
  body: Object.freeze(LETTER_PARAGRAPHS.slice(1, -2)),
  closing: LETTER_PARAGRAPHS[LETTER_PARAGRAPHS.length - 2],
  signature: LETTER_PARAGRAPHS[LETTER_PARAGRAPHS.length - 1],
});

export function canonicalLetter() {
  return LETTER_PARAGRAPHS.join("\n\n");
}

export async function verifyLetterIntegrity() {
  const canonical = canonicalLetter();
  const actualCount = LETTER_PARAGRAPHS.length;
  let actualHash = "";
  const subtle = globalThis.crypto && globalThis.crypto.subtle;
  if (subtle) {
    const digest = await subtle.digest("SHA-256", new TextEncoder().encode(canonical));
    actualHash = Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
  }
  const ok = actualHash === LETTER_SHA256 && actualCount === LETTER_PARAGRAPH_COUNT;
  return { ok, expectedHash: LETTER_SHA256, actualHash, expectedCount: LETTER_PARAGRAPH_COUNT, actualCount };
}
